# Render MCP Prompts

## Discovery

```text
Use the Render MCP connection to list the services available to the current workspace.
Identify the service running n8n and the associated PostgreSQL database.
Return name, type, region, current status, and public URL where available.
Do not modify, redeploy, suspend, resume, scale, or delete anything.
```

## Deployment inspection

```text
Inspect the current deployment of the n8n service.
Review recent logs and report:
- whether the image pulled successfully;
- whether n8n started on port 5678;
- whether PostgreSQL authentication succeeded;
- whether the service is restarting;
- whether any environment variable appears missing by name.

Redact all secret values.
Do not change settings or trigger a deployment.
```

## Safe troubleshooting

```text
Investigate why the n8n health check is failing.
Read service events, deployment status, and recent logs.
Classify the likely cause as image, port, database, environment, resource exhaustion,
or application startup.
Propose the smallest reversible change.
Do not execute the change until I explicitly approve it.
```

## Verification after deployment

```text
Confirm that the n8n service is available and stable.
Check its latest deployment, restart count, and recent error logs.
Do not make any write operation.
```
