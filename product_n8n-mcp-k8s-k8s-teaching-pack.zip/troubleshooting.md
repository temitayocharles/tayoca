# Troubleshooting

## Render Blueprint fails to create PostgreSQL

A workspace might already have its allowed free PostgreSQL database.

Resolution:

- use the paid database plan from `render.yaml`;
- delete an unused free database only after confirming it is disposable;
- ensure the service and database regions match.

## n8n cannot connect to PostgreSQL

Check variable names:

```text
DB_TYPE
DB_POSTGRESDB_DATABASE
DB_POSTGRESDB_HOST
DB_POSTGRESDB_PASSWORD
DB_POSTGRESDB_USER
```

Use Render's internal host for the database.

Do not log the password.

## n8n starts but webhooks show the wrong host

Set:

```text
WEBHOOK_URL=https://YOUR-N8N-SERVICE.onrender.com/
```

Save and redeploy.

## n8n MCP tools are missing

Check:

1. instance-level MCP is enabled;
2. the endpoint ends with `/mcp-server/http`;
3. authentication completed successfully;
4. the n8n version supports workflow creation and editing through MCP;
5. the connected n8n user has access to the intended project;
6. the client rescanned tools after the connection changed.

## ChatGPT cannot create a custom MCP app

Confirm that the account is in a ChatGPT Business or Enterprise/Edu workspace and that the
appropriate administrator enabled developer mode.

A personal Plus account is not sufficient for the direct ChatGPT custom-app route.

Use Codex as the fallback.

## Render MCP cannot deploy the n8n image

Render's hosted MCP currently does not cover every resource-creation path, including the full
creation of image-backed services.

Use the Render dashboard or Blueprint for initial n8n deployment.

Use Render MCP afterward for supported inspection and management actions.

## MCP stream disconnects

n8n MCP uses streamable HTTP/SSE patterns.

Check:

- proxy buffering;
- timeouts;
- authentication;
- whether multiple webhook replicas are routing the same MCP session inconsistently;
- Render service restarts or insufficient resources.

## AI-generated workflow is structurally valid but logically wrong

Import the known-good backup workflow.

Compare:

- validation conditions;
- unknown-field rejection;
- output schema;
- node types;
- absence of shell execution;
- absence of direct cluster access.

## Webhook test returns 404

- publish or activate the workflow if the production URL requires it;
- use `/webhook/`, not `/webhook-test/`, for the production path;
- confirm the exact path in the Webhook node;
- confirm `WEBHOOK_URL`.

## Composio can see too many repositories

Stop the demonstration and reduce the GitHub connection scope.

Do not continue with an over-scoped connection.

## Pull request contains unrelated files

Do not merge.

Close the pull request, remove the branch, correct the prompt/tool scope, and repeat using a clean branch.
