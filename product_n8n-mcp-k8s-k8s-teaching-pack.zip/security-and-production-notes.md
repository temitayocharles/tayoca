# Security and Production Notes

## Render

- Use a dedicated workspace or project for the demonstration.
- Render API keys can be broadly scoped. Do not connect one that exposes unrelated production services.
- Store API keys in a password manager or secret store.
- Pin the n8n image after testing.
- Preserve `N8N_ENCRYPTION_KEY`.
- Back up PostgreSQL and test recovery.
- Use paid instances for a reliable live lesson.
- Keep the web service and database in the same region.

## n8n

- Create a dedicated project and operator account.
- Prefer OAuth for MCP where possible.
- Rotate MCP access tokens after the recording.
- Enable only workflows intended for MCP access.
- Remember that clients connected as the same user can see that user's MCP-enabled workflows.
- Restrict execution-data retention and redact sensitive payloads.
- Never use an unrestricted Execute Command node for an AI-generated workflow.
- Review all AI-generated Code node content.
- Configure webhook authentication before public use.
- Set rate and concurrency limits appropriate to the workload.

## Composio

- Connect a test GitHub account or limit access to a demo repository.
- Review requested OAuth scopes.
- Do not grant organization administration for repository file operations.
- Use a separate Slack test channel.
- Revoke or disconnect the demo connection after recording if it is no longer needed.

## GitHub and GitOps

- Require pull requests.
- Protect main.
- Require CI and policy checks.
- Never allow the AI to merge during the initial lesson.
- Validate manifests with kubeconform or an equivalent schema validator.
- Test policy with Conftest, OPA, or Kyverno.
- Scan images and enforce signed-image policy where applicable.
- Use Argo CD Projects to restrict destinations, namespaces, and repositories.

## Kubernetes

- Use a non-production cluster and namespace.
- Set ResourceQuota and LimitRange.
- Do not provide cluster-admin credentials to ChatGPT, n8n, or Composio.
- When direct Kubernetes access is later introduced, begin with read-only `get`, `list`,
  and `watch` permissions through a dedicated service account.
- Separate observation tools from mutation tools.
- Put consequential write operations behind human approval.

## Threats demonstrated by the design

- secret leakage through screen sharing;
- over-scoped API tokens;
- prompt injection leading to tool misuse;
- AI-generated shell execution;
- arbitrary URL/SSRF-style access;
- unreviewed Kubernetes mutation;
- malformed or overly privileged manifests;
- workflow validation mistaken for security validation;
- tool hallucination or false success claims.
