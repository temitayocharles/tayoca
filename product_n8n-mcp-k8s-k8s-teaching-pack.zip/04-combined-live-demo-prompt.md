# Combined Live Demonstration Prompt

Use the connected n8n MCP and Composio GitHub tools.

Phase 1: n8n workflow

Create or update the n8n workflow named:

```text
Kubernetes GitOps Manifest Builder - Teaching Lab
```

The workflow must:

1. Receive POST JSON at `kubernetes-gitops-request`.
2. Accept only:
   - app_name
   - image
   - namespace
   - replicas
   - container_port
3. Reject unknown fields.
4. Validate Kubernetes DNS labels.
5. Limit replicas to 1–5.
6. Limit container_port to 1–65535.
7. Generate only a Deployment and ClusterIP Service.
8. Add standard labels, resource requests/limits, probes, disabled service-account token
   automount, RuntimeDefault seccomp, dropped capabilities, and no privilege escalation.
9. Return a summary and a `files` array with `path` and `content`.
10. Never use shell execution, SSH, kubectl, kubeconfig, or arbitrary HTTP requests.
11. Remain inactive until reviewed.
12. Be validated after creation.

Stop and present the exact node list, assumptions, and validation result.

Do not continue until I say:

```text
APPROVE WORKFLOW
```

Phase 2: workflow execution

After approval, execute the workflow with:

```json
{
  "app_name": "hello-mcp",
  "image": "nginx:1.27-alpine",
  "namespace": "mcp-demo",
  "replicas": 2,
  "container_port": 80
}
```

Review the generated files.

Stop and show:
- paths;
- resource kinds;
- names;
- namespace;
- image;
- replica count;
- service port;
- any security assumptions.

Do not continue until I say:

```text
APPROVE GITHUB PR
```

Phase 3: GitHub through Composio

After approval:

1. Use repository `<OWNER>/<REPOSITORY>`.
2. Create `demo/hello-mcp` from main.
3. Write only the two generated manifest files.
4. Open a pull request titled `Deploy hello-mcp to mcp-demo`.
5. State in the PR that no direct Kubernetes API action occurred.
6. Do not merge.
7. Do not alter settings, secrets, workflows, branch protection, or unrelated files.

Return the branch, commit SHA, pull-request number, and URL.
