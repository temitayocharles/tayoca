# Recording Checklist

## Before the recording

- [ ] Use a dedicated Render project or workspace.
- [ ] Add a payment method off camera.
- [ ] Create the demo GitHub repository.
- [ ] Copy `render/render.yaml` into the repository.
- [ ] Verify that the n8n image is still available.
- [ ] Deploy once and confirm the entire flow works.
- [ ] Confirm the n8n version includes instance-level MCP workflow creation/editing.
- [ ] Confirm whether the recording will use ChatGPT Business or Codex.
- [ ] Enable ChatGPT developer mode if using ChatGPT Business/Enterprise/Edu.
- [ ] Connect Composio GitHub to only the demonstration repository.
- [ ] Create an optional Slack demo channel.
- [ ] Remove unrelated browser tabs, bookmarks, account names, and notifications.
- [ ] Clear terminal scrollback containing secrets.
- [ ] Turn off password-manager pop-up previews.
- [ ] Create a duplicate n8n demo project.
- [ ] Import the backup workflow but keep it inactive.
- [ ] Confirm `curl`, `jq`, and `python3` are installed.
- [ ] Rehearse the invalid-input tests.
- [ ] Confirm no real production Argo CD repository is targeted.

## Secrets never shown on camera

- Render API key
- n8n owner password
- n8n MCP access token
- ChatGPT custom-app credentials
- Composio session or API secrets
- GitHub access token
- Slack access token
- kubeconfig
- database password
- n8n encryption key

## Browser tabs

1. Render dashboard
2. Official Render n8n guide
3. Official n8n Docker image page
4. GitHub demo repository
5. n8n editor
6. n8n instance-level MCP settings
7. ChatGPT Business or Codex
8. Composio
9. GitHub pull request page
10. Optional Argo CD read-only application page

## Terminal windows

### Window 1: Render verification

```bash
cd render-n8n-mcp-kubernetes-teaching-pack
read -s RENDER_API_KEY
export RENDER_API_KEY
bash scripts/render-api-smoke-test.sh
```

### Window 2: n8n verification

```bash
export N8N_BASE_URL="https://YOUR-N8N-SERVICE.onrender.com"
bash scripts/n8n-smoke-test.sh
```

### Window 3: Workflow test

```bash
export N8N_WEBHOOK_URL="https://YOUR-N8N-SERVICE.onrender.com/webhook/kubernetes-gitops-request"
export N8N_WEBHOOK_TOKEN="REDACTED"
bash scripts/test-kubernetes-workflow.sh
```

## Recovery points

### Render deployment is slow

Use the previous successful deployment and explain the logs already captured.

### ChatGPT custom MCP app is unavailable

Switch immediately to the Codex path. Do not imply that Plus supports custom MCP apps.

### n8n MCP cannot create the workflow

Import `workflows/kubernetes-gitops-manifest-builder.json`, then use MCP to inspect and update it.

### Composio GitHub action fails

Create a GitHub draft pull request manually from the generated branch, explain that Composio supplies the same authenticated action, and show the failed tool response honestly.

### Kubernetes validation fails

Do not merge. Show the validation failure and fix the manifest in the pull request.
