#!/usr/bin/env bash
set -Eeuo pipefail

: "${N8N_WEBHOOK_URL:?Set N8N_WEBHOOK_URL to the production webhook URL}"

auth_args=()
if [[ -n "${N8N_WEBHOOK_TOKEN:-}" ]]; then
  auth_args=(-H "Authorization: Bearer ${N8N_WEBHOOK_TOKEN}")
fi

request() {
  local name="$1"
  local payload="$2"
  local expected_class="$3"
  local body_file
  local status

  body_file="$(mktemp)"
  status="$(
    curl -sS \
      --connect-timeout 10 \
      --max-time 45 \
      -o "$body_file" \
      -w '%{http_code}' \
      -X POST \
      -H 'Content-Type: application/json' \
      "${auth_args[@]}" \
      --data "$payload" \
      "$N8N_WEBHOOK_URL"
  )"

  printf '\n=== %s ===\n' "$name"
  printf 'HTTP %s\n' "$status"

  if command -v jq >/dev/null 2>&1; then
    jq . "$body_file" 2>/dev/null || cat "$body_file"
  else
    cat "$body_file"
  fi
  printf '\n'

  case "$expected_class" in
    success)
      [[ "$status" =~ ^2 ]]
      ;;
    reject)
      [[ "$status" =~ ^(4|5) ]] || grep -Eqi '"accepted"[[:space:]]*:[[:space:]]*false|"error"' "$body_file"
      ;;
    *)
      printf 'Unknown expected class: %s\n' "$expected_class" >&2
      rm -f "$body_file"
      return 2
      ;;
  esac

  rm -f "$body_file"
}

request \
  "valid request" \
  '{"app_name":"hello-mcp","image":"nginx:1.27-alpine","namespace":"mcp-demo","replicas":2,"container_port":80}' \
  success

request \
  "invalid Kubernetes name" \
  '{"app_name":"Hello_MCP","image":"nginx:1.27-alpine","namespace":"mcp-demo","replicas":2,"container_port":80}' \
  reject

request \
  "excessive replica request" \
  '{"app_name":"hello-mcp","image":"nginx:1.27-alpine","namespace":"mcp-demo","replicas":50,"container_port":80}' \
  reject

request \
  "unexpected command field" \
  '{"app_name":"hello-mcp","image":"nginx:1.27-alpine","namespace":"mcp-demo","replicas":2,"container_port":80,"command":"kubectl delete namespace production"}' \
  reject
