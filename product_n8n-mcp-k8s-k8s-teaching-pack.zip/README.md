# From Zero to AI-Driven Kubernetes GitOps

## Deploy n8n on Render, connect MCP to ChatGPT, and use Composio to ship a Kubernetes workflow

This pack is designed for a complete, hands-on teaching session rather than a narrow n8n demonstration.

## Final lesson title

**Deploy Anything with AI: Render + n8n + MCP + ChatGPT + Composio + Kubernetes**

Alternative SEO title:

**How to Deploy n8n on Render and Control Kubernetes Workflows from ChatGPT with MCP**

Thumbnail text:

```text
DEPLOY WITH CHATGPT
RENDER + n8n + MCP
```

## What the audience will build

By the end of the session, the audience will have:

1. A Render account and a paid n8n deployment.
2. A Render Postgres database.
3. An API key for the Render API and Render MCP server.
4. An n8n instance running from the official `n8nio/n8n` container.
5. Render MCP connected to an AI client for infrastructure inspection.
6. n8n's instance-level MCP connected to ChatGPT Business or Codex.
7. Composio connected to GitHub and, optionally, Slack.
8. An AI-generated n8n workflow that validates a Kubernetes deployment request.
9. Kubernetes Deployment and Service manifests generated from the workflow.
10. A GitOps pull request created through Composio instead of direct cluster-admin access.

## The four MCP roles taught in this lesson

Do not describe all MCP connections as the same thing.

### 1. Render MCP

The AI client uses Render MCP to inspect Render services, logs, metrics, environment settings, and deploy status.

```text
ChatGPT or Codex -> Render MCP -> Render
```

### 2. n8n instance-level MCP

The AI client uses n8n's instance-level MCP to search, create, edit, validate, and execute n8n workflows.

```text
ChatGPT or Codex -> n8n instance-level MCP -> n8n workflows
```

### 3. n8n MCP Server Trigger

A specific n8n workflow can expose selected actions as MCP tools to other clients.

```text
MCP client -> n8n MCP Server Trigger -> selected workflow tools
```

This is an optional extension in the lesson, not the main workflow-building connection.

### 4. Composio MCP/tool layer

The AI client uses Composio to authenticate to GitHub and optional notification tools.

```text
ChatGPT or Codex -> Composio -> GitHub / Slack
```

## Why the Kubernetes action uses GitOps

The lesson does not give ChatGPT a cluster-admin kubeconfig.

The safer path is:

```text
User prompt
  -> ChatGPT
  -> n8n MCP builds or runs the manifest workflow
  -> validated Kubernetes YAML
  -> Composio GitHub creates a branch and pull request
  -> human review
  -> merge
  -> Argo CD applies the change
```

This teaches deployment automation while preserving review, auditability, rollback, and least privilege.

## Important platform constraint

Direct custom MCP apps in the ChatGPT web application require a ChatGPT Business or Enterprise/Edu workspace with developer mode enabled.

A personal ChatGPT Plus account cannot perform that exact custom-app setup.

This pack therefore contains two tracks:

- **Track A:** ChatGPT Business/Enterprise/Edu custom MCP app.
- **Track B:** OpenAI Codex MCP client as the reliable fallback.

The architecture and prompts are the same. Only the client configuration differs.

## Recommended duration

```text
Introduction and architecture             5 minutes
Render account, billing, and API key      7 minutes
Deploy n8n with Render Blueprint         12 minutes
Validate and harden n8n                   6 minutes
Connect Render MCP                        5 minutes
Connect n8n MCP                            8 minutes
Connect Composio GitHub                    6 minutes
Build Kubernetes workflow with AI        12 minutes
Generate manifests and open PR            8 minutes
Security recap                            5 minutes

Total                                     65–75 minutes
```

For a 40–45 minute version, create the Render account and GitHub repository before recording, then begin at the Blueprint deployment screen.

## Required accounts

- Render
- GitHub
- n8n self-hosted instance deployed during the lesson
- Composio
- ChatGPT Business/Enterprise/Edu, or Codex for the fallback
- Optional: Slack
- Optional: an Argo CD-managed Kubernetes test environment

## Files in this pack

```text
01-teleprompter-script.md
02-recording-checklist.md
render/render.yaml
render/manual-existing-image-deployment.md
scripts/render-api-smoke-test.sh
scripts/n8n-smoke-test.sh
scripts/test-kubernetes-workflow.sh
workflows/kubernetes-gitops-manifest-builder.json
workflows/WORKFLOW-SPEC.md
prompts/01-render-mcp-prompts.md
prompts/02-n8n-mcp-prompts.md
prompts/03-composio-github-prompts.md
prompts/04-combined-live-demo-prompt.md
docs/chatgpt-and-codex-connection-paths.md
docs/security-and-production-notes.md
docs/troubleshooting.md
docs/official-documentation.md
```

## Recommended recording strategy

Build and verify the entire system once before recording.

During the recording:

1. Create a separate demo Render workspace or project.
2. Never expose payment details, API keys, MCP tokens, cookies, or credentials.
3. Paste secrets from a password manager into masked fields.
4. Use the included importable n8n workflow as an emergency fallback.
5. Let ChatGPT create a fresh copy live, but compare it with the known-good workflow.
6. Use a test GitHub repository and test Kubernetes namespace.
7. Stop before merging the pull request into a production GitOps repository.

## Definition of done

The demonstration is complete when:

- Render reports the n8n service and database as available.
- The n8n login page loads.
- The Render API smoke test succeeds.
- The AI client can list the Render n8n service through Render MCP.
- The AI client can discover n8n workflow tools through n8n MCP.
- ChatGPT or Codex creates or updates the Kubernetes manifest-builder workflow.
- The workflow rejects unsafe input.
- The workflow returns valid Deployment and Service YAML.
- Composio creates a feature branch and pull request containing the manifests.
- No direct mutation is performed against the Kubernetes API.
