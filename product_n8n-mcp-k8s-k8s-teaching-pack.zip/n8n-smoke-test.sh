#!/usr/bin/env bash
set -Eeuo pipefail

: "${N8N_BASE_URL:?Set N8N_BASE_URL, for example https://your-service.onrender.com}"

base="${N8N_BASE_URL%/}"

check() {
  local label="$1"
  local path="$2"
  local expected="$3"
  local code

  code="$(
    curl -sS \
      --connect-timeout 10 \
      --max-time 30 \
      -o /dev/null \
      -w '%{http_code}' \
      "${base}${path}"
  )"

  printf '%-28s HTTP %s\n' "$label" "$code"

  if [[ ! "$code" =~ $expected ]]; then
    printf 'Unexpected status for %s\n' "$label" >&2
    return 1
  fi
}

check "n8n health" "/healthz" '^(200)$'
check "n8n editor/login" "/" '^(200|302)$'

printf '\nExpected instance-level MCP endpoint:\n'
printf '%s\n' "${base}/mcp-server/http"
printf '\nThe MCP endpoint may require authentication and is not probed anonymously.\n'
