# n8n MCP Prompts

## Tool discovery

```text
Using only the n8n MCP connection, list the available workflow-management tools.
Group them into search, inspect, validate, create, update, execute, and data-table tools.
Do not create or modify anything.
```

## Build the workflow

```text
Use the n8n MCP tools to create a workflow named
"Kubernetes GitOps Manifest Builder - Teaching Lab".

Requirements:
1. Start with a POST Webhook at path kubernetes-gitops-request.
2. Require header authentication if the current MCP tools support configuring it.
3. Accept only app_name, image, namespace, replicas, and container_port.
4. Reject unknown top-level fields.
5. Validate app_name and namespace against Kubernetes DNS-label rules.
6. Require replicas to be an integer from 1 through 5.
7. Require container_port to be an integer from 1 through 65535.
8. Generate a Kubernetes Deployment and ClusterIP Service.
9. Use standard app.kubernetes.io labels.
10. Disable service-account token automount.
11. Add RuntimeDefault seccomp, drop all Linux capabilities, and disallow privilege escalation.
12. Add conservative CPU and memory requests and limits.
13. Add readiness and liveness probes.
14. Return a JSON object with a summary and a files array.
15. Each file must contain path and content.
16. Do not use Execute Command, SSH, kubectl, a kubeconfig, or arbitrary HTTP requests.
17. Validate the workflow after creation.
18. Fix all structural validation errors and validate again.
19. Leave the workflow inactive until I approve it.
20. Report the created workflow ID, node names, validation result, and any assumptions.
```

## Audit the generated workflow

```text
Inspect the workflow "Kubernetes GitOps Manifest Builder - Teaching Lab".

Verify:
- the webhook is POST;
- unknown fields are rejected;
- Kubernetes names are validated;
- replica and port ranges are bounded;
- no shell, SSH, arbitrary URL, or cluster-access node exists;
- generated resources are only Deployment and ClusterIP Service;
- output contains exact paths and file contents;
- the workflow is inactive.

Report deviations. Do not change anything.
```

## Apply narrowly scoped corrections

```text
Update only the workflow "Kubernetes GitOps Manifest Builder - Teaching Lab".

Correct the following verified issues:
<PASTE ISSUES>

Preserve all behavior not mentioned.
Do not activate the workflow.
Validate after the update and report the final result.
```

## Execute after approval

```text
Execute the approved workflow with this input:

{
  "app_name": "hello-mcp",
  "image": "nginx:1.27-alpine",
  "namespace": "mcp-demo",
  "replicas": 2,
  "container_port": 80
}

Return the complete output.
Do not invoke any other workflow and do not perform a cluster change.
```
