# ChatGPT and Codex Connection Paths

## Track A: ChatGPT Business / Enterprise / Edu

### Requirement

The ChatGPT web application requires a Business or Enterprise/Edu workspace for full custom MCP support and developer mode.

### High-level steps

1. Sign in to the correct workspace.
2. Enable developer mode according to the workspace plan.
3. Navigate to Apps and create a custom app.
4. Enter the MCP endpoint.
5. Choose the supported authentication mechanism.
6. Complete authorization.
7. Scan tools.
8. Save the app as a draft.
9. Test in a new conversation before publishing it.
10. Keep write-capable apps restricted to authorized users.

### Render app

```text
Name: Render Teaching Lab
Endpoint: https://mcp.render.com/mcp
Authentication: Render API key through the supported secure auth field
```

### n8n app

```text
Name: n8n Teaching Lab
Endpoint: https://YOUR-N8N-SERVICE.onrender.com/mcp-server/http
Authentication: Prefer OAuth; otherwise use the n8n-supported secure access-token method
```

Do not paste tokens into prompts.

## Track B: Codex fallback

### n8n OAuth command

```bash
codex mcp add n8n-teaching \
  --url https://YOUR-N8N-SERVICE.onrender.com/mcp-server/http
```

Complete the browser authorization flow.

### n8n access-token configuration

Add to the Codex MCP configuration:

```toml
[mcp_servers.n8n-teaching]
url = "https://YOUR-N8N-SERVICE.onrender.com/mcp-server/http"
http_headers = { "authorization" = "Bearer <N8N_MCP_TOKEN>" }
```

Store the real configuration outside source control and set restrictive file permissions.

### Render hosted MCP configuration

```toml
[mcp_servers.render]
url = "https://mcp.render.com/mcp"
http_headers = { "Authorization" = "Bearer <RENDER_API_KEY>" }
```

### Verification prompts

```text
List the available Render workspaces and services. Do not modify anything.
```

```text
List the n8n workflow-management tools. Do not create or modify anything.
```

## Do not claim

- that personal ChatGPT Plus supports direct custom MCP apps;
- that a prompt restriction replaces tool permissions;
- that a token pasted in chat remains secret;
- that all MCP clients support the same authentication methods;
- that discovering a tool means the tool is safe to call.
