# Workflow Specification

## Name

```text
Kubernetes GitOps Manifest Builder - Teaching Lab
```

## Purpose

Accept a constrained deployment request and return Kubernetes manifest files for GitOps review.

## Input schema

```json
{
  "app_name": "hello-mcp",
  "image": "nginx:1.27-alpine",
  "namespace": "mcp-demo",
  "replicas": 2,
  "container_port": 80
}
```

## Validation

- Reject unknown top-level fields.
- `app_name` must be a Kubernetes DNS label.
- `namespace` must be a Kubernetes DNS label.
- `image` must be non-empty and contain no whitespace.
- `replicas` must be an integer from 1 through 5.
- `container_port` must be an integer from 1 through 65535.

## Output

```json
{
  "accepted": true,
  "summary": {
    "app_name": "hello-mcp",
    "image": "nginx:1.27-alpine",
    "namespace": "mcp-demo",
    "replicas": 2,
    "container_port": 80,
    "direct_cluster_change": false
  },
  "files": [
    {
      "path": "apps/hello-mcp/deployment.yaml",
      "content": "..."
    },
    {
      "path": "apps/hello-mcp/service.yaml",
      "content": "..."
    }
  ]
}
```

## Deliberate exclusions

The workflow must not:

- run `kubectl`;
- receive a kubeconfig;
- execute shell commands;
- create a cluster;
- delete resources;
- change GitHub settings;
- merge a pull request;
- call an arbitrary user-supplied URL.

## Follow-up production validations

Run generated files through:

```bash
kubeconform -strict -summary apps/hello-mcp/*.yaml
conftest test apps/hello-mcp
```

Apply repository policy and CI before merge.
