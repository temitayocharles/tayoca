# Manual Existing-Image Deployment

Use this route when you want to demonstrate the Render dashboard instead of a Blueprint.

## 1. Create PostgreSQL first

Create a Render Postgres database in the same region as n8n.

Recommended teaching baseline:

```text
Name: n8n-teaching-db
Plan: basic-256mb or larger
Database: n8n
User: n8n
```

Do not display the password.

## 2. Create the web service

In Render:

```text
New -> Web Service -> Existing Image
```

Image:

```text
docker.io/n8nio/n8n:latest
```

Use a paid instance that can reliably run the live lesson. Render's official guide recommends `standard` or larger.

## 3. Environment variables

```text
PORT=5678
DB_TYPE=postgresdb
DB_POSTGRESDB_DATABASE=<Render database name>
DB_POSTGRESDB_HOST=<Render internal database host>
DB_POSTGRESDB_PASSWORD=<Render database password>
DB_POSTGRESDB_USER=<Render database user>
N8N_ENCRYPTION_KEY=<generate 32+ random bytes and preserve permanently>
GENERIC_TIMEZONE=America/Toronto
TZ=America/Toronto
N8N_LOG_LEVEL=info
N8N_DIAGNOSTICS_ENABLED=false
N8N_PERSONALIZATION_ENABLED=false
```

Generate the encryption key locally:

```bash
openssl rand -hex 32
```

Store it directly in Render's secret environment field.

## 4. Deploy and add WEBHOOK_URL

After Render assigns the public URL, add:

```text
WEBHOOK_URL=https://YOUR-N8N-SERVICE.onrender.com/
```

Save and deploy.

## 5. Pin the image after testing

Replace `latest` with a tested version tag or immutable digest.
