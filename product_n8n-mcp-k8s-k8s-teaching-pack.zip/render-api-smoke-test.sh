#!/usr/bin/env bash
set -Eeuo pipefail

: "${RENDER_API_KEY:?Set RENDER_API_KEY without printing it. Example: read -s RENDER_API_KEY; export RENDER_API_KEY}"

API_URL="${RENDER_API_URL:-https://api.render.com/v1/services?limit=20}"

tmp="$(mktemp)"
trap 'rm -f "$tmp"' EXIT

status="$(
  curl -sS \
    --connect-timeout 10 \
    --max-time 30 \
    -o "$tmp" \
    -w '%{http_code}' \
    -H 'Accept: application/json' \
    -H "Authorization: Bearer ${RENDER_API_KEY}" \
    "$API_URL"
)"

if [[ "$status" != "200" ]]; then
  printf 'Render API request failed with HTTP %s\n' "$status" >&2
  cat "$tmp" >&2
  exit 1
fi

printf 'Render API authentication succeeded.\n'

if command -v jq >/dev/null 2>&1; then
  jq -r '
    .[]
    | [
        (.service.name // "unknown"),
        (.service.type // "unknown"),
        (.service.serviceDetails.url // "no-public-url")
      ]
    | @tsv
  ' "$tmp" | column -t -s $'\t'
else
  python3 - "$tmp" <<'PY'
import json, sys
with open(sys.argv[1], encoding="utf-8") as f:
    data = json.load(f)
for item in data:
    service = item.get("service", {})
    details = service.get("serviceDetails", {}) or {}
    print(
        f'{service.get("name", "unknown")}\t'
        f'{service.get("type", "unknown")}\t'
        f'{details.get("url", "no-public-url")}'
    )
PY
fi
