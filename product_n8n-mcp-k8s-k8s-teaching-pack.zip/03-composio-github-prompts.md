# Composio GitHub and Slack Prompts

## Confirm connection scope

```text
Using Composio, identify the connected GitHub account and the repositories it can access.
Do not read repository contents yet.
Do not change authentication, organization settings, collaborators, webhooks, secrets,
Actions settings, branch protection, or repository visibility.
```

## Create the GitOps pull request

```text
Use the connected Composio GitHub tools.

Target repository:
<OWNER>/<REPOSITORY>

Use these files returned by the approved n8n workflow:
<PASTE OR REFERENCE THE WORKFLOW OUTPUT>

Actions:
1. Confirm that every path begins with apps/hello-mcp/.
2. Confirm that only deployment.yaml and service.yaml are present.
3. Create branch demo/hello-mcp from the current main branch.
4. Write each file to its exact returned path.
5. Open a pull request targeting main.
6. Set the title to "Deploy hello-mcp to mcp-demo".
7. Include image, replicas, port, generated file list, and validation summary in the body.
8. State that no Kubernetes API call has been made.
9. Do not merge.
10. Do not modify repository settings, secrets, workflows, branch protection, or other files.

Return the branch name, commit SHA, pull-request number, and pull-request URL.
```

## Optional Slack notification

```text
Using the connected Composio Slack tools, send one message to:
<DEMO CHANNEL>

Message requirements:
- include the GitHub pull-request title and URL;
- include repository and branch;
- state that human review is required;
- state that the change has not been deployed;
- do not mention or expose tokens, internal credentials, or MCP endpoints.

Do not send to any other channel or direct message.
```
