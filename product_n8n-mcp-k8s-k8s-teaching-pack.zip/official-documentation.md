# Official Documentation

These were the primary sources used to construct the lesson. Recheck them on the recording date because product interfaces and capabilities can change.

## Render

- Deploy n8n on Render  
  https://render.com/docs/deploy-n8n

- Deploy a prebuilt Docker image  
  https://render.com/docs/deploying-an-image

- Render REST API overview and API keys  
  https://render.com/docs/api

- Render MCP server  
  https://render.com/docs/mcp-server

- Official Render n8n template  
  https://github.com/render-examples/n8n

- Render pricing  
  https://render.com/pricing

## n8n

- Connect to n8n instance-level MCP  
  https://docs.n8n.io/connect/connect-to-n8n-mcp-server

- Use n8n MCP server to build workflows  
  https://docs.n8n.io/build/ways-of-building-workflows/connect-to-n8n-mcp-server

- MCP Server Trigger  
  https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-langchain.mcptrigger

- MCP Client Tool  
  https://docs.n8n.io/integrations/builtin/cluster-nodes/sub-nodes/n8n-nodes-langchain.toolmcp

- Webhook node  
  https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-base.webhook

- n8n API authentication  
  https://docs.n8n.io/connect/n8n-api/authentication

## OpenAI / ChatGPT

- Developer mode and MCP apps in ChatGPT  
  https://help.openai.com/en/articles/12584461-developer-mode-and-mcp-apps-in-chatgpt

- Apps in ChatGPT  
  https://help.openai.com/en/articles/11487775-connectors-in-chatgpt

## Composio

- Composio documentation  
  https://docs.composio.dev/

- Composio toolkits  
  https://docs.composio.dev/toolkits

Review the current GitHub toolkit actions and requested OAuth scopes in Composio before recording.

## Kubernetes validation tools

- kubeconform  
  https://github.com/yannh/kubeconform

- Conftest  
  https://www.conftest.dev/

- Argo CD documentation  
  https://argo-cd.readthedocs.io/
