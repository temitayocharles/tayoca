# Teleprompter Script

## Deploy Anything with AI: Render + n8n + MCP + ChatGPT + Composio + Kubernetes

### 0:00–1:30 — Opening

[CAMERA]

Today, I am not going to show you another AI automation that only works inside a prepared demo.

We are starting from zero.

We will create a Render account, choose the infrastructure for a reliable n8n deployment, verify the official n8n container, deploy it with PostgreSQL, create a Render API key, connect Render through MCP, expose n8n to an AI client through its own MCP server, connect GitHub through Composio, and then ask the AI to build a Kubernetes deployment workflow.

At the end, a plain-English request will become validated Kubernetes YAML and a reviewable GitHub pull request.

The important word is reviewable.

I will not give an AI model unrestricted cluster-admin access.

We will use GitOps so that the AI can prepare a change, a human can review it, and Argo CD can apply it after approval.

[ON SCREEN]

```text
PROMPT -> WORKFLOW -> KUBERNETES YAML -> PULL REQUEST -> ARGO CD
```

### 1:30–3:30 — Explain the architecture

[SHOW ARCHITECTURE DIAGRAM]

There are four separate connections in this lesson.

First, Render MCP allows the AI client to inspect and operate supported Render resources.

Second, n8n's instance-level MCP lets the AI client create, edit, validate, and run n8n workflows.

Third, Composio gives the AI client authenticated tools such as GitHub and Slack.

Fourth, GitOps is the deployment boundary between the AI-generated change and the Kubernetes cluster.

This distinction matters.

MCP is the protocol that connects the AI to tools.

n8n is the workflow engine.

Render is the hosting platform.

Composio manages access to third-party applications.

GitHub carries the desired state.

Argo CD reconciles that desired state into Kubernetes.

[CAMERA]

One current limitation must be clear before we begin.

Direct custom MCP applications in the ChatGPT web interface require a ChatGPT Business or Enterprise or Education workspace with developer mode.

If you have that workspace, follow the ChatGPT path.

If you only have a personal Plus account, use the Codex path included in this lesson.

The lesson and prompts remain the same.

### 3:30–6:30 — Create the Render account and choose the right payment model

[SHOW RENDER SIGN-UP PAGE]

I will create or sign in to my Render account.

I am hiding personal and payment information from the recording.

An important distinction is that a Render workspace plan and a Render service instance are different things.

You do not need to buy a Pro workspace simply to prevent n8n from sleeping.

For this deployment, the relevant decision is to use paid compute for the n8n web service and paid PostgreSQL for durable storage.

The official Render n8n guide recommends the standard web-service instance or larger, and says the basic two-hundred-and-fifty-six-megabyte PostgreSQL plan is normally sufficient for the n8n database.

For a temporary learning lab you can begin on the free resources, but the free web service sleeps after inactivity and the free PostgreSQL database expires.

I do not want those limitations to interrupt a live MCP demonstration, so I am using paid instances.

[ON SCREEN]

```text
n8n web service: standard or larger
PostgreSQL: basic-256mb or larger
Region: choose the same region for both
```

### 6:30–8:30 — Verify the official n8n image

[SHOW DOCKER HUB OR OFFICIAL RENDER GUIDE]

Before deploying a container, verify the source.

The official image used by Render's own n8n deployment guide is:

```text
docker.io/n8nio/n8n:latest
```

For this first deployment, latest ensures that the instance-level MCP workflow-building features are present.

For production, I would test a specific version and pin the image to a version tag or digest.

Never deploy a similarly named community image merely because it appears first in search results.

### 8:30–11:30 — Show the Blueprint before deployment

[SHOW GITHUB REPOSITORY AND render.yaml]

I am using a Render Blueprint rather than clicking through two unrelated resources.

The Blueprint describes the n8n web service and the PostgreSQL database together.

The service runs the official n8n image.

The database connection fields are injected from the Render database.

The encryption key is generated once and must not be changed later, because n8n uses it to encrypt stored credentials.

Let us inspect the important lines.

[HIGHLIGHT]

```yaml
runtime: image
image:
  url: docker.io/n8nio/n8n:latest
```

[HIGHLIGHT]

```yaml
- key: N8N_ENCRYPTION_KEY
  generateValue: true
```

[HIGHLIGHT]

```yaml
- key: DB_TYPE
  value: postgresdb
```

[CAMERA]

Do not copy the generated encryption key into source control.

Do not rotate it casually.

A replacement key would make credentials encrypted with the old key unreadable.

### 11:30–15:00 — Deploy the Blueprint

[SHOW RENDER DASHBOARD]

From the Render dashboard, I select New and then Blueprint.

I connect the GitHub repository that contains this render.yaml file.

I confirm the branch and the two resources.

The web service and database must use the same region.

I then deploy the Blueprint.

[SHOW DEPLOYMENT LOGS]

While the deployment runs, notice the sequence.

Render provisions PostgreSQL.

It pulls the n8n container.

It injects the environment variables.

It starts n8n on port 5678.

And it exposes the web service behind a Render HTTPS address.

A green deployment does not automatically mean the application is correctly configured.

We will verify the application separately.

### 15:00–18:00 — Configure WEBHOOK_URL and initialize n8n

[SHOW RENDER SERVICE]

After the first deployment, I copy the public onrender.com address.

In the service environment settings, I add:

```text
WEBHOOK_URL=https://YOUR-N8N-SERVICE.onrender.com/
```

The trailing slash is intentional.

I save the setting and deploy again.

This variable ensures that n8n generates externally reachable webhook and MCP addresses instead of internal container addresses.

[SHOW N8N LOGIN PAGE]

Now I open the n8n service.

On first launch, I create the owner account.

I am not displaying the password.

For a production deployment, use a unique administrator password, multi-factor authentication where supported, and separate accounts for operators.

### 18:00–20:30 — Create and test the Render API key

[SHOW RENDER ACCOUNT SETTINGS]

Next, I create a Render API key.

I give it a purpose-specific name such as:

```text
teaching-render-mcp-2026-07
```

Render shows this secret once.

I copy it directly into my password manager.

I do not paste it into the terminal history, source code, slides, or chat.

[TERMINAL]

The included smoke-test script reads the token from an environment variable.

```bash
read -s RENDER_API_KEY
export RENDER_API_KEY
bash scripts/render-api-smoke-test.sh
unset RENDER_API_KEY
```

The script calls the Render API and lists services without printing the token.

If the request succeeds, the API key is valid.

### 20:30–24:00 — Connect Render MCP

[SHOW CHATGPT BUSINESS OR CODEX]

Render provides a hosted MCP endpoint:

```text
https://mcp.render.com/mcp
```

The connection uses the Render API key.

Be aware that a Render API key can have broad access to the services available to that user.

For a demonstration, use a dedicated Render workspace or project that contains no unrelated production infrastructure.

[CHATGPT BUSINESS PATH]

In a ChatGPT Business or Enterprise workspace, the administrator enables developer mode.

Then I create a custom app, provide the Render MCP endpoint, select the supported authentication mechanism, authorize it, scan the tools, and save the draft app.

[CODEX PATH]

With Codex, I add the hosted MCP server according to the client configuration and store the authorization header outside source control.

Now I test the connection with this prompt:

```text
List the Render services available to this workspace.
Identify the n8n web service and its PostgreSQL database.
Do not modify or redeploy anything.
```

The phrase do not modify anything is not the security boundary, but it makes the intended task explicit.

The actual security boundary is the credential scope and the available tools.

### 24:00–27:00 — Use Render MCP for a real verification

[SHOW AI RESPONSE]

Now I ask:

```text
Inspect the n8n service status and recent logs.
Report whether the container started successfully, whether port 5678 was detected,
and whether there are database connection errors.
Do not change environment variables or trigger a deployment.
```

This is where MCP becomes practical.

I am not copying logs into the chat manually.

The AI client is using an authenticated tool to retrieve the current state from Render.

If it reports a database error, I verify the database environment variables.

If it reports a port error, I verify that n8n is listening on 5678.

If it reports a redirect or webhook issue, I verify WEBHOOK_URL.

### 27:00–30:30 — Explain n8n's three MCP capabilities

[SHOW N8N SETTINGS AND WORKFLOW CANVAS]

n8n contains several MCP features, and they solve different problems.

The instance-level MCP server lets an external AI client build and manage n8n workflows.

The MCP Server Trigger turns a specific workflow into an MCP server with selected tools.

The MCP Client Tool lets an n8n AI Agent consume tools exposed by another MCP server.

Today, the main connection is the instance-level MCP server because I want ChatGPT to build a workflow inside n8n.

Later, I will briefly show how the finished workflow can itself become an MCP tool.

### 30:30–34:00 — Enable n8n instance-level MCP

[SHOW N8N SETTINGS]

Inside n8n, I open Settings and then the instance-level MCP settings.

I enable MCP access.

The endpoint follows this form:

```text
https://YOUR-N8N-SERVICE.onrender.com/mcp-server/http
```

n8n supports OAuth or a personal MCP access token.

For ChatGPT, prefer the OAuth path when the current n8n and ChatGPT configuration supports it.

For a local Codex demonstration, an access token is also supported.

If I generate an access token, n8n displays it once.

I save it directly into a secure credential store.

All clients connected under the same n8n user can see the workflows that user has enabled for MCP access.

That means I should use a dedicated n8n account and a dedicated project for this lesson.

### 34:00–37:00 — Connect the n8n MCP server

[CHATGPT BUSINESS]

I create another custom MCP app named:

```text
n8n Teaching Lab
```

I use the n8n MCP endpoint, complete authentication, scan the tools, and save the draft.

[CODEX]

The Codex command using OAuth is:

```bash
codex mcp add n8n-teaching \
  --url https://YOUR-N8N-SERVICE.onrender.com/mcp-server/http
```

For token-based configuration, I add the endpoint and authorization header to the Codex MCP configuration without committing the token.

Now I test discovery.

[PROMPT]

```text
Using the n8n MCP connection, list the workflow-management tools you can access.
Do not create or modify a workflow yet.
Summarize which tools can search, inspect, validate, create, update, and execute workflows.
```

If the client cannot discover tools, I stop here and fix authentication before attempting the live build.

### 37:00–40:00 — Connect Composio to GitHub

[SHOW COMPOSIO]

Now I connect Composio.

Composio is not replacing n8n.

It gives the AI client authenticated tools for third-party systems.

For this lesson, I connect GitHub.

Optionally, I also connect Slack so that a pull-request notification can be sent after creation.

I authorize a test GitHub account or organization.

I grant access only to the demonstration repository.

I do not use a token with organization-wide administrative privileges.

[ON SCREEN]

```text
Composio GitHub purpose:
- create a feature branch
- write generated manifest files
- open a pull request
- optionally add a comment

Composio Slack purpose:
- send a deployment-review notification
```

### 40:00–43:00 — Describe the Kubernetes workflow before asking AI to build it

[SHOW WORKFLOW SPEC]

Before asking AI to create anything, define the contract.

The workflow receives:

```json
{
  "app_name": "hello-mcp",
  "image": "nginx:1.27-alpine",
  "namespace": "mcp-demo",
  "replicas": 2,
  "container_port": 80
}
```

It must validate every field.

The application and namespace names must be valid Kubernetes DNS labels.

The image cannot be blank.

Replica count must be between one and five for this demonstration.

The port must be between one and 65535.

The workflow then returns two files:

```text
apps/hello-mcp/deployment.yaml
apps/hello-mcp/service.yaml
```

It must not run kubectl.

It must not receive a kubeconfig.

It must not apply resources directly.

### 43:00–49:00 — Ask ChatGPT to build the workflow through n8n MCP

[SHOW CHATGPT WITH N8N APP ENABLED]

I now use the included master prompt.

[PROMPT]

```text
Use the n8n MCP tools to create a workflow named
"Kubernetes GitOps Manifest Builder - Teaching Lab".

Requirements:
1. Start with a POST Webhook at path kubernetes-gitops-request.
2. Require header authentication if the current MCP tools support configuring it.
3. Validate app_name, image, namespace, replicas, and container_port in a Code node.
4. app_name and namespace must match Kubernetes DNS-label rules.
5. replicas must be an integer from 1 through 5.
6. container_port must be an integer from 1 through 65535.
7. Reject unknown top-level input fields.
8. Generate a Kubernetes Deployment and ClusterIP Service.
9. Add recommended labels, resource requests and limits, readiness and liveness probes,
   securityContext, and a non-root-compatible default where the selected image permits it.
10. Do not run kubectl, do not access a cluster, and do not add shell execution.
11. Return an object containing a summary and a files array with path and content.
12. Validate the completed workflow, report any validation errors, fix them, and validate again.
13. Do not activate the workflow until I approve its final structure.
```

[PAUSE WHILE TOOLS RUN]

Notice that the AI is not merely writing JSON in the chat.

It is using n8n's MCP tools to create nodes and connections inside the deployed instance.

When it finishes, I open n8n and inspect the workflow visually.

### 49:00–53:00 — Review the AI-generated workflow

[SHOW N8N CANVAS]

I check five things before activation.

First, the trigger is a POST webhook.

Second, validation occurs before manifest generation.

Third, unknown fields are rejected.

Fourth, no Execute Command or SSH node exists.

Fifth, the workflow only returns files; it does not mutate Kubernetes.

I also inspect the generated code.

An AI-created workflow is not trusted merely because the platform says it is valid.

Validation means the workflow structure is acceptable to n8n.

It does not prove that the business logic or security controls are correct.

If the live generation fails, I import the known-good backup workflow included with this teaching pack and explain the difference between an AI draft and a tested artifact.

### 53:00–56:00 — Test valid and invalid requests

[TERMINAL]

I publish the workflow only after review.

Then I export the webhook URL into a variable:

```bash
export N8N_WEBHOOK_URL="https://YOUR-N8N-SERVICE.onrender.com/webhook/kubernetes-gitops-request"
```

I run:

```bash
bash scripts/test-kubernetes-workflow.sh
```

The script sends a valid request and several invalid requests.

The valid request should return Deployment and Service YAML.

The unsafe request with an invalid application name should fail.

The excessive replica request should fail.

The request containing an unexpected command field should fail.

The purpose is not only to prove that the happy path works.

The purpose is to prove that unsafe inputs are rejected.

### 56:00–61:00 — Use Composio to open the GitOps pull request

[SHOW CHATGPT WITH N8N AND COMPOSIO TOOLS]

Now I combine the tools.

I ask ChatGPT to execute the approved n8n workflow with the demo input.

Then I ask it to use the Composio GitHub tools to create a feature branch, write the two returned files, and open a pull request.

[PROMPT]

```text
Use the approved n8n workflow to generate Kubernetes manifests for:

app_name: hello-mcp
image: nginx:1.27-alpine
namespace: mcp-demo
replicas: 2
container_port: 80

Review the returned file paths and YAML for obvious errors.

Then use the connected Composio GitHub tools against the repository I specify:
1. Create a branch named demo/hello-mcp.
2. Write each returned file to its exact path.
3. Open a pull request to main.
4. Use the title "Deploy hello-mcp to mcp-demo".
5. In the body, summarize the image, replicas, port, generated files, validation performed,
   and state clearly that the pull request has not been applied to a cluster.
6. Do not merge the pull request.
7. Do not modify repository settings, secrets, workflows, or branch protection.
```

[SHOW GITHUB PULL REQUEST]

This is the deployment handoff.

The AI prepared the change.

GitHub records the diff.

A human can review it.

A policy engine and CI pipeline can validate it.

Only after merge does Argo CD reconcile it into the Kubernetes cluster.

### 61:00–63:30 — Optional Slack notification

[SHOW COMPOSIO SLACK]

If Slack is connected, I add:

```text
Send one message to the demo deployment-review channel.
Include the pull-request title, repository, branch, and URL.
State that human review is required and that nothing has been deployed yet.
Do not notify any other channel.
```

This is a good example of why Composio is useful.

The same AI conversation can use n8n for workflow management, GitHub for GitOps, and Slack for communication, while each system keeps its own authentication boundary.

### 63:30–66:00 — Optional: expose the workflow as an MCP tool

[SHOW N8N MCP SERVER TRIGGER]

The instance-level MCP connection allowed the AI to build n8n workflows.

Now I can demonstrate the opposite direction.

I can create an MCP Server Trigger workflow and attach the approved manifest-builder workflow as a narrowly defined tool.

An external client would then see a tool such as:

```text
generate_kubernetes_gitops_manifests
```

I would protect the production MCP URL with OAuth or bearer authentication.

I would expose only this approved workflow, not every workflow in the instance.

That is how n8n can be both an MCP client and an MCP server.

### 66:00–69:00 — Production cautions

[CAMERA]

This demonstration is intentionally safer than direct autonomous deployment, but it is not the final production design.

For production I would add:

- a dedicated Render workspace and least-privilege operators;
- pinned container digests;
- backups and database recovery testing;
- custom domains and access controls;
- n8n project separation;
- token rotation;
- execution-data retention rules;
- rate and concurrency limits;
- signed commits or a GitHub App;
- schema validation;
- policy checks with Kyverno, OPA, Conftest, or kubeconform;
- image signature and vulnerability checks;
- branch protection;
- mandatory pull-request approval;
- Argo CD project restrictions;
- namespace quotas;
- and full audit logging.

I would not expose a generic shell tool, arbitrary HTTP client, unrestricted GitHub token, or cluster-admin kubeconfig to an AI agent.

### 69:00–70:30 — Closing

[CAMERA]

Let us recap what we built.

Render hosted the official n8n container and PostgreSQL database.

Render MCP allowed the AI to inspect the hosting environment.

n8n MCP allowed the AI to create and validate a workflow.

Composio connected the AI to GitHub and optional notifications.

The workflow generated Kubernetes manifests from validated input.

GitOps converted those files into a controlled deployment proposal.

And a human remained between the AI-generated change and the cluster.

That is the lesson.

MCP makes tools reachable.

Good architecture decides which tools should be reachable, what they are allowed to do, and where human approval belongs.
