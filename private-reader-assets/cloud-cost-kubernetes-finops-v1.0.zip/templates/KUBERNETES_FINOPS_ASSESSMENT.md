# Kubernetes FinOps Assessment

Score each control 0 (absent), 1 (partial), 2 (operational). Record evidence, owner and action.

| Domain | Control | Score | Evidence | Owner | Action |
|---|---|---:|---|---|---|
| Allocation | Namespaces/labels map workloads to teams/services | | | | |
| Allocation | Shared platform cost allocation rule documented | | | | |
| Requests | CPU requests compared with observed usage | | | | |
| Requests | Memory requests compared with observed usage | | | | |
| Limits | Limits reviewed for throttling/OOM risk | | | | |
| Autoscaling | HPA targets match demand signals | | | | |
| Autoscaling | VPA recommendations reviewed where appropriate | | | | |
| Nodes | Node utilization and stranded capacity measured | | | | |
| Nodes | Instance diversification/architecture suitability reviewed | | | | |
| Capacity | Spot interruption tolerance assessed per workload | | | | |
| Storage | PV size, class, age and attachment status reviewed | | | | |
| Cost data | OpenCost/Kubecost-equivalent allocation data available | | | | |
| Governance | Idle and unallocated cost have owners and thresholds | | | | |
| Validation | Performance/SLO checks required after rightsizing | | | | |
