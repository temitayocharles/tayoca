# Post-change Validation Checklist

## Before
- [ ] Baseline period and normalization factors recorded.
- [ ] Expected saving is labelled estimated, not realized.
- [ ] SLOs, latency, error rate, saturation and capacity headroom captured.
- [ ] Security/compliance constraints recorded.
- [ ] Rollback trigger and rollback owner defined.

## After
- [ ] Change reached intended resources only.
- [ ] Reliability and performance stayed within agreed thresholds.
- [ ] No new throttling, OOM, queueing, storage or network errors appeared.
- [ ] Cost data has enough post-change time to be comparable.
- [ ] Cost is normalized for traffic, seasonality and one-time charges.
- [ ] Realized saving calculated and evidence linked.
- [ ] Recommendation status updated: realized / partial / rejected / rolled back.
- [ ] New baseline recorded.
