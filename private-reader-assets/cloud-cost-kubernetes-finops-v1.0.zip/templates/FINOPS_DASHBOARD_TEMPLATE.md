# FinOps Dashboard Template

## Executive KPIs

| Metric | Formula / source | Current | Target | Trend | Owner |
|---|---|---:|---:|---|---|
| Monthly amortized cost | CUR 2.0 / cost dashboard | | | | |
| Forecast variance | (actual - forecast) / forecast | | | | |
| Allocation coverage | allocated cost / total eligible cost | | | | |
| Commitment coverage | eligible usage covered / eligible usage | | | | |
| Commitment utilization | used commitment / purchased commitment | | | | |
| Idle/unallocated Kubernetes cost | OpenCost idle + unallocated / cluster cost | | | | |
| Realized savings | validated baseline - post-change normalized cost | | | | |
| Optimization backlog value | sum of validated candidate monthly savings | | | | |

## Engineering panels
- Top cost movers by service, account, team and environment.
- Cost Optimization Hub opportunities by action and estimated monthly savings.
- EC2/ASG rightsizing candidates with CPU/memory headroom and risk class.
- Kubernetes requests vs usage by namespace/workload.
- Storage growth, lifecycle coverage and unattached-volume inventory.
- NAT/data-transfer cost by route and workload.
- Anomalies opened, owned, resolved and false-positive rate.

**Rule:** Never report recommendation savings as realized savings until post-change measurement passes.
