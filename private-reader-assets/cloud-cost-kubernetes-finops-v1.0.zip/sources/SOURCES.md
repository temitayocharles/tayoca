# Source & Version Notes

Research snapshot: 2026-08-28. Re-check service behavior before making production changes.

- AWS Cost Optimization Hub: https://docs.aws.amazon.com/cost-management/latest/userguide/cost-optimization-hub.html
- Cost Optimization Hub strategies: https://docs.aws.amazon.com/cost-management/latest/userguide/coh-optimization-strategies.html
- AWS Savings Plans: https://docs.aws.amazon.com/savingsplans/latest/userguide/what-is-savings-plans.html
- AWS Data Exports / CUR 2.0: https://docs.aws.amazon.com/cur/latest/userguide/what-is-data-exports.html
- CUR 2.0 migration: https://docs.aws.amazon.com/cur/latest/userguide/dataexports-migrate.html
- S3 Intelligent-Tiering: https://docs.aws.amazon.com/AmazonS3/latest/userguide/intelligent-tiering-overview.html
- OpenCost specification: https://opencost.io/docs/specification/
- Terraform AWS provider resources used by snippets: https://registry.terraform.io/providers/hashicorp/aws/latest/docs
- Terraform Kubernetes provider: https://registry.terraform.io/providers/hashicorp/kubernetes/latest/docs
- Terraform Helm provider: https://registry.terraform.io/providers/hashicorp/helm/latest/docs

The snippets are teaching/reference patterns. Review provider versions, account topology, IAM, regions, service quotas, organizational policy and workload SLOs before use.
