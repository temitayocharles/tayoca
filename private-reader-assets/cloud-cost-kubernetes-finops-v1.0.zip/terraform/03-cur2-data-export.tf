data "aws_caller_identity" "current" {}
data "aws_partition" "current" {}

resource "aws_s3_bucket" "finops_exports" {
  bucket_prefix = "finops-cur2-"
}

resource "aws_bcmdataexports_export" "cur2" {
  export {
    name = "finops-cur2"
    data_query {
      query_statement = "SELECT identity_line_item_id, identity_time_interval, line_item_product_code, line_item_unblended_cost FROM COST_AND_USAGE_REPORT"
      table_configurations = {
        COST_AND_USAGE_REPORT = {
          BILLING_VIEW_ARN                   = "arn:${data.aws_partition.current.partition}:billing::${data.aws_caller_identity.current.account_id}:billingview/primary"
          TIME_GRANULARITY                   = "DAILY"
          INCLUDE_RESOURCES                  = "TRUE"
          INCLUDE_SPLIT_COST_ALLOCATION_DATA = "TRUE"
        }
      }
    }
    destination_configurations {
      s3_destination {
        s3_bucket = aws_s3_bucket.finops_exports.bucket
        s3_prefix = "cur2"
        s3_region = "us-east-1"
        s3_output_configurations {
          compression = "GZIP"
          format      = "TEXT_OR_CSV"
          output_type = "CUSTOM"
          overwrite   = "CREATE_NEW_REPORT"
        }
      }
    }
    refresh_cadence { frequency = "SYNCHRONOUS" }
  }
}
