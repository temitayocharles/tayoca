variable "db_subnet_group_name" { type = string }
variable "security_group_ids" { type = list(string) }

resource "aws_db_instance" "example" {
  identifier              = "finops-example"
  engine                  = "postgres"
  instance_class          = "db.t4g.medium"
  allocated_storage       = 20
  max_allocated_storage   = 100
  storage_type            = "gp3"
  db_subnet_group_name    = var.db_subnet_group_name
  vpc_security_group_ids  = var.security_group_ids
  deletion_protection     = true
  backup_retention_period = 7
  storage_encrypted       = true
  skip_final_snapshot     = false
  username                = "finops_admin"
  manage_master_user_password = true
}
