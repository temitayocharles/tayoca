variable "subnet_ids" { type = list(string) }
variable "launch_template_id" { type = string }

resource "aws_autoscaling_group" "cost_aware" {
  min_size            = 2
  desired_capacity    = 4
  max_size            = 12
  capacity_rebalance  = true
  vpc_zone_identifier = var.subnet_ids

  mixed_instances_policy {
    instances_distribution {
      on_demand_base_capacity                  = 2
      on_demand_percentage_above_base_capacity = 25
      spot_allocation_strategy                 = "price-capacity-optimized"
    }
    launch_template {
      launch_template_specification {
        launch_template_id = var.launch_template_id
        version            = "$Latest"
      }
      override { instance_type = "m7g.large" }
      override { instance_type = "m7g.xlarge" }
      override { instance_type = "m6g.large" }
    }
  }
}
