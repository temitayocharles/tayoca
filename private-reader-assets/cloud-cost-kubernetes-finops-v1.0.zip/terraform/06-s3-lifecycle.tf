variable "bucket_id" { type = string }

resource "aws_s3_bucket_lifecycle_configuration" "cost_aware" {
  bucket = var.bucket_id
  rule {
    id     = "tier-and-expire-noncurrent"
    status = "Enabled"
    filter {}
    transition { days = 30 storage_class = "INTELLIGENT_TIERING" }
    noncurrent_version_transition { noncurrent_days = 30 storage_class = "STANDARD_IA" }
    noncurrent_version_expiration { noncurrent_days = 180 }
  }
}
