resource "kubernetes_limit_range" "defaults" {
  metadata {
    name      = "cost-aware-defaults"
    namespace = "default"
  }
  spec {
    limit {
      type = "Container"
      default_request = { cpu = "100m", memory = "128Mi" }
      default         = { cpu = "500m", memory = "512Mi" }
      max             = { cpu = "2", memory = "2Gi" }
    }
  }
}
