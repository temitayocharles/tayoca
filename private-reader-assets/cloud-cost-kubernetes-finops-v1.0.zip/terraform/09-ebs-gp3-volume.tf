variable "availability_zone" { type = string }
variable "size_gib" { type = number default = 100 }

resource "aws_ebs_volume" "gp3" {
  availability_zone = var.availability_zone
  type              = "gp3"
  size              = var.size_gib
  iops              = 3000
  throughput        = 125
  encrypted         = true
  tags = { Name = "cost-aware-gp3" }
}
