resource "helm_release" "opencost" {
  name       = "opencost"
  repository = "https://opencost.github.io/opencost-helm-chart"
  chart      = "opencost"
  namespace  = "opencost"
  create_namespace = true

  set = [
    { name = "opencost.exporter.defaultClusterId", value = "production" },
    { name = "opencost.ui.enabled", value = "true" }
  ]
}
