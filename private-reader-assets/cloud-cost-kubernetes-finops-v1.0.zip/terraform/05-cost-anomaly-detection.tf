variable "alert_email" { type = string }

resource "aws_ce_anomaly_monitor" "services" {
  name              = "service-cost-anomalies"
  monitor_type      = "DIMENSIONAL"
  monitor_dimension = "SERVICE"
}

resource "aws_ce_anomaly_subscription" "daily" {
  name      = "daily-cost-anomalies"
  frequency = "DAILY"
  monitor_arn_list = [aws_ce_anomaly_monitor.services.arn]
  threshold_expression {
    dimension {
      key           = "ANOMALY_TOTAL_IMPACT_ABSOLUTE"
      match_options = ["GREATER_THAN_OR_EQUAL"]
      values        = ["100"]
    }
  }
  subscriber {
    type    = "EMAIL"
    address = var.alert_email
  }
}
