Build, Break, Fix: DevOps Practice Lab Pack — Second Edition
By Temitayo Charles · Tayoca Books

Included:
- Build-Break-Fix_DevOps-Practice-Lab-Pack_v2.0.pdf — 100-page 7×10 customer edition
- cover-front-ebook.png — retail cover artwork
- labs/ — complete 13-area companion lab pack, solutions, templates, environment checker, and reset tooling

Start with labs/START-HERE.md. The labs intentionally contain broken configurations and teaching fixtures. No production credentials are included.
