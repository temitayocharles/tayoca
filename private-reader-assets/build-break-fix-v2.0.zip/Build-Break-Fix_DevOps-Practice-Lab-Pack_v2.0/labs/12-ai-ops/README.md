# Lab 12 — AI-Assisted Operations: Read-Only First

**Loop stage:** BUILD (a policy boundary) → BREAK (try to get past it)
**You will keep:** the rule — reads flow, mutations need a human, secrets never flow
through a model — and a working enforcement of it you can show in interviews.

## Objective

Use and attack a small policy engine that gates AI-suggested kubectl operations. Prove
that the interesting failures are refused (mutations, secrets, sneaky flags), that
allowed reads run, and that every decision lands in an audit log.

This lab needs NO cluster: `--selftest` and `--dry-run` exercise the policy engine
anywhere. With kubectl and the kind cluster present, reads execute for real.

## Prerequisites

python3 (stdlib only). kubectl + the kind cluster optional (live reads).

## Setup — expected working state

```bash
cd labs/12-ai-ops
python3 safe_kubectl_assistant.py --selftest      # 16/16 passed
python3 safe_kubectl_assistant.py get pods --dry-run
```

Success criteria: selftest all green; dry-run prints `kubectl get pods` without running
it; `.audit/bbf-ai-ops-audit.jsonl` now contains two decisions (check: `cat` it).

## Break — try to get past the gate (each attempt is the lab)

```bash
python3 safe_kubectl_assistant.py delete pod api-123        # mutation
python3 safe_kubectl_assistant.py apply -f evil.yaml        # mutation via file
python3 safe_kubectl_assistant.py get secret db-creds       # secret read
python3 safe_kubectl_assistant.py describe secret/api-token # secret, other verb
python3 safe_kubectl_assistant.py get pods --raw            # unusual flag
python3 safe_kubectl_assistant.py exec api-123 -- sh        # escape hatch?
```

All six must be REFUSED. Then find what IS allowed and ask why each is safe:
`get`, `describe`, `logs`, `top`, `explain`, `diff`.

## Investigate — evidence checklist

1. For each refusal: the exact `reason` string — which rule fired (mutating verb?
   secret marker? flag allowlist?).
2. Read `classify()` in the source: which check runs FIRST, and why that order matters
   (secrets before verbs — a secret *read* is worse to leak than a pod delete is to do).
3. Audit log: every attempt recorded? Find your own attack history:
   `grep '"verdict": "refuse"' .audit/bbf-ai-ops-audit.jsonl | wc -l`.
4. Attack the design, not just the inputs: how WOULD a malicious suggestion try to slip
   through? (Flag smuggling, `--namespace` tricks, `-o yaml` on sensitive objects,
   suggesting a shell one-liner instead of kubectl...) Note at least two gaps a fuller
   implementation should close — writing them down is senior-level thinking.

**Hypothesis gate:** *"The boundary holds because the engine decides based on ______
before looking at ______; the audit trail proves ______."*

Solutions: `labs/solutions/12-ai-ops.md`.

## Fix and prove recovery

There is nothing broken to repair — instead, tighten one gap you found in step 4 and
prove it: add a rule to `policy.json`, add a selftest case, re-run `--selftest`.
Green selftest with your new case = recovery proof.

## Reset

```bash
rm -rf .audit
```

## Prevention lesson

- Give tools (and models) the least privilege that completes the task: allowlist reads,
  gate mutations, block secret surface entirely.
- Boundaries must be enforced in code the model cannot talk its way past — the model
  proposes; the policy disposes.
- Audit logs turn "the AI did what?" into a reviewable history.

## Portfolio prompt

Show the six refusals, the audit log, and your two identified design gaps with patches.
This is a genuinely modern portfolio artifact — very few candidates can demonstrate a
working AI-ops safety boundary.

## Interview question

*"Your team wants to let an AI assistant operate Kubernetes. What would you allow it to
do on day one, what would you never allow, and how do you enforce that technically
rather than by prompt?"*
