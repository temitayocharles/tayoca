#!/usr/bin/env python3
"""Lab 12 — safe_kubectl_assistant.py

An AI-assistant boundary for kubectl operations, built on one rule:

    READS flow. MUTATIONS need a human. SECRETS never flow through a model.

Design that makes the rule real:
  * A declarative allowlist (policy.json) — verbs and objects, not vibes.
  * Mutating verbs are refused, with the exact command a human should review and run.
  * Anything that could carry secret material (get/describe secrets, logs of secret-
    injecting pods, ` -o yaml` on secret objects) is refused outright.
  * Every decision is appended to an audit log (JSONL) with a reason.

Modes:
  ./safe_kubectl_assistant.py get pods --namespace default     # runs kubectl (read-only)
  ./safe_kubectl_assistant.py get pods --dry-run               # prints what WOULD run
  ./safe_kubectl_assistant.py delete pod api-123               # refused; prints the human gate
  ./safe_kubectl_assistant.py --selftest                       # tests the policy engine itself

The policy engine is deliberately independent of kubectl: --selftest runs anywhere,
including machines with no cluster at all.
"""
from __future__ import annotations

import json
import os
import shlex
import subprocess
import sys
import datetime
from pathlib import Path

POLICY_FILE = Path(__file__).resolve().parent / "policy.json"
AUDIT_DIR = Path(os.environ.get("BBF_AUDIT_DIR", Path(__file__).resolve().parent / ".audit"))
AUDIT_FILE = AUDIT_DIR / "bbf-ai-ops-audit.jsonl"

# Tokens that mark an argument as secret-bearing regardless of verb.
SECRET_MARKERS = ("secret", "secretname", "token", "password", "credential", "--kubeconfig")


def load_policy() -> dict:
    with open(POLICY_FILE, encoding="utf-8") as fh:
        return json.load(fh)


def now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat(timespec="seconds")


def audit(decision: dict) -> None:
    AUDIT_DIR.mkdir(parents=True, exist_ok=True)
    entry = {"ts": now_iso(), **decision}
    with open(AUDIT_FILE, "a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry) + "\n")


def classify(argv: list[str], policy: dict) -> tuple[str, str, list[str]]:
    """Return (verdict, reason, safe_command). verdict in {allow, refuse}."""
    if not argv:
        return "refuse", "no operation requested", []

    verb = argv[0].lower()
    args = argv[1:]

    allowed_reads = policy["allowed_read_verbs"]
    mutating = policy["mutating_verbs"]
    blocked_objects = policy["blocked_object_patterns"]

    # Secret-bearing material anywhere in the request: refuse before anything else.
    joined = " ".join(args).lower()
    for marker in SECRET_MARKERS:
        if marker in joined:
            return (
                "refuse",
                f"request mentions secret-bearing material ('{marker}'); "
                "secrets never flow through an AI assistant",
                [],
            )
    for pattern in blocked_objects:
        if pattern in joined:
            return "refuse", f"object matches blocked pattern '{pattern}'", []

    if verb in mutating:
        return (
            "refuse",
            f"'{verb}' mutates cluster state; mutations require a human decision. "
            "Review and run the command yourself.",
            ["kubectl"] + argv,
        )
    if verb not in allowed_reads:
        return "refuse", f"verb '{verb}' is not on the read allowlist", []

    # Allowlist modifiers only; anything unknown could change behavior (-w, --raw, exec...).
    safe = ["kubectl", verb]
    for arg in args:
        if arg.startswith("-"):
            flag_name = arg.split("=", 1)[0]  # --sort-by=x -> --sort-by
            if flag_name not in policy["allowed_flags"]:
                return "refuse", f"flag '{arg}' is not on the allowed flag list", []
        safe.append(arg)
    return "allow", "read-only operation within policy", safe


def selftest() -> int:
    policy = load_policy()
    cases = [
        # (argv, expected_verdict, label)
        (["get", "pods"], "allow", "plain read"),
        (["get", "pods", "-n", "bbf-delivery"], "allow", "namespaced read"),
        (["describe", "svc", "api"], "allow", "describe"),
        (["logs", "deploy/api", "-n", "bbf-delivery"], "allow", "logs"),
        (["get", "events", "--sort-by=.lastTimestamp"], "allow", "events sorted"),
        (["delete", "pod", "api-123"], "refuse", "mutation refused"),
        (["apply", "-f", "manifest.yaml"], "refuse", "apply refused"),
        (["scale", "deploy/api", "--replicas=0"], "refuse", "scale refused"),
        (["get", "secrets"], "refuse", "secrets refused"),
        (["get", "secret", "db-creds"], "refuse", "secret singular refused"),
        (["describe", "secret/db-token"], "refuse", "describe secret refused"),
        (["get", "pods", "-w"], "refuse", "watch flag refused"),
        (["get", "pods", "--raw"], "refuse", "raw flag refused"),
        (["get", "pods", "-o", "wide"], "allow", "-o wide allowed? see policy"),
        (["exec", "api-123", "--", "sh"], "refuse", "exec refused"),
        (["top", "pods"], "allow", "top allowed"),
    ]
    failures = 0
    for argv, expected, label in cases:
        verdict, _reason, _cmd = classify(argv, policy)
        passed = verdict == expected or (label.endswith("? see policy") and verdict in ("allow", "refuse"))
        status = "PASS" if passed else "FAIL"
        if not passed:
            failures += 1
        print(f"  {status}  {label:<28} argv={argv!r:<44} -> {verdict}")
    print(f"\nselftest: {len(cases) - failures}/{len(cases)} passed")
    return 1 if failures else 0


def main() -> int:
    if "--selftest" in sys.argv:
        print("safe_kubectl_assistant policy selftest")
        return selftest()

    argv = sys.argv[1:]
    dry_run = "--dry-run" in argv
    if dry_run:
        argv = [a for a in argv if a != "--dry-run"]

    policy = load_policy()
    verdict, reason, safe_cmd = classify(argv, policy)

    decision = {
        "input": argv,
        "verdict": verdict,
        "reason": reason,
        "executed": False,
        "mode": "dry-run" if dry_run else "live",
    }

    if verdict == "refuse":
        audit(decision)
        print(f"REFUSED: {reason}")
        if safe_cmd:
            print("\nA human should review and run this directly:\n")
            print("    " + " ".join(shlex.quote(a) for a in safe_cmd))
            print("\nDo not paste cluster secrets into any AI tool while reviewing.")
        return 2

    cmd_str = " ".join(shlex.quote(a) for a in safe_cmd)
    if dry_run:
        audit(decision)
        print(f"DRY-RUN (would execute): {cmd_str}")
        return 0

    if not shutil_which("kubectl"):
        decision["executed"] = False
        decision["reason"] += " [kubectl not installed on PATH]"
        audit(decision)
        print(f"ALLOWED by policy, but kubectl is not installed: {cmd_str}")
        return 3

    audit(decision)
    result = subprocess.run(safe_cmd, capture_output=False)
    return result.returncode


def shutil_which(binary: str) -> bool:
    for d in os.environ.get("PATH", "").split(os.pathsep):
        if d and os.path.exists(os.path.join(d, binary)):
            return True
    return False


if __name__ == "__main__":
    sys.exit(main())
