#!/usr/bin/env bash
# Lab 03 — container exit codes are evidence, not noise.
# REQUIRES Docker. Exit codes you will meet constantly:
#   0  success           1  application error   7  app exited 7 (chosen)
# 126  not executable   127  command not found
set -uo pipefail
step() { printf '\n== %s ==\n' "$1"; }

run_and_report() { # label, then command...
  local label="$1"; shift
  set +e
  docker run --rm "$@" >/dev/null 2>&1
  local code=$?
  set -e
  printf '%-34s exit %s\n' "$label" "$code"
}

step "1. The five exits you will actually meet"
run_and_report "clean exit"                 alpine true
run_and_report "application error (1)"      alpine sh -c 'echo boom >&2; exit 1'
run_and_report "application chose 7"        alpine sh -c 'exit 7'
run_and_report "not executable (126)"       alpine sh -c 'exec /etc/hostname'
run_and_report "command not found (127)"    alpine nosuchcommand

step "2. Where a stopped container keeps its evidence"
docker run --name bbf-exit-demo alpine sh -c 'echo "about to fail"; exit 4' 2>/dev/null || true
docker inspect bbf-exit-demo --format 'ExitCode={{.State.ExitCode}}  OOMKilled={{.State.OOMKilled}}  Error="{{.State.Error}}"'
echo "-- logs of the dead container:"
docker logs bbf-exit-demo
docker rm bbf-exit-demo >/dev/null

step "Key reading"
cat <<'NOTES'
* exit 126/127 = the SHELL/OS never ran your app (image or permission problem).
* exit 1 (or any app-chosen code) = your app ran and decided to stop: read `docker logs`.
* OOMKilled=true = the kernel killed it; logs will NOT explain this. Check limits.
* A restart policy turns any of these into a visible loop (`docker ps` shows Restarting).
NOTES
