#!/usr/bin/env bash
# Lab 03 — activate one of three faults in the working Dockerfile.
#   1) typo-copy : build fails at COPY
#   2) exec-bit  : builds fine, container exits 126
#   3) app-fails : builds fine, container exits 1 with a message in logs
set -euo pipefail
cd "$(dirname "$0")/.."

mode="${1:-2}"
cp -n Dockerfile Dockerfile.bak

case "$mode" in
  1) cp broken/Dockerfile.typo-copy Dockerfile ;;
  2) cp broken/Dockerfile.exec-bit Dockerfile ;;
  3) cp broken/Dockerfile.app-fails Dockerfile ;;
  *) echo "usage: ./scripts/break.sh [1|2|3]" >&2; exit 2 ;;
esac

echo "BREAK $mode active (original saved as Dockerfile.bak). Now run:"
echo "  docker build -t bbf-site:broken . && docker run --rm --name bbf-site-broken bbf-site:broken"
echo "Evidence to collect: the exit code, docker logs, docker inspect .State"
