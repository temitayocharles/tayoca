#!/usr/bin/env bash
# Lab 03 — restore working files, remove demo containers and images.
set -euo pipefail
cd "$(dirname "$0")/.."
[[ -f Dockerfile.bak ]] && mv Dockerfile.bak Dockerfile
docker rm -f bbf-exit-demo bbf-site-broken bbf-site 2>/dev/null || true
docker rmi bbf-site:broken bbf-site:ok 2>/dev/null || true
echo "Lab 03 reset complete."
