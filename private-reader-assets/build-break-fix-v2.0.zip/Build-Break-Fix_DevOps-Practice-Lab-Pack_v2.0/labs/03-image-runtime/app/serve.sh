#!/bin/sh
# Lab 03 — start busybox httpd in the foreground, serving /site on 8080.
# Foreground (-f) is essential: PID 1 must stay alive or the container exits.
exec httpd -f -p 8080 -h /site
