# Lab 03 — Docker Image & Runtime Troubleshooting

**Loop stage:** BUILD (a working image) → BREAK (three fault classes)
**You will keep:** separating *build failure* from *runtime failure* from *application
failure* — each has different evidence.

## Objective

Build one small image that works, then meet the three ways images fail: at build time
(broken context), at start time (permission / command problems), and at run time (the
application itself gives up). Learn to read exit codes as a first-class signal.

## Prerequisites

Docker. No Kubernetes, no cloud.

## Setup — expected working state

```bash
cd labs/03-image-runtime
docker build -t bbf-site:ok .
docker run -d --name bbf-site -p 8090:8080 bbf-site:ok
curl -i http://localhost:8090/          # HTTP/1.1 200 OK
docker inspect --format '{{.State.Health.Status}}' bbf-site   # healthy
```

Success criteria: `curl` returns `200`, and after ~10 seconds the healthcheck status is
`healthy` (not `starting`).

## Build (vocabulary)

```bash
./scripts/exit-codes.sh
```

You should see exit codes `0, 1, 7, 126, 127` printed with labels, then an inspect of a
dead container showing `ExitCode=4 OOMKilled=false` and its last log line.

## Break

```bash
./scripts/break.sh 1   # build fails: COPY path wrong
./scripts/break.sh 2   # builds, exits 126: serve.sh not executable
./scripts/break.sh 3   # builds, exits 1: app refuses to start
```

For each mode, record in your debugging log **before** reading solutions:

| Evidence | Mode 1 | Mode 2 | Mode 3 |
|---|---|---|---|
| Which stage failed (build vs run)? | | | |
| Exact exit code | | | |
| What `docker logs` shows | | | |
| What `docker inspect .State` shows | | | |

**Hypothesis gate:** for each mode write one sentence — *"This failed at ______ because
______; the evidence that proves it is ______."*

Solutions: `labs/solutions/03-image-runtime.md` (open only after the table is full).

## Fix and prove recovery

Fix = the `curl` from Setup returns `200` again **and** health returns to `healthy`.
A green `docker run` without a reachable endpoint is not recovery (Lab 02's rule).

## Reset

```bash
./scripts/reset.sh
```

## Prevention lesson

- `COPY` fails before anything runs: guard paths with `.dockerignore` and simple names.
- Executable bits belong in version control or a `RUN chmod` — decide once, not per build.
- Startup should fail *loudly* (message + non-zero exit) when dependencies are missing.

## Portfolio prompt

"Three ways a container image fails, and the one piece of evidence that identifies each" —
your table is the outline.

## Interview question

*"A container in CI exits 126. What does that mean, what are the likely causes, and what
would you check first?"*
