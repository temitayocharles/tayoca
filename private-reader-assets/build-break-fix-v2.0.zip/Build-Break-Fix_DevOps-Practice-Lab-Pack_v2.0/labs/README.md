# Build, Break, Fix — Companion Lab Pack

Thirteen runnable labs + templates + sealed solutions. Every lab is local and free;
container/Kubernetes labs need only Docker and kind on your laptop. Nothing here touches
paid cloud infrastructure.

```
labs/
├── 01-networking-dns/      failure vocabulary: exit codes 6 / 7 / 28; container DNS
├── 02-app-delivery/        bare process → image → Compose; running vs reachable
├── 03-image-runtime/       build vs runtime vs application failures; exit codes
├── 04-compose-deps/        depends_on conditions, healthchecks, dependency failure
├── 05-k8s-delivery/        Deployment → Pod → Service → Endpoint label chain
├── 06-k8s-config/          ConfigMaps, requests/limits, OOMKilled, Pending
├── 07-k8squest/            four sealed symptom-first scenarios
├── 08-cicd/                pipeline faults + a local CI twin (bbf-ci)
├── 09-terraform/           fmt/validate/plan/apply locally (free) + EKS study (gated)
├── 10-observability/       structured logs, levels, metrics, req_id correlation
├── 11-security/            secrets audit gate; base64≠encryption; rotation order
├── 12-ai-ops/              read-only kubectl boundary with selftests + audit log
├── 13-capstone/            integrated multi-fault incident + acceptance script
├── solutions/              sealed answer key (one file per lab)
├── templates/              lab notes, debugging log, portfolio story, interview prep
├── tools/check-env.sh      what can you run right now?
└── reset-all.sh            master cleanup
```

## Quick start

```bash
./tools/check-env.sh        # see what you can run right now
```

Labs 01 (scripts 1–2), 02 (bare process), 08, 10, 11, 12 run with just
curl/python3/node — no Docker. The container and Kubernetes labs (02 image half, 03,
04, 05–07, 13) need Docker Desktop and kind.

## The one rule of this pack

Write your hypothesis BEFORE opening `solutions/`. The labs are the product; the
answers are just the answer key.

## Cost & safety guarantees

- No cloud account, credentials, or paid service is required by any lab.
- The Terraform EKS study (`09-terraform/eks-study/`) is read/validate-only with
  explicit cost gates; it contains no apply path by design.
- Every deliberately broken file lives in a `broken/` (or `release/`) folder and is
  restored by that lab's `scripts/reset.sh`. `reset-all.sh` cleans everything.

## Book mapping

Each lab folder corresponds to a chapter in *Build, Break, Fix: DevOps Practice Lab
Pack* (2nd edition). The book explains the reasoning; this pack is the practice floor.
