# Lab 11 — Security & Secrets Safety Boundaries

**Loop stage:** BUILD (a clean repo) → BREAK (a secret leaks; permissions lie)
**You will keep:** base64 is not encryption; environment variables are printed evidence;
least privilege is a checklist, not a feeling. **No real credentials are used anywhere.**

## Objective

Hunt a planted (fake) secret, learn the three places secrets leak in everyday practice —
files, environment, and "encoding" — and build the audit habit that catches them.

## Prerequisites

python3, curl, git (optional). No cloud, no cluster needed for the main path; the
Kubernetes part is optional and marked.

## Setup — expected working state

```bash
cd labs/11-security
./scripts/audit-secrets.sh fixtures/     # exit 0: findings listed, nothing real
```

Success criteria: the audit reports the planted fake AWS-style key and the `.env` file in
`fixtures/`, with file/line evidence, and exits non-zero while findings exist (that
behavior IS the gate).

## The three everyday leaks — try each

**1. Encoding is not encryption.**

```bash
echo -n "hunter2-definitely-fake" | base64
# aGVudGVyMi1kZWZpbml0ZWx5LWZha2U=
echo -n "aGVudGVyMi1kZWZpbml0ZWx5LWZha2U=" | base64 -d   # anyone can read it back
```

Kubernetes Secrets are base64 in etcd unless encryption at rest is configured. Base64
defeats shoulder-surfing, not adversaries.

**2. Environment variables are printed evidence.**

If Docker is present: `docker run --rm -e TOKEN=fake-token-for-lab nginx:alpine env`? Do
not run that — read why: any `docker inspect` on a container exposes its env block in
plain text, and crash reports often include it. The rule: env vars are fine for
*configuration*, risky for *credentials you would not paste into a ticket*.

**3. Files outlive intentions.** `fixtures/app/.env` was "temporary". Nothing in git is
temporary.

## Break

```bash
./scripts/audit-secrets.sh ../10-observability/ ; echo "exit=$?"
```

(Run against a clean folder — the audit should pass. Then run it against `fixtures/`
again and note the exit code difference. A gate that always fails teaches nothing; one
that fails only on findings can block CI.)

## Investigate — evidence checklist

1. Which finding would you consider exploitable if the keys were real? Rank them.
2. For the `.env` file: check `fixtures/app/.gitignore` — why did it not save you?
   (Answer with git's actual rule: `.gitignore` prevents *staging*, never *removal*.)
3. If a real secret reaches a remote branch, deleting the file is insufficient — write
   the two-step response in your own words (rotate first, history-cleanup second, and why
   that order).

**Hypothesis gate:** *"A leaked secret must be treated as compromised regardless of
______, because ______."*

Solutions: `labs/solutions/11-security.md`.

## Optional Kubernetes part (needs the kind cluster)

```bash
kubectl create ns bbf-secrets 2>/dev/null || true
kubectl -n bbf-secrets create secret generic demo --from-literal=password=fake-not-real
kubectl -n bbf-secrets get secret demo -o jsonpath='{.data.password}' | base64 -d; echo
kubectl delete ns bbf-secrets
```

Note who could read that back: anyone with `get` on secrets in the namespace. Least
privilege means that list should be short, and audited.

## Fix and prove recovery

Add the findings to `.gitignore`/removal as appropriate; re-run the audit on `fixtures/`
— wait: the fixtures are the *teaching material*. Real recovery proof: run the audit on a
folder of YOUR project and get exit 0 with findings listed as none.

## Reset

Nothing persistent to reset. `rm -rf` nothing: fixtures are part of the lab.

## Prevention lesson

- Secret managers exist because memory ("I'll delete it later") does not scale; use the
  platform's store (CI masked variables, cloud secret managers, K8s Secrets + RBAC +
  encryption at rest).
- Audit scripts in CI turn "we hope not" into "we would know".
- Rotation is the only real response to exposure; obfuscation is not containment.

## Portfolio prompt

"Three places secrets leak and one audit gate": include your ranked findings and the
exit-code gate behavior.

## Interview question

*"A teammate commits an AWS key to a public repo and deletes the file five minutes later.
Walk me through your response in order, and why rotation comes before history cleanup."*
