#!/usr/bin/env bash
# Lab 11 — a tiny secrets audit gate. Usage: ./scripts/audit-secrets.sh <directory>
# Scans for the classic leaks: .env files, private key blocks, AWS-style key IDs,
# password assignments in config. Exit 1 if findings exist (so CI can gate on it).
# ALL fixtures in this lab are FAKE and labeled as such.
set -uo pipefail
DIR="${1:?usage: audit-secrets.sh <directory>}"
[[ -d "$DIR" ]] || { echo "not a directory: $DIR" >&2; exit 2; }

findings=0
note() { printf '  FINDING  %-52s %s\n' "$1" "$2"; findings=$((findings+1)); }

echo "== bbf secrets audit: $DIR =="

# 1. Environment files
while IFS= read -r f; do
  note "$f" "environment file present — should it be committed?"
done < <(find "$DIR" -name ".env" -o -name ".env.*" 2>/dev/null | grep -v '\.example$')

# 2. Private key material
while IFS= read -r line; do
  note "${line%%:*}" "private key block (${line#*:})"
done < <(grep -rn --include='*' -E '^-----BEGIN [A-Z ]*PRIVATE KEY-----' "$DIR" 2>/dev/null | head -5)

# 3. AWS-style access key IDs (pattern only; fixtures are fake)
while IFS= read -r line; do
  note "${line%%:*}" "AWS-style access key ID pattern"
done < <(grep -rEn --include='*' 'AKIA[0-9A-Z]{16}' "$DIR" 2>/dev/null | head -5)

# 4. Obvious credential assignments in code/config
while IFS= read -r line; do
  note "${line%%:*}" "hardcoded credential assignment"
done < <(grep -rEn --include='*.js' --include='*.py' --include='*.sh' --include='*.yaml' --include='*.yml' --include='*.json' --include='*.conf' '(password|secret|token|api_key)"?\s*[:=]\s*"[^$"{}][^"]{7,}"' "$DIR" 2>/dev/null \
        | grep -v -i 'example\|placeholder\|not-real' | head -5)

echo
if [[ "$findings" -eq 0 ]]; then
  echo "PASS: no classic leaks found. (This scan is heuristic, not a guarantee.)"
  exit 0
fi
echo "FAIL: $findings finding(s). Treat every finding as potentially real:"
echo "  1) rotate the credential if it was ever valid"
echo "  2) remove the file/line from the branch"
echo "  3) clean history ONLY AFTER rotation"
exit 1
