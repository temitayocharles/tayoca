# START HERE

Welcome to the lab pack for **Build, Break, Fix: DevOps Practice Lab Pack**.

## Your first ten minutes

```bash
cd labs
./tools/check-env.sh
```

Read the table it prints. Everything marked **(core)** runs with curl + python3 + node
and nothing else. The **(k8s stack)** labs wait for Docker + kind — install them when
you reach Lab 02's container half (instructions in the book's Setup chapter).

## Then, in order

1. **Lab 01** (`01-networking-dns`) — build your failure vocabulary first. Everything
   later reuses it.
2. Follow the book's parts in order: 02 → 03 → 04 → (cluster labs) 05 → 06 → 07 →
   08 → 09 → 10 → 11 → 12 → capstone 13.
3. After EVERY lab: copy `templates/lab-notes-template.md`, fill it, keep it in a notes
   folder outside this pack (so updates never overwrite your work):

```bash
mkdir -p ~/bbf-lab-notes
cp labs/templates/*.md ~/bbf-lab-notes/
```

## The three habits this pack installs

1. **Hypothesis before fix** — write what you believe and why, then test it.
2. **Evidence over vibes** — paste the decisive output line, not your memory of it.
3. **Recovery proof** — the user-path command that failed must succeed again.

## If anything misbehaves

- Every lab has `scripts/reset.sh`. The pack has `reset-all.sh`.
- `./tools/check-env.sh` again — environments drift; that's not a metaphor.
- The book's Appendix A maps every symptom class in this pack to its evidence commands.
