#!/usr/bin/env bash
# Build, Break, Fix — environment doctor.
# Reports which labs you can run RIGHT NOW, and what is missing for the rest.
# Safe: reads versions only, touches nothing.
set -uo pipefail

have() { command -v "$1" >/dev/null 2>&1; }
ver()  { "$1" version 2>/dev/null | head -1 || "$1" --version 2>/dev/null | head -1 || echo "(present)"; }
verc() { "$1" version --client 2>/dev/null | head -1 || "$1" --client=true version 2>/dev/null | head -1; }

printf '%-14s %-10s %s\n' "TOOL" "STATUS" "VERSION / NOTE"
printf '%.0s-' {1..58}; echo

check() { # tool required-for lab-note
  local tool="$1" labs="$2" v=""
  if have "$tool"; then
    case "$tool" in
      kubectl) v=$(verc kubectl) ;;
      docker)  v=$(docker --version 2>/dev/null | head -1) ;;
      node)    v="node $(node --version 2>/dev/null)" ;;
      *)       v=$(ver "$tool") ;;
    esac
    printf '%-14s %-10s %s\n' "$tool" "OK" "$v"
  else
    printf '%-14s %-10s needed for: %s\n' "$tool" "MISSING" "$labs"
  fi
}

check curl      "Lab 01+ (core)"
check python3   "Labs 01, 10, 11, 12 (core)"
check node      "Labs 02, 08, 10 (core)"
check docker    "Labs 01(3), 02, 03, 04, 05-07, 13 (k8s stack)"
check kind      "Labs 05-07, 13 (k8s stack)"
check kubectl   "Labs 05-07, 13 (k8s stack)"
check terraform "Lab 09 (or use tofu)"
check tofu      "Lab 09 (alternative to terraform)"
check jq        "optional convenience"

echo
if have docker; then
  if docker info >/dev/null 2>&1; then echo "Docker daemon: reachable"
  else echo "Docker daemon: NOT reachable — start Docker Desktop / the daemon first (labs 01(3),02-07,13 wait on this)"; fi
fi
if have kubectl; then
  ctx=$(kubectl config current-context 2>/dev/null || echo none)
  echo "kubectl context: $ctx $([[ "$ctx" == kind-bbf ]] && echo '(ready for the K8s labs)' || echo '(create the lab cluster with: kind create cluster --name bbf)')"
fi
echo
echo "Legend: (core) = free, no container runtime needed. (k8s stack) = needs Docker+kind."
echo "Nothing here modifies your machine."
