# Debugging Log — ______ (system / incident)

**Started:** ____  **Severity (your call):** ____  **User impact in one sentence:**

## 1. Symptom — what is observed, by whom, since when

## 2. Evidence — separate observation from interpretation

| # | Command / source | Output line that matters | What it rules OUT |
|---|---|---|---|
| 1 | | | |
| 2 | | | |
| 3 | | | |

## 3. Hypothesis space — at least two, ranked

- H1 (most likely): ______ because ______
- H2: ______ because ______
- The cheapest single test that separates H1 from H2: ______

## 4. Safe debugging path — what I will NOT do yet (and why)

## 5. Fix applied — smallest reversible change that tests H1

## 6. Recovery proof — user-path evidence, not green commands

## 7. Prevention — the systemic change (check, gate, alert, doc, test)

## 8. Explanation — 5 sentences a new teammate could follow
