# Interview Readiness Checklist

Work through this after every lab, and again after the capstone.

## The five-move answers (know your evidence commands cold)

- [ ] DNS failure vs connection refused vs timeout — one curl each, exit codes 6/7/28
- [ ] Running vs reachable — `docker ps` + `curl` in one breath
- [ ] Desired vs actual state — `kubectl get deploy` vs `kubectl get pods` vs endpoints
- [ ] Configuration vs runtime failure — CreateContainerConfigError vs CrashLoopBackOff
- [ ] Symptom vs root cause — state both, separately, for every story you tell

## SSRL structure (every behavioral answer)

- [ ] **S**ituation — system + stakes in one sentence
- [ ] **S**ignal — how you noticed (not "someone told me", if avoidable)
- [ ] **R**ecovery action — evidence order, then the smallest reversible fix
- [ ] **L**esson — prevention, and what you would do faster

## Question bank (answer aloud; record yourself once — it works)

1. A container runs but the service is unreachable. First five commands?
2. All pods Ready but requests fail. Where do you look and why?
3. Pod in CrashLoopBackOff with empty logs. Three causes, one first command?
4. CI green yesterday, red today, no code changes. Investigation order?
5. Terraform shows drift on a load balancer. Two options, and how you choose?
6. Teammate leaked a live key to a public repo. First two actions, in order?
7. You want to let an AI assistant touch the cluster. Allow/deny list?
8. Logs are structured JSON with request IDs. Why does that matter at 03:00?
9. A deployment rolled out but users still hit the old version. Caches, DNS, or
   selectors — how do you separate the three?
10. Walk me through a system you broke on purpose and fixed with evidence. (Your capstone.)

## Red flags in your own answers (listen for these)

- Naming a tool before naming the layer ("I'd check Kubernetes..." — which property?)
- "I restarted it and it worked" with no hypothesis stated
- No user-path recovery proof ("the command exited 0" is not recovery)
- Claiming no mistakes — interviewers trust evidence of handled failures more
