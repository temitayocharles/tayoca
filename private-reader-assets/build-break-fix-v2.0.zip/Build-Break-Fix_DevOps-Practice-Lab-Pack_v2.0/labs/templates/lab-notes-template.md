# Lab Notes — Lab __: ______

**Date:** ____  **Time spent:** ____  **Loop stages completed:** Build ☐ Break ☐ Fix ☐ Explain ☐

## What I built (2–3 sentences, your words)

## The failure I worked (symptom as a user would state it)

## Evidence I collected (commands + the decisive output lines)

```
(paste)
```

## My hypothesis — written BEFORE the fix

## The fix + recovery proof (the command that failed, now succeeding)

## Prevention lesson (what would stop this class of failure, not just this instance)

## Mastery self-check

- [ ] I could re-derive the diagnosis from the evidence alone
- [ ] I can explain the failure layer without naming the tool first
- [ ] Recovery was proven by a user-path check, not a green command
