# Portfolio Story — ______ (lab or project)

> A portfolio is not a gallery of successes. It is evidence of judgment.
> Use one failure-driven story per page. Truthful, specific, evidence-backed.

## Title (plain and specific)

e.g. "Diagnosing a service selector mismatch in Kubernetes — an evidence-first walkthrough"

## Context (what existed, what it was for)

## What I built (architecture in 3–4 lines; a small diagram earns its space)

## What broke (the interesting part — lead with it)

## How I noticed (signal: user report? alert? failed check?)

## Evidence trail (commands + decisive outputs, trimmed to the lines that mattered)

```
(paste 3–8 lines maximum)
```

## Hypothesis → cheapest separating test → fix

## Recovery proof (before/after of the same user-path command)

## Prevention (the change that outlived the incident)

## Skills demonstrated (name them explicitly for recruiters scanning)

## Artifacts (link the repo path; note honestly if data was sanitized)
