# Lab 07 — K8sQuest: Evidence-First Troubleshooting

**Loop stage:** BREAK first, BUILD last. This lab starts broken.
**You will keep:** calm, ordered diagnosis when all you have is a symptom.

## How the quest works

Four sealed scenarios. For each one:

1. Read ONLY the symptom card (`quests/SYMPTOM-Qn.md`).
2. Apply the broken manifest (`kubectl apply -f scenarios/Qn.yaml`).
3. Gather evidence (the allowed moves below).
4. Write a hypothesis with a predicted fix.
5. Only then open `labs/solutions/07-k8squest.md` at Qn.
6. Fix it, prove recovery, write the explanation in your own words.

**Allowed moves** (evidence, not answers): `kubectl get` (any), `describe` (any),
`logs` (any), `get events`, `get endpoints`, `--show-labels`. Not allowed until after the
hypothesis: reading the scenario YAML, reading solutions.

## Prerequisites

The `bbf` kind cluster, `bbf-sample-api:local` loaded (Lab 05).

## Quest log (fill as you go)

| Q | Symptom in one sentence | Layer (image/config/network/schedule) | Evidence line that decided it | Fix | Proof |
|---|---|---|---|---|---|
| 1 | | | | | |
| 2 | | | | | |
| 3 | | | | | |
| 4 | | | | | |

## Symptom cards

- **Q1** (`scenarios/q1.yaml`, ns `bbf-quest-1`): the rollout never finishes;
  `kubectl rollout status deploy/web` hangs; pods show a back-off state.
- **Q2** (`scenarios/q2.yaml`, ns `bbf-quest-2`): pods restart endlessly; each copy dies
  moments after start; there IS a log line.
- **Q3** (`scenarios/q3.yaml`, ns `bbf-quest-3`): everything is Running and Ready, the
  Service exists — but `curl` through it fails.
- **Q4** (`scenarios/q4.yaml`, ns `bbf-quest-4`): the Deployment reports a new ReplicaSet
  with zero pods; old pods are gone; nothing is crashing.

## Between quests

Run the reset below, then continue. Do not peek at the next symptom card until the
previous row of the quest log is complete — the point of this lab is the discipline.

## Reset (each scenario, or all)

```bash
kubectl delete ns bbf-quest-1 bbf-quest-2 bbf-quest-3 bbf-quest-4 --ignore-not-found
```

Full-cluster teardown after the lab: `kind delete cluster --name bbf` (also used by other
labs — only when you are done for the day).

## Portfolio prompt

Pick the quest that took you longest. Write it as a 120-word incident narrative: symptom,
evidence, hypothesis, fix, proof, prevention. That story is interview-ready material.

## Interview question

*"Tell me about a time a system looked healthy but was not."* Use Q3 or Q4 as your story
if you lack a work incident yet — say honestly that it was a training scenario and show
the evidence discipline.
