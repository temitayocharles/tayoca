# K8sQuest — Symptom cards (open one at a time)

Do not read the scenario YAML before writing your hypothesis. The symptom is the entry
point; the manifest is part of the answer.

---

## Q1 — the rollout that never finishes

You applied a routine release at 09:40. `kubectl rollout status deploy/web -n bbf-quest-1`
hangs past a minute. Users of the old version are unaffected (this is a new deployment).

**Your moves:** `get pods`, `describe pod`, `get events`.

Write before solutions:
- Status shown: ____________
- Reason shown in describe: ____________
- The event line that names the actual failing step: ____________
- Hypothesis: ____________

---

## Q2 — the crash that talks

`kubectl get pods -n bbf-quest-2` shows a restart counter climbing. Unlike a kernel kill,
this one leaves a message.

**Your moves:** `get pods`, `logs` (current AND `--previous`), `describe`.

Write before solutions:
- The log line: ____________
- Exit code if visible: ____________
- Why the restart count grows instead of stopping: ____________
- Hypothesis: ____________

---

## Q3 — healthy on paper

Every pod is `Running` and `Ready`. The Service exists. `kubectl port-forward -n
bbf-quest-3 svc/web 8181:80` works — but `curl http://localhost:8181/health` refuses.

**Your moves:** `get endpoints`, `logs`, `describe svc`.

Write before solutions:
- Are endpoints populated? ____________
- What the app log says it is listening on: ____________
- Where in the chain the refusal is born: ____________
- Hypothesis: ____________

---

## Q4 — the vanished rollout

`kubectl rollout status deploy/web -n bbf-quest-4` waits forever, but nothing is crashing
and nothing restarts. `get pods` shows pods that never become pods.

**Your moves:** `get pods`, `describe pod` (Events!), `get rs`, `get deploy -o wide`.

Write before solutions:
- Pod phase: ____________
- The scheduling message: ____________
- Which resource number is the blocker, and where it appears: ____________
- Hypothesis: ____________
