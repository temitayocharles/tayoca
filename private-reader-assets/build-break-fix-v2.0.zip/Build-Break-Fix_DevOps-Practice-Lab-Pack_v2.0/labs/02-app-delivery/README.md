# Lab 02 — Local Application Delivery

**Loop stage:** BUILD → BREAK
**You will keep:** the distinction between *a process running* and *a service being reachable*.

## Objective

Take one small API through three delivery forms — bare process, container image, Compose
service — and prove each form works with the same evidence-based check. Then break the port
chain and diagnose it from symptoms.

## Prerequisites

- Node.js ≥ 18 (`node --version`)
- Docker (any recent version) for the container half
- curl

No cloud account. No npm packages — the app is dependency-free by design.

## Setup — expected working state

```bash
cd labs/02-app-delivery/sample-app
npm test          # 3 tests must pass
npm start         # terminal 1
# terminal 2:
curl -i http://localhost:3000/health     # HTTP/1.1 200 OK
curl -s http://localhost:3000/api/items  # {"items":[...]}
```

Success criteria (write these down before you start):

1. `npm test` prints `pass 3`.
2. `curl -i /health` returns `HTTP/1.1 200` and a JSON body containing `"status":"ok"`.
3. The server logs one line beginning `[bbf-sample-api] listening on 0.0.0.0:3000`.

## Build — container and Compose

```bash
docker build -t bbf-sample-api:local .
docker run --rm -d --name bbf-api -p 3000:3000 bbf-sample-api:local
curl -i http://localhost:3000/health        # same 200 as before
docker logs bbf-api                          # shows the listening line
docker rm -f bbf-api

docker compose up --build -d
curl -i http://localhost:3000/health        # same 200, third proof
docker compose down
```

## Break — choose a failure

```bash
cd ..
./scripts/break.sh 1   # or: ./scripts/break.sh 2
```

**Symptom (both modes):** `curl: (7) Failed to connect to localhost port 3000` — yet the
container is *running* (`docker ps` shows it `Up`).

## Investigate — evidence to collect BEFORE reading any solution

Gather, in order:

1. `docker ps` — is the container running? (expected: yes)
2. `docker logs <container>` — what port did the app say it is listening on?
3. `docker port <container>` — which host port maps to which container port?
4. `docker inspect <container> --format '{{ .Config.Env }}'` — what is `PORT` set to?
5. `curl -v --max-time 3 http://localhost:3000/health` — the exact curl exit code (run
   `echo $?` immediately after).

Write your hypothesis before opening `labs/solutions/02-app-delivery.md`:
complete this sentence — *"The request fails because the port that ______ listens on is not
the port that ______ forwards to."*

## Fix and prove recovery

Fix, then re-run the exact command that failed. Recovery proof = the same `curl -i` that
returned exit 7 now returns `HTTP/1.1 200` **and** `docker logs` shows the matching port.

## Reset

```bash
./scripts/reset.sh
```

## Prevention lesson (write your own, then compare)

Config changes that move a listening port must be changed in **every** place the port is
named: the app config, the image's `ENV`/`EXPOSE`, the run mapping `-p host:container`, and
any Compose file. A one-line `healthcheck` against `/health` turns this class of silent
breakage into a visible one.

## Portfolio prompt

Explain "running is not reachable" with your actual evidence trail (ps output, log line,
port mapping) as the story spine.

## Interview question

*"A container is running but users get connection refused. Walk me through your first five
commands."* Practice answering with evidence, not guesses.
