// Lab 02 — automated checks for the sample app.
// Run with: npm test   (uses Node's built-in test runner; no dependencies)
const test = require('node:test');
const assert = require('node:assert');
const { spawn } = require('node:child_process');
const http = require('node:http');

function get(pathname, port) {
  return new Promise((resolve, reject) => {
    const req = http.get({ host: '127.0.0.1', port, path: pathname, timeout: 2000 }, (res) => {
      let body = '';
      res.on('data', (c) => (body += c));
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
  });
}

test('GET /health returns 200 ok', async () => {
  const srv = spawn('node', ['server.js'], {
    env: { ...process.env, PORT: '39871' },
    stdio: 'ignore',
  });
  try {
    let lastErr;
    for (let i = 0; i < 30; i++) {
      try { await get('/health', 39871); break; }
      catch (e) { lastErr = e; await new Promise((r) => setTimeout(r, 100)); }
    }
    const res = await get('/health', 39871);
    assert.equal(res.status, 200);
    assert.equal(JSON.parse(res.body).status, 'ok');
  } finally {
    srv.kill('SIGTERM');
  }
});

test('GET /api/items returns the catalog', async () => {
  const srv = spawn('node', ['server.js'], {
    env: { ...process.env, PORT: '39872' },
    stdio: 'ignore',
  });
  try {
    for (let i = 0; i < 30; i++) {
      try { await get('/api/items', 39872); break; }
      catch { await new Promise((r) => setTimeout(r, 100)); }
    }
    const res = await get('/api/items', 39872);
    assert.equal(res.status, 200);
    assert.ok(JSON.parse(res.body).items.length >= 2);
  } finally {
    srv.kill('SIGTERM');
  }
});

test('unknown path returns 404, not a crash', async () => {
  const srv = spawn('node', ['server.js'], {
    env: { ...process.env, PORT: '39873' },
    stdio: 'ignore',
  });
  try {
    for (let i = 0; i < 30; i++) {
      try { await get('/nope', 39873); break; }
      catch { await new Promise((r) => setTimeout(r, 100)); }
    }
    const res = await get('/nope', 39873);
    assert.equal(res.status, 404);
  } finally {
    srv.kill('SIGTERM');
  }
});
