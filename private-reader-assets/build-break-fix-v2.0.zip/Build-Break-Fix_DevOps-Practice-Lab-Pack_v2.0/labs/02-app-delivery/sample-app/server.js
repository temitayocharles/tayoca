// Build, Break, Fix — Lab 02 sample API
// A deliberately small HTTP API with no external dependencies.
// Endpoints:
//   GET /health    -> 200 {"status":"ok"}     (liveness for the labs)
//   GET /api/items -> 200 a small JSON list
//   GET /metrics   -> 200 plain-text counters (used in Lab 10's twin app)
const http = require('node:http');
const os = require('node:os');

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '0.0.0.0';

let requestsTotal = 0;
const startedAt = Date.now();

const server = http.createServer((req, res) => {
  requestsTotal += 1;
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && url.pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', uptimeSeconds: Math.round((Date.now() - startedAt) / 1000) }));
    return;
  }
  if (req.method === 'GET' && url.pathname === '/api/items') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ items: [{ id: 1, name: 'widget' }, { id: 2, name: 'gadget' }] }));
    return;
  }
  if (req.method === 'GET' && url.pathname === '/metrics') {
    res.writeHead(200, { 'Content-Type': 'text/plain; version=0.0.4' });
    res.end(`# HELP bbf_requests_total Total requests handled.\n# TYPE bbf_requests_total counter\nbbf_requests_total ${requestsTotal}\n`);
    return;
  }
  if (req.method === 'GET' && url.pathname === '/alloc') {
    // Lab 06: allocate ?mb=N megabytes for two seconds. Used to demonstrate
    // memory limits and OOMKilled deterministically. Kept deliberately blunt.
    const mb = Math.min(parseInt(url.searchParams.get('mb') || '0', 10) || 0, 4096);
    if (mb > 0) {
      const sink = Buffer.alloc(mb * 1024 * 1024, 1);
      setTimeout(() => { res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ allocatedMb: mb })); }, 2000);
      return;
    }
    res.writeHead(400, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'specify ?mb=N (1-4096)' }));
    return;
  }
  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'not found', path: url.pathname }));
});

server.listen(PORT, HOST, () => {
  console.log(`[bbf-sample-api] listening on ${HOST}:${PORT}`);
  console.log(`[bbf-sample-api] pid=${process.pid} host=${os.hostname()}`);
  // Lab 06 evidence point: configuration actually received by the process.
  console.log(`[bbf-sample-api] greeting=${process.env.GREETING || '(unset)'}`);
});

// Lab 03 uses this: a clean shutdown path, so SIGTERM is not a crash.
process.on('SIGTERM', () => {
  console.log('[bbf-sample-api] SIGTERM received, closing server');
  server.close(() => process.exit(0));
});
