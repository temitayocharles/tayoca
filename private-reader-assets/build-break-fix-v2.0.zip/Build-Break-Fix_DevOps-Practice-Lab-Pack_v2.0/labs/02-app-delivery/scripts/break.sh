#!/usr/bin/env bash
# Lab 02 — activate a deliberate failure. Usage: ./scripts/break.sh [1|2]
#   1) container listens on 4000, operator still maps 3000:3000
#   2) compose maps host 3000 -> container 8080, app listens on 3000
# The script backs up originals so scripts/reset.sh can restore them.
set -euo pipefail
cd "$(dirname "$0")/.."
cd sample-app

mode="${1:-1}"
cp -n Dockerfile Dockerfile.bak
cp -n compose.yaml compose.yaml.bak

if [[ "$mode" == "1" ]]; then
  cp broken/Dockerfile.listen-4000 Dockerfile
  echo "BREAK 1 active: Dockerfile now sets PORT=4000 (original saved as Dockerfile.bak)."
  echo "Reproduce:  docker build -t bbf-sample-api:broken . && docker run --rm -p 3000:3000 bbf-sample-api:broken"
  echo "Then run:   curl -v --max-time 3 http://localhost:3000/health"
elif [[ "$mode" == "2" ]]; then
  cp broken/compose.wrong-port.yaml compose.yaml
  echo "BREAK 2 active: compose now maps 3000:8080 (original saved as compose.yaml.bak)."
  echo "Reproduce:  docker compose up --build -d && curl -v --max-time 3 http://localhost:3000/health"
else
  echo "usage: ./scripts/break.sh [1|2]" >&2; exit 2
fi
