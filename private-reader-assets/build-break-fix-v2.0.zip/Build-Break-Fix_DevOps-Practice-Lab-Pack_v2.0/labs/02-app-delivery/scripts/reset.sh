#!/usr/bin/env bash
# Lab 02 — restore the working files and remove the broken image.
set -euo pipefail
cd "$(dirname "$0")/../sample-app"

[[ -f Dockerfile.bak ]] && mv Dockerfile.bak Dockerfile
[[ -f compose.yaml.bak ]] && mv compose.yaml.bak compose.yaml
docker compose down --remove-orphans 2>/dev/null || true
docker rmi bbf-sample-api:broken 2>/dev/null || true
docker rm -f bbf-api-broken 2>/dev/null || true

echo "Lab 02 reset complete."
