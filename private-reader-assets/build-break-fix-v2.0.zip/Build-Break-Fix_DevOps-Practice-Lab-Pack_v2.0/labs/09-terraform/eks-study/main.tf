# EKS scheduled-operations STUDY SKELETON — validate-only by design.
# This file teaches the SHAPE of a guarded node-group scaling pattern.
# It intentionally contains no schedule trigger resource: that belongs to
# EventBridge/Lambda or CI, so that no accidental apply can resize real nodes.

variable "cluster_name" {
  description = "Existing EKS cluster this pattern would operate on."
  type        = string
  default     = "study-cluster-not-real"
}

variable "node_group_name" {
  description = "Managed node group under discussion."
  type        = string
  default     = "general"
}

variable "desired_size" {
  description = "Desired node count. 0 is the safe 'stop' for a non-production cluster."
  type        = number
  default     = 0

  validation {
    condition     = var.desired_size >= 0 && var.desired_size <= 9
    error_message = "desired_size must be between 0 and 9 for this study pattern."
  }
}

variable "min_size" {
  type    = number
  default = 0
}

variable "max_size" {
  type    = number
  default = 9
}

locals {
  is_stopped = var.desired_size == 0
  # A stopped cluster must keep min at 0, or the API will fight the schedule.
  effective_min = local.is_stopped ? 0 : var.min_size
}

# The real resource is COMMENTED OUT on purpose: uncommenting is a decision,
# and decisions about paid infrastructure should be slow ones.
#
# resource "aws_eks_node_group" "general" {
#   cluster_name    = var.cluster_name
#   node_group_name = var.node_group_name
#   node_role_arn   = "arn:aws:iam::ACCOUNT:role/ROLE"   # never hardcode real ARNs
#   subnet_ids      = []                                  # filled by your VPC module
#
#   scaling_config {
#     desired_size = var.desired_size
#     min_size     = local.effective_min
#     max_size     = var.max_size
#   }
#
#   lifecycle {
#     prevent_destroy = true    # a schedule must never delete a node group outright
#   }
# }

resource "null_resource" "study_marker" {
  # A zero-cost marker so `terraform validate` has something real to validate.
  lifecycle {
    precondition {
      condition     = var.min_size <= var.max_size
      error_message = "min_size cannot exceed max_size — even in a study."
    }
  }

  triggers = {
    pattern   = "eks-scheduled-operations"
    mode      = local.is_stopped ? "stopped" : "running"
    min_check = local.effective_min
  }
}

output "study_summary" {
  description = "What this configuration WOULD represent, in words."
  value = join(" ", [
    "Node group", var.node_group_name, "on", var.cluster_name,
    local.is_stopped ? "scaled to zero (stopped)." : "running with desired=${var.desired_size}.",
    "Guardrails: prevent_destroy, variable validation, plan-first workflow."
  ])
}
