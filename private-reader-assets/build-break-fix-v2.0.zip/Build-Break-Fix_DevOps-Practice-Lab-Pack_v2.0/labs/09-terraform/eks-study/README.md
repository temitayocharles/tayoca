# EKS Scheduled-Operations Study — READ & VALIDATE ONLY

> **Cost boundary (read twice).** Everything in this folder is study material for
> *reading and reasoning about* an AWS EKS operation pattern. It deliberately contains
> **no `apply` instructions**, because a real EKS cluster bills you per hour per node
> plus NAT gateways plus load balancers. Do not run `terraform apply` here. If you later
> adapt this pattern, do it in a sandbox AWS account with a budget alarm set first.

## What this pattern is for

Teams that run non-production EKS clusters often scale node groups to zero (or small)
overnight and restore them in the morning. The pattern has three honest parts:

1. **Declaration** — the desired node group scaling values (Terraform resources).
2. **Trigger** — something that changes them on a schedule (EventBridge Scheduler +
   Lambda outside Terraform, or a CI job running `terraform apply` with tight variable
   scopes).
3. **Guardrails** — `lifecycle` blocks, variable validation, `prevent_destroy`, and a
   plan-first workflow so a schedule can never delete something by accident.

## How to study it safely

```bash
cd labs/09-terraform/eks-study
terraform init -backend=false     # downloads the AWS provider (~100 MB, no credentials used)
terraform fmt -check
terraform validate                # needs NO cloud access: syntax + type checking only
terraform plan                    # WILL ask for credentials — that is your cue to stop.
```

`plan` failing here without credentials is the correct, expected outcome of this study.
Everything before it is fully local.

## The guardrails to notice in `main.tf`

- `variable "desired_size"` validates 0–9 — a schedule cannot ask for 500 nodes.
- `lifecycle { prevent_destroy = true }` on the node group — Terraform refuses to
  destroy it even if someone deletes the resource block.
- `precondition` checks that "stop" is expressed as size 0, not deletion.
- Explicit `create_before_destroy` where reordering would cause an outage.

## Transfer to the real thing (checklist, not commands)

When you adapt this at work or in a sandbox account with a budget alarm:

- [ ] `terraform plan` reviewed by a second person before the first apply
- [ ] Budget alarm set in the AWS account (Billing → Budgets)
- [ ] Region and account verified with `aws sts get-caller-identity` BEFORE apply
- [ ] Tag everything with an owner and an auto-delete date
- [ ] `terraform destroy` rehearsed in the sandbox before anyone depends on the cluster

Cost reality to write in your notes: a small EKS control plane is billed hourly (around
$0.10/hour in most regions as of 2025), EC2 nodes bill per second while up, and forgotten
NAT gateways and load balancers are the classic surprise line items. Exact numbers change —
always check the current AWS pricing page before you build.
