# Lab 09 — Terraform / OpenTofu: Validate, Plan, Drift

**Loop stage:** BUILD (real apply, zero cost) → BREAK (format, types, drift)
**You will keep:** the habit of `fmt -check → validate → plan → (review) → apply`, and the
ability to read a plan as a *prediction*, not a receipt.

## Objective

Run Terraform's complete lifecycle against the `local` provider — every command is real,
nothing touches a cloud, applying costs nothing. Then break the code three ways and, most
importantly, manufacture **configuration drift** and watch Terraform detect it.

Works identically with OpenTofu (`tofu`) if that is what you have.

## Prerequisites

Terraform ≥ 1.6 or OpenTofu ≥ 1.6 (`terraform version`). No AWS account. No credentials.

## Setup — expected working state

```bash
cd labs/09-terraform/local-basics
terraform init
terraform fmt -check          # silence IS success
terraform validate            # "Success! The configuration is valid."
terraform plan                # Plan: 2 to add, 0 to change, 0 to destroy.
terraform apply               # type yes; two files appear under generated/
terraform output
```

Success criteria: `generated/index.html` and `generated/runtime.conf` exist, and
`terraform output runtime_conf_hash` prints a SHA1. You have now genuinely *applied
infrastructure code* — locally.

## Break

```bash
./scripts/break.sh 1   # formatting chaos        -> fmt -check fails
./scripts/break.sh 2   # type + validation faults -> validate/plan fails
./scripts/break.sh 3   # DRIFT: hand-edit the managed file after apply
```

## Investigate — evidence checklist

| Fault | Command that catches it | The decisive line of its output | What Terraform refuses to do |
|---|---|---|---|
| 1 | `terraform fmt -check -diff` | | |
| 2 | `terraform validate` | | |
| 3 | `terraform plan` | | |

For fault 3 — the important one — read the plan like an operator:

- Which resource does Terraform want to change, and why does it *know*?
- Does the plan say "update in-place" or "destroy and recreate"? What decides that?
- Who caused this incident? (Answer honestly: you did, out-of-band. In production the
  "who" is a human with console access — same plan, same detection.)

**Hypothesis gate:** *"Terraform detected drift because state says ______ but the real
file says ______; it will ______ to reconcile."*

Solutions: `labs/solutions/09-terraform.md`.

## Fix and prove recovery

Fault 1: `terraform fmt` (then re-check). Fault 2: fix the values, `terraform validate`.
Fault 3 — choose deliberately, both are valid, and the choice is the lesson:

- `terraform apply` — Terraform wins; the hand-edit is reverted.
- Edit the Terraform source so the desired state matches reality — the operator wins.

Write one sentence on when each choice is right.

## Reset

```bash
./scripts/reset.sh
```

## EKS study (separate folder, validate-only)

`eks-study/README.md` holds the scheduled-operations pattern as **annotated study
material** with explicit cost gates and no apply path. Read it after this lab; it is the
bridge from "local provider" to "the real thing, guarded".

## Prevention lesson

- `fmt -check` in CI keeps IaC reviewable; unreadable code hides real defects.
- Variable validation is the cheapest gate you will ever write.
- Drift is not hypothetical: anyone with console access can create it. `plan` on a
  schedule (or `terraform plan -detailed-exitcode` in CI) is how you catch it.

## Portfolio prompt

"Local provider, real habits": show init→apply→drift→reconcile as one narrative with the
plan output as your centerpiece. Then a paragraph on the EKS study: what you would guard
before applying anything real.

## Interview question

*"A teammate changed a load balancer setting in the AWS console during an incident. What
does Terraform see now, what are your two options, and what would you check before
choosing?"*
