output "index_path" {
  description = "Where the generated index page lives."
  value       = local_file.index.filename
}

output "runtime_conf_hash" {
  description = "Content hash of runtime.conf — watch it change when drift is corrected."
  value       = local_file.runtime_conf.content_sha1
}
