terraform {
  required_version = ">= 1.6.0"
  # No backend: this lab's state stays in this folder, on your disk, on purpose.
  required_providers {
    local = {
      source  = "hashicorp/local"
      version = "~> 2.5"
    }
  }
}
