# Lab 09 — infrastructure code that is REALLY, FREE-TO-APPLY local.
# The local provider writes files on your own machine: you can run the full
# init -> fmt -> validate -> plan -> apply -> destroy loop with zero cloud, zero cost,
# zero credentials — and every habit transfers 1:1 to real providers.

locals {
  files_dir = "${path.module}/generated"
  page_title = "Site: ${var.site_name}"
}

resource "local_file" "index" {
  filename = "${local.files_dir}/index.html"
  content = templatefile("${path.module}/index.html.tftpl", {
    site_name  = var.site_name
    title      = local.page_title
    replicas   = var.replicas
  })
}

# This one is deliberately NOT created with a template — you will meet it again
# in the drift exercise, where YOU are the out-of-band change.
resource "local_file" "runtime_conf" {
  filename = "${local.files_dir}/runtime.conf"
  content  = "site=${var.site_name}\nreplicas=${var.replicas}\nlog_level=info\n"
}
