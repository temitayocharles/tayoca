# Lab 09 — inputs with validation. Validation is your cheapest safety gate:
# it rejects nonsense BEFORE any plan or apply is possible.
variable "site_name" {
  description = "Short name used in file paths and content."
  type        = string
  default     = "bbf-lab"

  validation {
    condition     = can(regex("^[a-z][a-z0-9-]{2,20}$", var.site_name))
    error_message = "site_name must be 3-21 chars, lowercase alphanumerics/hyphens, start with a letter."
  }
}

variable "replicas" {
  description = "How many copies of the app this configuration describes."
  type        = number
  default     = 2

  validation {
    condition     = var.replicas >= 1 && var.replicas <= 9 && floor(var.replicas) == var.replicas
    error_message = "replicas must be a whole number between 1 and 9."
  }
}
