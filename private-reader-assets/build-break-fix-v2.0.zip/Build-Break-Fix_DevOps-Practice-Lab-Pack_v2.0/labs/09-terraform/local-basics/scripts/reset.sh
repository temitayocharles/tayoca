#!/usr/bin/env bash
# Lab 09 — destroy managed files, restore originals, remove state. Local and free.
set -euo pipefail
cd "$(dirname "$0")/.."
terraform destroy -auto-approve >/dev/null 2>&1 || true
[[ -f main.tf.bak ]] && mv main.tf.bak main.tf
[[ -f variables.tf.bak ]] && mv variables.tf.bak variables.tf
rm -rf generated .terraform .terraform.lock.hcl terraform.tfstate*
echo "Lab 09 local-basics reset complete."
