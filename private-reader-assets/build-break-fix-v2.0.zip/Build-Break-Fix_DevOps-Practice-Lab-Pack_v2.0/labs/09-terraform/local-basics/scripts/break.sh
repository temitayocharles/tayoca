#!/usr/bin/env bash
# Lab 09 — activate one of three faults.
#   1) bad formatting (fmt -check fails)
#   2) type/validation failure (validate/plan fails)
#   3) DRIFT: requires you to have run `apply` first; edits runtime.conf out-of-band
set -euo pipefail
cd "$(dirname "$0")/.."

mode="${1:-1}"
case "$mode" in
  1)
    cp -n main.tf main.tf.bak && cp broken/main.tf.badfmt main.tf
    echo "BREAK 1 active. Prove it:  terraform fmt -check -diff   (then read the diff)" ;;
  2)
    cp -n variables.tf variables.tf.bak && cp broken/variables.tf.badtype variables.tf
    echo "BREAK 2 active. Prove it:  terraform validate   (then: terraform plan)" ;;
  3)
    if [[ ! -f generated/runtime.conf ]]; then
      echo "Run 'terraform init && terraform apply -auto-approve' first, then re-run break 3." >&2
      exit 1
    fi
    cp -n generated/runtime.conf generated/runtime.conf.bak
    printf 'site=%s\nreplicas=99\nlog_level=debug\n# edited by hand during an incident\n' \
      "$(grep -oP 'site=\K.*' generated/runtime.conf || echo bbf-lab)" > generated/runtime.conf
    echo "BREAK 3 active: runtime.conf changed OUT OF BAND (replicas=99)."
    echo "Prove it:  terraform plan   — read what Terraform intends to do about it." ;;
  *) echo "usage: ./scripts/break.sh [1|2|3]" >&2; exit 2 ;;
esac
