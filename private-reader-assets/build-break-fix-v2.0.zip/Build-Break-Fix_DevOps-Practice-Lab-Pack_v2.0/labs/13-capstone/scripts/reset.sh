#!/usr/bin/env bash
# Lab 13 — full reset: remove the namespace (everything in the lab lived inside it).
set -euo pipefail
kubectl delete ns bbf-capstone --ignore-not-found
echo "Lab 13 reset complete. Re-run the lab with: kubectl apply -f release/"
