#!/usr/bin/env bash
# Lab 13 — the acceptance check. Run it after release, after each fix, and at the end.
# Each check prints PASS/FAIL with the evidence that decided it. Exit 0 only when all pass.
set -uo pipefail
NS=bbf-capstone
DEPLOY=api

say()  { printf '%-4s %s\n' "$1" "$2"; }
pass=0; fail=0
ck() { # verdict(0/1) label
  if [[ "$1" == 0 ]]; then say PASS "$2"; pass=$((pass+1)); else say FAIL "$2"; fail=$((fail+1)); fi
}

echo "== capstone acceptance — $NS =="

# 1. rollout complete
if kubectl rollout status deploy/$DEPLOY -n $NS --timeout=5s >/dev/null 2>&1; then ck 0 "1. rollout progress complete"; else ck 1 "1. rollout progress complete (rollout status fails — 'kubectl rollout status deploy/$DEPLOY -n $NS' for why)"; fi

# 2. pods running & ready
ready=$(kubectl get pods -n $NS -l app=$DEPLOY --no-headers 2>/dev/null | awk '$2=="2/2"||$2=="1/1"{c++} END{print c+0}')
total=$(kubectl get pods -n $NS -l app=$DEPLOY --no-headers 2>/dev/null | wc -l | tr -d ' ')
if [[ "$total" -gt 0 && "$ready" == "$total" ]]; then ck 0 "2. pods ready ($ready/$total)"; else ck 1 "2. pods ready ($ready/$total) — statuses: $(kubectl get pods -n $NS -l app=$DEPLOY --no-headers 2>/dev/null | awk '{print $3}' | sort -u | tr '\n' ' ')"; fi

# 3. service endpoints non-empty
eps=$(kubectl get endpoints api -n $NS -o jsonpath='{.subsets[*].addresses[*].ip}' 2>/dev/null)
if [[ -n "$eps" && "$eps" != " " ]]; then ck 0 "3. service has endpoints ($eps)"; else ck 1 "3. service has endpoints (<none> — selector vs labels: kubectl describe svc api -n $NS)"; fi

# 4. /health through the service returns 200 (via a temporary port-forward)
PF_PORT=18181
kubectl port-forward -n $NS svc/api $PF_PORT:80 >/dev/null 2>&1 &
PF_PID=$!
code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 4 "http://127.0.0.1:$PF_PORT/health" 2>/dev/null || echo 000)
kill $PF_PID 2>/dev/null || true
if [[ "$code" == "200" ]]; then ck 0 "4. /health through Service -> HTTP 200"; else ck 1 "4. /health through Service -> HTTP ${code} (refused/timeout means port chain: containerPort vs targetPort)"; fi

# 5. configuration delivered (greeting from the ConfigMap reached the process)
greet=$(kubectl logs -n $NS deploy/$DEPLOY --tail=20 2>/dev/null | grep -o 'greeting=[^ ]*' | head -1)
if [[ -n "$greet" && "$greet" != "greeting=(unset)" ]]; then
  ck 0 "5. config delivered ($greet)"
else
  ck 1 "5. config delivered (${greet:-no greeting line in logs} — the env var never arrived: check configMapKeyRef key vs the ConfigMap's actual keys)"
fi

echo
echo "result: $pass passed, $fail failed"
[[ "$fail" -eq 0 ]] && echo "RELEASE VERIFIED — recovery proven. Paste this into EVIDENCE-LOG.md."
exit $(( fail > 0 ))
