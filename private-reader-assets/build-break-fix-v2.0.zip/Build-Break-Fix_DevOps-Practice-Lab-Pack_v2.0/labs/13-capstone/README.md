# Lab 13 — Integrated Capstone: The Full Loop Under Pressure

**Loop stage:** ALL FOUR, in one sitting, against a release that is lying to you.
**You will keep:** proof — an evidence log you wrote yourself — that you can run the
entire BUILD → BREAK → FIX → EXPLAIN loop without help.

## The scenario (read once, then start)

You are on call for a small platform. A release goes out at 16:45 Friday: the API's
"v2" rollout to the `bbf-capstone` namespace. At 16:47 the release pipeline is green,
but the on-call dashboard has gone dark for that service, and a colleague reports
`curl` failing. The pipeline's opinion and reality disagree — your job is to make
reality win, with evidence.

Three faults shipped together (you will discover them in whatever order the cluster
reveals them). You have: kubectl, the evidence log template, and the discipline from
twelve labs.

## Prerequisites

kind cluster `bbf` up (Lab 05), `bbf-sample-api:local` loaded (Lab 05 `scripts/load.sh`).

## Release (this applies the broken state)

```bash
cd labs/13-capstone
kubectl apply -f release/
kubectl rollout status deploy/api -n bbf-capstone --timeout=30s || true
./scripts/verify.sh          # the formal acceptance check — it FAILS; that is the lab
```

## Your working method (no skipping)

1. Open `EVIDENCE-LOG.md`; write the incident start time.
2. Run `./scripts/verify.sh`; record every failing check verbatim.
3. Diagnose with evidence only: `get` / `describe` / `logs` / `get events` / `get endpoints`.
   For EACH fault, write in the log BEFORE fixing: symptom → evidence lines → hypothesis
   → planned fix.
4. Fix (the fixes/ folder is SEALED until your hypotheses are written — see solutions).
5. Re-run `./scripts/verify.sh` after each fix; record which checks flip to green.
6. Full green = recovery proof. Paste it. Write the prevention lesson for each fault.
7. Fill the portfolio story and interview narration at the bottom of the log.

## Acceptance criteria (what verify.sh enforces)

| # | Check | Proves |
|---|---|---|
| 1 | Deployment `api` progress complete | rollout actually finished |
| 2 | All pods Running & Ready | runtime is healthy, not just "no errors" |
| 3 | Service `api` has non-empty endpoints | labels wire traffic to pods |
| 4 | `/health` through the Service returns 200 | a USER can reach it |
| 5 | Pod logs show `greeting=...` from the ConfigMap | configuration delivered |

## Reset (also the "cleanup" discipline from every lab, in one place)

```bash
./scripts/reset.sh          # deletes the namespace; nothing else lingers
```

Full end-of-book teardown: `kind delete cluster --name bbf` plus `labs/reset-all.sh`.

## Why this capstone matters

Interviews and real incidents share a shape: several unrelated failures wearing one
symptom ("it's down"). The skill is decomposition with evidence — not guessing, not
 googling faster. You have now practiced it across networking, containers, Kubernetes,
 Terraform, CI, observability, security, and AI boundaries.

Complete `EVIDENCE-LOG.md` in full. It is the single strongest artifact this book
produces. Put it in your portfolio.
