# Lab 13 fixes — SEALED

Do not open this folder until EVIDENCE-LOG.md contains a written hypothesis for every
fault you found. The fixes are deliberately three one-line changes; the value was never
in the diff.

- `fix-A-image.yaml`   — patch the image tag
- `fix-B-config.yaml`  — align the ConfigMap key
- `fix-C-service.yaml` — align targetPort

Apply in any order; re-run `../scripts/verify.sh` after each one and watch which
acceptance check flips. If a fix does not change verify.sh output, you fixed a suspicion,
not a fault.
