# Lab 13 — Incident Evidence Log

> Fill this as you work. Do not write it afterwards from memory — the value is in the
> contemporaneous record. This completed log is a portfolio artifact as-is.

## Incident header

- Start time: ____  End time: ____
- Release applied: `kubectl apply -f release/` at ____
- First failing verify.sh output (paste verbatim):

```
(paste)
```

## Fault 1 (discovered first)

- Symptom (one sentence, user perspective):
- Commands run, in order, with the decisive output lines:

```
(paste evidence)
```

- Hypothesis (written BEFORE the fix):
- Fix applied:
- Verify.sh check(s) that flipped to green:
- Prevention lesson:

## Fault 2

- Symptom:
- Evidence:
- Hypothesis:
- Fix:
- Verification change:
- Prevention lesson:

## Fault 3

- Symptom:
- Evidence:
- Hypothesis:
- Fix:
- Verification change:
- Prevention lesson:

## Recovery proof

Paste the final `./scripts/verify.sh` output here:

```
(paste — must show 5 passed, 0 failed, RELEASE VERIFIED)
```

## Portfolio story (120–180 words)

I was on call for ______ when ______. The pipeline said ______ but the evidence showed
______. I isolated ______ by ______, then ______, then ______. Recovery was proven by
______. To prevent recurrence I would ______.

## Interview narration (STAR, 60 seconds spoken)

- Situation:
- Task:
- Action (evidence first, no guessing):
- Result (with numbers if you have them):
- Reflection (what you would do faster next time):
