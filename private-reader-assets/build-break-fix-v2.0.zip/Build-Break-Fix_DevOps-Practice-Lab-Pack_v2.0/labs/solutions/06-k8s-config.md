# Solution — Lab 06 · Configuration & Resources

> Stop. All three layers matched with evidence? If not, close this file.

## bbf-config-broken → CreateContainerConfigError

**Layer: configuration.** `kubectl describe pod` → `Reason: CreateContainerConfigError`,
message names `configmap "api-config" not found`. The Deployment referenced a ConfigMap
that was never applied **into that namespace** (ConfigMaps are namespaced — the one from
the working lab lives in `bbf-config`, not here).
**Fix:** apply the ConfigMap into the right namespace. **Prevention:** smoke Jobs +
`kubectl apply` order discipline; in GitOps, the manifest set is atomic so this class
mostly disappears.

## bbf-config-oom → OOMKilled / CrashLoopBackOff

**Layer: runtime resources.** describe shows `Last State: Terminated, Reason: OOMKilled,
Exit Code: 137`; logs are empty or truncated — the kernel killed the process mid-boot.
The 16Mi limit is below Node's floor (~40+MB RSS just to start).
**Fix:** raise the limit to a defensible floor (128–256Mi) based on measurement, not
hope; keep requests honest. **Prevention:** load-test once, set limits from data, alert
on usage approaching limits.

## bbf-config-pending → Pending / Unschedulable

**Layer: scheduling.** Pods exist in the API but were never placed: describe events show
`0/1 nodes are available: insufficient cpu`. Nothing is wrong with the container — the
cluster cannot honor the request (32000m on a laptop-sized node).
**Fix:** right-size the request to real need + headroom. **Prevention:** quotas and
LimitRanges make absurd requests visible at admission instead of as silent queueing.

## The table to memorize

| Status | Reason | Layer | First command |
|---|---|---|---|
| CreateContainerConfigError | config ref unresolvable | configuration | `describe pod` (message) |
| CrashLoopBackOff + OOMKilled 137 | kernel kill | resources | `describe pod` (Last State) |
| Pending / Unschedulable | no node fits | scheduling | `describe pod` (Events) |
| CrashLoopBackOff + logs exist | app exits nonzero | application | `logs` (+ `--previous`) |
