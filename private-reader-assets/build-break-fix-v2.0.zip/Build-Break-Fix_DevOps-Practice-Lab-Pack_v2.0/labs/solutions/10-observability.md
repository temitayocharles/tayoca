# Solution — Lab 10 · Observability

> Stop. Hypothesis written? If not, close this file.

## The break — LOG_LEVEL=error

**What vanished:** every `info` line — `server listening`, `request received`, and the
crucial `request handled` (with status). **What stayed:** `error` lines (`work failed`)
and the `/metrics` counters, which don't depend on the log level at all.

**Why it's dangerous at 03:00:** you can still SEE failures (errors) but no longer
measure their RATE (no handled lines → no denominator), and can't correlate by req_id
across the full request lifecycle. Error-only logs feel efficient and quietly destroy
error-rate math.

**Fix:** restart with `LOG_LEVEL=info`. **Proof:** before/after `grep -c '"msg":"request
handled"'` matches the metrics delta for the same load.

## The three-signal doctrine (the takeaway)

- **Health** answers "is it up NOW?" — one bit, instant, tells you nothing about why.
- **Metrics** answer "how much, how often, trending?" — survive log-level breaks; lose
  the why.
- **Logs** answer "why, for THIS request?" — die to log-level breaks; need `req_id` to
  correlate.
A system you can only observe one way is a system you cannot debug under pressure.

## Answers to the interview probe

Slow-user complaints with green dashboards: metrics here count requests, not latency.
You'd add a duration field to `request handled` lines (and/or a histogram metric), then
grep/aggregate by duration to find the slow slice. The lab's app deliberately omits
timing — noticing that omission IS the exercise.

## Extra credit you actually did

You computed an error rate from logs (step 2 of analyze.sh) and cross-checked it against
`bbf_status_total` — two independent sources agreeing is what turns a number into
evidence.
