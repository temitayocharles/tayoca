# Solution — Lab 05 · Kubernetes Delivery

> Stop. Hypothesis written? If not, close this file.

## Fault 1 — selector typo (`app: apis`)

**Fault class:** Service→Pod wiring (labels), the K8s name-resolution layer.
**Evidence chain:**
- `kubectl get endpoints api-broken -n bbf-delivery` → `ENDPOINTS <none>` — the Service
  found zero pods. This single line is the verdict.
- `kubectl describe svc api-broken` → `Selector: app=apis`
- `kubectl get pods --show-labels` → pods carry `app=api`
**Fix:** correct the selector to `app: api`. **Proof:** endpoints populate with pod IPs;
curl via port-forward returns 200.

## Fault 2 — targetPort 9999

**Fault class:** port chain inside the cluster — same lesson as Lab 02, one layer deeper.
**Evidence chain:** pods Running/Ready; endpoints POPULATED (labels are fine!); curl
through the service gets **connection refused** — because kube-proxy forwarded to
pod:9999 where the OS refused. The app's own log line `listening on 0.0.0.0:3000`
completes the triangle: containerPort (3000) ≠ targetPort (9999).
**Fix:** targetPort 3000. **Proof:** same curl now 200.

## The transferable map

Symptom → first suspicion:
- Endpoints `<none>` → selector/labels (describe both sides)
- Endpoints full + refused → port chain (logs vs targetPort)
- Endpoints full + timeout → network policy / wrong address family (out of scope; name it)

## Interview one-liner

"I check the Service's endpoints first: `<none>` means the selector found no pods —
label mismatch; populated-but-refused means labels are fine and the port chain is lying.
`kubectl get endpoints` separates the two in one command."
