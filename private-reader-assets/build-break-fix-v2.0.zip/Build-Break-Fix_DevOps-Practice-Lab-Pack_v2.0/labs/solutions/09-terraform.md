# Solution — Lab 09 · Terraform

> Stop. Table filled? If not, close this file.

## Fault 1 — fmt

`terraform fmt -check` exits non-zero; `-diff` prints the reformatting. Nothing is
semantically wrong — that's the point: format gates are cheap discipline that keeps
diffs honest and reviews fast. **Fix:** `terraform fmt`. **Prevention:** pre-commit hook
or CI gate.

## Fault 2 — type + validation faults

`terraform validate` (and plan) reject: `replicas` default `"three"` is a string where a
number is declared, and `site_name` `"BBF-Lab-01"` fails the lowercase regex. Validation
errors appear BEFORE any resource planning — the cheapest possible failure.
**Fix:** correct the values. **Prevention:** always declare types; add `validation`
blocks for business rules.

## Fault 3 — drift (the lesson that transfers)

After hand-editing `runtime.conf` (replicas=99), `terraform plan` reports roughly:

```
local_file.runtime_conf: Refreshing state... [id=...]
~ resource "local_file" "runtime_conf" {
      content = <<-EOT
          site=bbf-lab
        - replicas=2
        + replicas=99
          log_level=info
        + # edited by hand during an incident
    }

Plan: 0 to add, 1 to change, 0 to destroy.
```

Terraform KNOWS because state records the content hash it last wrote; the real file
disagrees; the plan proposes an in-place update to reconcile.

**The two legitimate responses:**
- `terraform apply` — declaration wins; the hotfix is reverted. Right when the out-of-band
  change was wrong or unreviewed.
- Change the .tf source — reality wins; the hotfix was correct and must be adopted.
  Right when the change was a good fix someone made under pressure.

Choosing is an engineering decision; doing neither leaves a lying state file.

## Interview one-liner

"Drift means state and reality disagree. I read the plan to see which side is right:
if the hotfix was wrong I apply to revert; if it was right I adopt it into the module —
and then I find out WHO changed it out-of-band, because that process gap is the real
incident."
