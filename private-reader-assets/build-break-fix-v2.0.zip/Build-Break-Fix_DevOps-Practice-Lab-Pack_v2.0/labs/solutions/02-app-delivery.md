# Solution — Lab 02 · Local Application Delivery

> Stop. Hypothesis written? If not, close this file.

## Break 1 — app listens on 4000, mapping still 3000:3000

**Fault class:** port chain mismatch (container runtime layer).

**Evidence chain:**
- `docker ps` — container `Up` (running ≠ reachable)
- `docker logs` — `[bbf-sample-api] listening on 0.0.0.0:4000` ← the decisive line
- `docker port <c>` — `3000 -> 3000` mapping exists but forwards to a silent port
- `curl` exit 7 — the *host-side* 3000 forwards into the container's 3000, where nothing
  listens; the container's own OS refuses.

**Fix:** make the chain agree — either `docker run -p 3000:4000` or restore `PORT=3000`.

**Recovery proof:** `curl -i http://localhost:3000/health` → `200` with the same body as
the bare-process run.

## Break 2 — compose maps 3000:8080

Same class, opposite side: the app listens on 3000 (its logs say so); the mapping
forwards to 8080. `docker compose ps` even shows the port mapping, confident and wrong.
Fix the mapping or the app env — one, deliberately.

## Prevention

- One source of truth for the port (an env var), referenced by image and mapping.
- A healthcheck (`wget -q http://127.0.0.1:3000/health`) converts this silent failure
  into a visible `unhealthy` state within seconds.

## Interview one-liner

"Running is a process fact; reachable is a network fact. I prove reachable with a
user-path request, and when it fails I check three ports in order: what the app says it
listens on, what the mapping forwards to, and what I actually dialed."
