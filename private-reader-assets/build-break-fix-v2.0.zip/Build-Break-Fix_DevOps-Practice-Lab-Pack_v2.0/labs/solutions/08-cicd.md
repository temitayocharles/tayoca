# Solution — Lab 08 · CI/CD

> Stop. Table filled? If not, close this file.

## Fault 1 — working-directory: src

**Class: pipeline context.** Locally: stage 2 fails with "no such file or directory"
when npm looks for package.json in the wrong folder. In GitHub Actions the step log
shows `ENOENT ... package.json` with the job's workspace path — the path IS the evidence.
**Fix:** `working-directory: app` (or restructure the repo). The code was never broken.

## Fault 2 — `npm instal`

**Class: typo, fails fast.** Stage/step fails at the typo'd step with
`instal: command not found` (exit 127). Boring, and common. Fix the letter. The lesson
isn't the typo — it's reading WHICH step failed and trusting it.

## Fault 3 — the wrong expectation

**Class: test defect (the interesting one).** The suite fails with an assertion:
`Expected values to be strictly equal: 201 !== 200`. The app is RIGHT (Lab 02's contract
says /health returns 200); the TEST is wrong. "Make it green" energy would have you
change the app to break its contract — the discipline is deciding who owns the truth
before touching either.
**Fix:** the assertion → 200. **Prevention:** contract tests pin behavior; when red,
first ask "did the contract change, or the code regress?"

## Reading a red build like an operator

1. Which JOB failed (test vs build — `needs:` may have blocked others, that's not their
   failure).
2. Which STEP (the log's collapsing structure is the stage→step map).
3. The FIRST error line in that step — above it is context, below it is noise.
4. Classify: pipeline context / typo / code / test / dependency / environment.

## Interview one-liner

"A red pipeline is information, not an emergency. I find the job, the step, the first
error line — and before changing anything I decide whether the code, the test, or the
pipeline is the one telling the truth."
