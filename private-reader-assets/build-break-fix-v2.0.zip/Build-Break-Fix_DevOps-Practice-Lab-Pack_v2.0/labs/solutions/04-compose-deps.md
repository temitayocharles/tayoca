# Solution — Lab 04 · Compose Dependencies

> Stop. Hypothesis written? If not, close this file.

## Mode 1 — healthcheck on the wrong port

**Fault class:** health gate that can never pass.
**Evidence:** `docker compose ps -a` shows api stuck in `health: starting` then
`(unhealthy)`, and reporter never created. The decisive evidence:
`docker inspect <api> --format '{{json .State.Health}}'` — probe exit code non-zero, log
shows the wget against `:8080` while the app logs say `listening on 0.0.0.0:3000`.
**Fix:** align healthcheck port (3000). **Prevention:** the healthcheck and the app
config should derive from one place (an ARG/ENV), exactly like Lab 02's lesson.

## Mode 2 — order-only depends_on

**Fault class:** wrong dependency SEMANTICS (start order, not success).
**Evidence:** with `docker compose logs -t`, the api's `listening` line has an earlier
timestamp than the migrator's `migration complete` line — the race is measurable, not
hypothetical. In this lab the app tolerates it; real apps crash on missing schemas, which
is exactly why the race is dangerous (it wins sometimes).
**Fix:** `condition: service_completed_successfully` (jobs) or `service_healthy`
(services).

## Mode 3 — migrator exits 3

**Fault class:** dependency FAILURE surfaced honestly.
**Evidence:** `docker compose ps -a` — migrator `Exited (3)`; api created but blocked/not
started; compose's own error names the failed condition. The migrator's log line
`migration-failed-locked` is the root cause; the exit code is the contract.
**Fix:** fix the migration (here: the seeded failure), re-up. Compose retries nothing by
default — deliberate, correct behavior for a failed gate.

## Interview one-liner

"`depends_on` alone is start order. For real dependencies I gate on
`service_completed_successfully` for one-shot jobs and `service_healthy` for services —
otherwise I've built a race that only fails on the nights I'm on call."
