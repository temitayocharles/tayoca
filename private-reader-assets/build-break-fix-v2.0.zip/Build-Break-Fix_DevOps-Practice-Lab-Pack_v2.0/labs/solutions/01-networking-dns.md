# Solution — Lab 01 · Networking & DNS

> Stop. Hypothesis written? If not, close this file.

## Break scenario (container renamed)

**Fault class:** name resolution (DNS), user-defined Docker network.

**Why the evidence proves it:** the client container reports `bad address` (or nslookup
returns NXDOMAIN) for the old name — the failure happens while *turning a name into an
address*, before any packet aims at a port. Connection refused is impossible here: being
refused requires reaching an address, and no address was ever produced.

**The fix:** recreate/alias the container under the expected name
(`docker run --name bbf-alpha` or `--network-alias`), or update the client to the new
name. Either side can move — but change *one* side deliberately.

**Prevention:** treat service names as API contracts. In Compose/K8s, the name IS the
discovery mechanism — document names alongside ports, and add a startup check that
resolves its dependencies (`getent hosts db`) before an app serves traffic.

## Exit-code table (fill-from-memory answer)

| Observation | curl exit | Layer |
|---|---|---|
| Could not resolve host | 6 | DNS/name resolution |
| Connection refused | 7 | transport (port closed) |
| Timeout / silence | 28 | routing/firewall/hung backend |
| HTTP 4xx/5xx | 0 | application (reachable!) |

## Interview-grade one-liner

"I classify connectivity failures by exit code first: 6 means the name never became an
address, 7 means the address answered 'nobody home', 28 means silence — three different
layers, three different first commands."
