# Solution — Lab 03 · Docker Image & Runtime

> Stop. Table filled? If not, close this file.

## Mode 1 — typo-copy

**Fault class:** BUILD failure (context/paths). `docker build` fails at `COPY
app/serv.sh ...` with `failed to compute cache key: ... not found`. Nothing ran; no
container exists. **Fix:** correct the path; guard with consistent file naming.

## Mode 2 — exec-bit

**Fault class:** RUNTIME start failure. Build succeeds; container exits immediately.
`docker run` exit code **126**; `docker logs` shows `/bin/sh: /usr/local/bin/serve.sh:
Permission denied`. **Fix:** `RUN chmod +x` in the Dockerfile (deterministic) rather than
fixing the bit on your machine (non-reproducible).

## Mode 3 — app-fails

**Fault class:** APPLICATION failure. Exit code **1** with a real log line:
`fatal: config service unreachable on start`. The container did its job; the process
decided not to run. **Fix:** the dependency, not the image — but also consider: a
process that cannot start usefully should fail fast and loudly, exactly like this.

## The separation that matters

| Failure | Stage | Exit | Where the truth lives |
|---|---|---|---|
| Path/context typo | build | builder's error | build log (COPY line) |
| Permission/PATH | container start | 126 / 127 | `docker logs` + exit code |
| App gives up | running | app's choice (1, 7...) | `docker logs` (the message) |
| Kernel kill | running | 137 + `OOMKilled=true` | `docker inspect .State` — logs stay silent |

## Interview one-liner

"126 and 127 mean the OS never ran my app — image problem. An app-chosen exit code means
the app ran and refused — read its logs. OOMKilled means the kernel intervened and logs
won't explain it; inspect state instead."
