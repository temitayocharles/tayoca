# Solutions — sealed by convention, protected by your own discipline

Open the file for a lab ONLY after you have written your hypothesis in the lab README's
"investigate" section or in your debugging log. The reveal order is always:

1. **Fault class** — one line naming the layer.
2. **Why the evidence proves it** — the lines you should have collected.
3. **The fix** — usually small.
4. **The prevention** — usually the part worth more than the fix.

If you open a solution before hypothesizing, you traded a skill for a spoiler. The labs
are the product; the answers are just the answer key.

| Lab | File |
|---|---|
| 01 Networking & DNS | `01-networking-dns.md` |
| 02 App delivery | `02-app-delivery.md` |
| 03 Image & runtime | `03-image-runtime.md` |
| 04 Compose dependencies | `04-compose-deps.md` |
| 05 K8s delivery | `05-k8s-delivery.md` |
| 06 K8s config & resources | `06-k8s-config.md` |
| 07 K8sQuest | `07-k8squest.md` |
| 08 CI/CD | `08-cicd.md` |
| 09 Terraform | `09-terraform.md` |
| 10 Observability | `10-observability.md` |
| 11 Security & secrets | `11-security.md` |
| 12 AI ops boundary | `12-ai-ops.md` |
| 13 Capstone | `13-capstone.md` |
