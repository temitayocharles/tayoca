# Solution — Lab 07 · K8sQuest (all four)

> Stop. Quest table filled, hypotheses written? If not, close this file.

## Q1 — ImagePullBackOff

**Fault class: image supply.** Status column says `ImagePullBackOff`; describe's Events
show `Failed to pull image ... not found` then back-off. The tag `v9.9.9` was never
built/pushed — and with `imagePullPolicy: Always`, kind cannot fall back to a local copy.
**Fix:** point at a real tag (`bbf-sample-api:local`, policy IfNotPresent).
**Prevention:** tags are contracts; pipelines should verify existence (or build+push
atomically) before rollout.

## Q2 — CrashLoopBackOff with a message

**Fault class: application failure.** Logs contain
`FATAL: port 3000 already in use (bind: EADDRINUSE)` and exit 1; restarts climb because
K8s restarts failed containers with back-off — by design, not by bug. The `command:`
override in the manifest simulates an app that cannot bind its port.
**Fix:** remove/repair the override (in real life: fix the bind conflict or the config
that caused it). `--previous` logs matter when the current container restarted so fast
its logs look empty.

## Q3 — healthy on paper, refused in fact

**Fault class: port chain (env override vs declared ports).** Endpoints are populated;
pods Ready; but the app's logs say `listening on 0.0.0.1:4000`... precisely: PORT=4000
while `containerPort: 3000` and `targetPort: 3000`. The refusal is born in the pod's
network namespace — the Service faithfully forwarded to a closed door.
**Fix:** make the env PORT, containerPort and targetPort agree (one source of truth).
This is Lab 02's lesson surviving into Kubernetes — the tools change, the port chain
does not.

## Q4 — the vanished rollout

**Fault class: scheduling (again, deliberately).** New ReplicaSet created; its pods sit
`Pending`; the old ReplicaSet scaled to 0 per rolling-update maxUnavailable — so total
available replicas = 0 with zero crashes. describe events: `Insufficient cpu`
(request: 16000m). **Fix:** right-size the request.
**Prevention:** capacity awareness — a request larger than any node is a typo wearing a
tie; admission checks (`LimitRange`) catch it early.

## The meta-lesson

Four quests, four layers — supply, application, network path, scheduling — and only one
of them shows anything in `kubectl get pods` that names the truth. `describe` (Events +
Last State) is where the cluster confesses; logs are where the app confesses; endpoints
are where the wiring confesses. Three confession booths; visit them in order.
