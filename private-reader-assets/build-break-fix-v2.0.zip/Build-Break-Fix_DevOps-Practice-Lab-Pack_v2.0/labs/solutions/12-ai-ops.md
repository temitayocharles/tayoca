# Solution — Lab 12 · AI-Ops Boundary

> Stop. Six attacks attempted, two design gaps written? If not, close this file.

## Why each refusal fired

- `delete pod`, `apply`, `scale` → **mutating verb list**: the engine never runs verbs
  that change state; it prints the exact command for a human to review.
- `get secret`, `describe secret/...` → **secret markers checked BEFORE verbs**: a
  secret read is worse to leak than a pod delete is to do, so that rule runs first.
- `--raw`, `-w` → **flag allowlist**: unknown flags can change behavior (`--raw` bypasses
  formatting; `-w` never terminates and would hang automation).
- `exec ... -- sh` → exec is not on the read allowlist at all — arbitrary code in a pod
  is the opposite of read-only.

## The design gaps you were asked to find (two strong examples)

1. **Output-side leakage:** `get deploy -o yaml` can embed env var values, secret NAMES,
   and annotations. A stricter engine would block `-o yaml/json` or scrub known
   sensitive paths from output before it reaches a model.
2. **Indirection:** a malicious suggestion can route around kubectl entirely ("run this
   curl against the API server with the token at ~/.kube/config"). The boundary only
   governs what flows through IT; host-level least privilege (no admin kubeconfig for
   the assistant's user) is the real defense-in-depth.

Also worth naming: the allowlist trusts `kubectl` on PATH (PATH poisoning), and there is
no rate limit or namespace scoping by default — both fine to tighten via `policy.json`
and RBAC.

## The audit log's job

`.audit/bbf-ai-ops-audit.jsonl` turns "what did the AI do?" into `grep`. Every allow AND
refusal is recorded with a reason — refusal records matter as much: they're the evidence
the gate worked.

## Interview one-liner

"I let assistants read (get/describe/logs/top via an allowlist), never mutate, never see
secrets — enforced in code the model can't negotiate with, logged per decision, and
backed by RBAC so even a bypass hits least privilege."
