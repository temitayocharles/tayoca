# Solution — Lab 11 · Security & Secrets

> Stop. Findings ranked, hypothesis written? If not, close this file.

## The four findings, ranked (the ranking is the answer)

1. **`.env` with a DB URL+password** — highest: credential material, whole-file leak.
2. **AKIA-pattern key ID in config.json** — key IDs alone are not secrets, but they
   prove a secret EXISTS somewhere nearby and identify the account. Treat as incident.
3. **`token` assignment in config.json** — a live-looking token in source.
4. **Missing `.gitignore` for `.env`** — not a leak itself; the door left open.

## Why rotation precedes history cleanup

Deleting the file (or rewriting git history) does not un-leak it: clones, forks, CI
caches, and scrapers may already hold it. Rotation makes the leaked value worthless;
history cleanup then reduces future exposure. Reverse the order and you spend hours
scrubbing a key that stayed valid the whole time.

## `.gitignore`'s actual rule

It prevents *unstaged* files from being added — it never removes tracked files and does
nothing about a file already committed. `git rm --cached .env` + commit + rotate is the
minimum honest response.

## base64 is not encryption

`base64 -d` is lossless and keyless. Kubernetes Secrets are base64 in etcd by default;
encryption at rest, RBAC scope, and short-lived credentials are the real controls. The
lab's audit blocks secret reads for exactly this reason — anyone with `get secrets` in a
namespace can decode everything in it.

## Interview one-liner

"Rotate first, then clean history — deletion doesn't un-leak. Then fix the process gap:
secrets belong in a manager or CI masked variables, an audit gate in CI catches the next
one, and least privilege limits who can read what remains."
