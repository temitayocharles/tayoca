# Solution — Lab 13 · Capstone (sealed)

> Stop. Three hypotheses written in EVIDENCE-LOG.md? If not, close this file.

## The three faults, discovery order (typical)

### Fault A — image tag `bbf-sample-api:v2` does not exist

- verify.sh: check 1 fails (rollout), check 2 fails (no pods ready)
- Evidence: `kubectl get pods -n bbf-capstone` → `ImagePullBackOff`;
  `kubectl describe pod` events → `Failed to pull image ... not found`
- Hypothesis template: "rollout stuck because the image supply failed, not the app"
- Fix: `kubectl apply -f fixes/fix-A-image.yaml` (or set image) → checks 1–2 flip green

### Fault B — ConfigMap key `greeting_text` vs reference `greeting`

- Usually revealed AFTER A (pods must attempt to start first): status
  `CreateContainerConfigError`; describe names `configmap "api-config" ... key
  "greeting" ... not found` — or pods run (if you fixed A via :local) but logs show
  `greeting=(unset)`? No — with a bad key reference the container never starts; the
  (unset) log line belongs to a *missing optional* config. The evidence line in
  describe is the verdict.
- Fix: `fixes/fix-B-config.yaml` → check 5 flips green (pod log now shows
  `greeting=welcome to the capstone release`)

### Fault C — Service targetPort 3001

- Pods Running/Ready, endpoints populated — yet check 4 shows `HTTP 000` (connection
  refused through the port-forward). Lab 05's lesson under incident pressure.
- Evidence triangle: app log `listening on 0.0.0.0:3000` + manifest `targetPort: 3001`
  + refused curl.
- Fix: `fixes/fix-C-service.yaml` → checks 3–4 flip green

## Grading your own log

- Every fault has: symptom sentence, pasted evidence, hypothesis BEFORE fix, minimal
  fix, flipped check, prevention. (6 × 3 = 18 rows of discipline.)
- Recovery proof is the full green verify.sh — user-path evidence.
- The portfolio story names the system, the three-layer decomposition, and the
  prevention ideas (tag pipeline gate; config key lint; port-chain CI check).

## The honest self-assessment

If you jumped to fixes without hypotheses, redo it — the capstone's product is your log,
not the green output. "RELEASE VERIFIED" without evidence discipline is a green command,
not a recovered system.
