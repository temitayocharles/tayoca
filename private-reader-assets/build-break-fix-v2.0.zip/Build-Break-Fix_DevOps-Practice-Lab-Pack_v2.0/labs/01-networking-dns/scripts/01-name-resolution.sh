#!/usr/bin/env bash
# Lab 01 — Names, addresses, and ports: what resolution actually does.
# Safe to run anywhere. No external network required.
set -euo pipefail

step() { printf '\n== %s ==\n' "$1"; }

step "1. A name that always resolves: localhost"
getent hosts localhost || echo "(getent found nothing for localhost — unusual)"

step "2. localhost is an alias for a loopback address"
# 127.0.0.0/8 is loopback: traffic never leaves the machine.
ping -c1 -W1 127.0.0.1 >/dev/null && echo "127.0.0.1 answers ping (loopback works)"

step "3. A name that exists because a file says so"
# /etc/hosts is the first place the resolver looks (before DNS).
grep -v '^#' /etc/hosts | sed '/^[[:space:]]*$/d'

step "4. The three-part address of any service"
# host : port / path  — three different failure domains, three different errors
printf 'http://127.0.0.1:8911/health\n'
printf '  host = 127.0.0.1   (reached by routing)\n'
printf '  port = 8911        (reached only if a process listens there)\n'
printf '  path = /health     (understood only by the application)\n'

step "Done"
echo "Key idea: DNS answers 'what address does this name have?' — nothing more."
echo "DNS knows nothing about whether a service is running."
