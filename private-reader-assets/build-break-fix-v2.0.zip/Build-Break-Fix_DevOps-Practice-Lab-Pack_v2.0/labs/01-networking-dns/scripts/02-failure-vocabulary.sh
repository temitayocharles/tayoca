#!/usr/bin/env bash
# Lab 01 — The failure vocabulary: DNS failure vs connection refused vs timeout.
# Runs a real local listener, then provokes all three errors deliberately.
# Uses only loopback and RFC 5737/3849 documentation addresses. Safe everywhere.
set -uo pipefail

step() { printf '\n== %s ==\n' "$1"; }

PORT_OK=8911        # where a real server WILL listen
PORT_CLOSED=8922    # where nothing listens
# (A routed black hole such as 192.0.2.1 — RFC 5737 docs range — often
# shows the same silence; some networks redirect it, which is worth noticing.)

step "0. Start a real listener on 127.0.0.1:$PORT_OK"
mkdir -p /tmp/bbf-lab01 && cd /tmp/bbf-lab01
python3 -m http.server "$PORT_OK" --bind 127.0.0.1 >/dev/null 2>&1 &
SERVER_PID=$!
trap 'kill "$SERVER_PID" 2>/dev/null || true' EXIT
sleep 1

code=0; curl -s -o /dev/null "http://127.0.0.1:$PORT_OK/" || code=$?
echo "curl to working listener        -> exit $code   (0 = success)"

step "1. DNS FAILURE — a name that cannot resolve"
code=0; curl -s -o /dev/null --max-time 3 "http://no-such-host.bbf.invalid/" || code=$?
echo "curl to unresolvable name       -> exit $code"
echo "meaning: the NAME never became an address. No connection was attempted."

step "2. CONNECTION REFUSED — address reachable, port closed"
code=0; curl -s -o /dev/null --max-time 3 "http://127.0.0.1:$PORT_CLOSED/" || code=$?
echo "curl to closed port             -> exit $code"
echo "meaning: the address was reached; the OS said nobody listens there."

step "3. TIMEOUT — connection succeeds, nothing answers"
# A socket that ACCEPTS connections and then never writes a byte — the same silence
# you get from a hung backend or a firewalled black hole, but reproducible anywhere.
python3 - <<'PY' &
import socket, time
srv = socket.socket()
srv.bind(("127.0.0.1", 8933))
srv.listen(5)
srv.settimeout(30)
try:
    while True:
        conn, _ = srv.accept()   # accept, then deliberately never reply
        time.sleep(30)
except Exception:
    pass
PY
BLACKHOLE_PID=$!
sleep 0.5
code=0; curl -s -o /dev/null --max-time 3 "http://127.0.0.1:8933/" || code=$?
kill "$BLACKHOLE_PID" 2>/dev/null || true
echo "curl to silent backend         -> exit $code   (28 = timed out)"
echo "meaning: no refusal, no answer. The door opened; nobody spoke."

step "4. Same vocabulary, HTTP status side"
# A server that ANSWERS with 404/502/503 is reachable — that is an application answer,
# not a connection error. Do not confuse the two layers.
code=0; curl -s -o /dev/null -w 'HTTP status: %{http_code}\n' "http://127.0.0.1:$PORT_OK/no-such-page" || code=$?
echo "curl exit                       -> $code (0: the conversation happened)"

step "Summary table"
cat <<'TABLE'
| Observation                    | curl exit | Layer            | First question to ask        |
|--------------------------------|-----------|------------------|------------------------------|
| Could not resolve host         |     6     | name resolution  | What name? Who should know it?|
| Connection refused             |     7     | transport        | Is anything listening?       |
| Timeout                        |    28     | routing/firewall | Is the path blocked or dead? |
| HTTP 4xx/5xx with exit 0       |     0     | application      | What does the server say?    |
TABLE

echo
echo "Now cover the table and reproduce all three exits from memory."
