#!/usr/bin/env bash
# Lab 01 — Container name resolution on a user-defined Docker network.
# REQUIRES Docker. Containers reach each other BY NAME only on user-defined
# networks; the default bridge has no DNS between containers.
set -euo pipefail

NET=bbf-net
step() { printf '\n== %s ==\n' "$1"; }

cleanup() {
  docker rm -f bbf-alpha bbf-pinger >/dev/null 2>&1 || true
  docker network rm "$NET" >/dev/null 2>&1 || true
}
trap cleanup EXIT
cleanup

step "1. Create a user-defined network"
docker network create "$NET"

step "2. Start a container with a NAME on that network"
docker run -d --name bbf-alpha --network "$NET" alpine sleep 120

step "3. Ask another container to reach it BY NAME"
docker run --rm --name bbf-pinger --network "$NET" alpine \
  sh -c 'nslookup bbf-alpha && ping -c1 -W2 bbf-alpha'

step "4. Ask for a name that does not exist on that network"
if docker run --rm --network "$NET" alpine sh -c 'nslookup bbf-omega'; then
  echo "unexpected: bbf-omega resolved"
else
  echo "expected: bbf-omega did NOT resolve (no such container name)"
fi

step "Break scenario (read, then try): rename the target, keep the client unchanged"
cat <<'NOTE'
If bbf-alpha is recreated as bbf-beta (same image, same everything), then:
  nslookup bbf-alpha   -> NXDOMAIN or old address
  ping bbf-alpha       -> "bad address"
The failure is a NAME failure, not a connection-refused failure: nothing was
reachable enough to be refused. Compare with Lab 02, where the name was right
and the PORT was wrong.
NOTE

step "Cleanup happens automatically on exit (trap). Verify with:"
echo "  docker network ls | grep $NET || echo 'network removed'"
