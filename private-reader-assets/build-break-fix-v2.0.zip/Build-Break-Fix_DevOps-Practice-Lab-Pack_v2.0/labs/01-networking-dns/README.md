# Lab 01 — Networking & DNS Foundations

**Loop stage:** BUILD (vocabulary) → BREAK (a name that stops resolving)
**You will keep:** the ability to classify any connectivity failure in one observation.

## Objective

Build a precise mental model of *name → address → port → path*, then practice separating the
three classic connectivity failures — DNS failure, connection refused, timeout — with real
commands and real exit codes.

## Prerequisites

- curl, python3, ping (script 01/02 run on Linux/macOS/WSL as-is)
- Docker for script 03 only

## Setup

```bash
cd labs/01-networking-dns
chmod +x scripts/*.sh
./scripts/01-name-resolution.sh
./scripts/02-failure-vocabulary.sh
```

## Expected working state

Script 02 must print, in order: `exit 0` (working listener), `exit 6` (DNS failure),
`exit 7` (refused), `exit 28` (timeout), then an HTTP `404` with curl exit `0`.
If your machine's firewall eats the timeout case, note the exit code you saw instead and
write why — that investigation is the lab.

## Break

In `scripts/03-docker-network-names.sh` (requires Docker), recreate the target container
under a new name and query the old name. Expected symptom class: *name resolution failure*
(`bad address` / NXDOMAIN) — **not** connection refused.

## Investigate — evidence checklist

1. Exact curl exit code (`echo $?` immediately after the failing curl).
2. `nslookup <name>` (or `getent hosts <name>`) — does the name resolve at all?
3. If it resolves: is anything listening? (`ss -ltn` / `netstat -ltn` on the target host.)
4. Distinguish: did packets leave at all, or did the OS answer "closed"?

**Hypothesis sentence to complete before any solution:** *"This is a ______ failure because
the evidence shows ______, which rules out ______."*

Solution path (open only after writing your hypothesis): `labs/solutions/01-networking-dns.md`.

## Fix and prove recovery

Recovery proof for connectivity is a successful request, not a happy-looking process list:
`curl -i` returning an HTTP status line with exit code `0`.

## Reset

Scripts clean up after themselves (the Docker script traps its own cleanup). If you
interrupted one: `docker rm -f bbf-alpha bbf-pinger; docker network rm bbf-net`.

## Prevention lesson

Document which names a system depends on (service names, aliases, domains) the same way you
document ports. Most "the network is down" reports are one name failing to resolve.

## Portfolio prompt

Write the exit-code table from memory and annotate each row with one incident-style sentence
you personally triggered.

## Interview question

*"Without ping or a browser, how would you tell DNS failure from connection refused from a
timeout — and which single piece of evidence do you trust most?"*
