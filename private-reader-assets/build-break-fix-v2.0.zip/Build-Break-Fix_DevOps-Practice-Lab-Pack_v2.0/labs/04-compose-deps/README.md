# Lab 04 — Compose Service Dependencies

**Loop stage:** BUILD (a dependency chain that actually holds) → BREAK (three ways chains lie)
**You will keep:** the difference between *started*, *exited successfully*, and *healthy* —
and why plain `depends_on` is usually not what you meant.

## Objective

Wire a one-shot migration job → API → verification reporter with correct conditions, then
break each link and learn what each failure looks like in `docker compose ps` and `logs`.

## Prerequisites

Docker with Compose v2 (`docker compose version`). Lab 02's sample app is referenced by
path — no copy needed.

## Setup — expected working state

```bash
cd labs/04-compose-deps
docker compose up --build -d
docker compose ps -a          # migrator: Exited (0); api: Up (healthy); reporter: Exited (0)
curl -i http://localhost:3010/health   # 200 OK
docker compose logs reporter  # reporter-ready-api-healthy-schema-ready
```

Success criteria (all three, or the chain did not hold):

1. `migrator` shows status `Exited (0)` — success, not just "ran".
2. `api` shows `(healthy)` — not `(health: starting)` forever.
3. `reporter` log prints its ready line, proving it was gated correctly.

Watch the order once with `docker compose up --build` (foreground, no `-d`) — you will
*see* Compose hold api until migrator exits 0, then hold reporter until api is healthy.

## Break

```bash
./scripts/break.sh 1   # healthcheck hits a port nothing listens on
./scripts/break.sh 2   # depends_on without a condition (start-order only)
./scripts/break.sh 3   # migrator exits non-zero
```

## Investigate — evidence checklist (fill before solutions)

For each mode:

1. `docker compose ps -a` — which services exist, and in what state?
2. `docker compose logs <service>` — the last lines of the failing service.
3. `docker inspect <api-container> --format '{{json .State.Health }}'` — actual
   healthcheck probe output (mode 1: which URL, which exit code?).
4. Timing evidence (mode 2): do the api's first log lines appear before the migrator's
   "migration complete" line? Use `docker compose logs -t` timestamps.

**Hypothesis gate:** *"In mode N the gate failed because ______; Compose knows because
it checks ______, not ______."*

Solutions: `labs/solutions/04-compose-deps.md`.

## Fix and prove recovery

Recovery proof = all three success criteria from Setup hold again after `docker compose up -d`.

## Reset

```bash
./scripts/reset.sh
```

## Prevention lesson

- `depends_on` alone is start order. Real dependencies need conditions:
  `service_completed_successfully` (jobs) or `service_healthy` (long-running services).
- A healthcheck that can never succeed will silently wedge every dependent service.
- Jobs that "usually exit 0" are not dependencies; they are races you have not lost yet.

## Portfolio prompt

Diagram the chain (migrator → api → reporter) and annotate which condition guards each
arrow — in your own words.

## Interview question

*"Your app starts before its database is ready and crashes. The team suggests a sleep in
the entrypoint. What do you suggest instead, and why?"*
