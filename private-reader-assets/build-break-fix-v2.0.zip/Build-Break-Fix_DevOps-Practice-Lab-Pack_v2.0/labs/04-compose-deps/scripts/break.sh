#!/usr/bin/env bash
# Lab 04 — activate one of three faults in compose.yaml.
#   1) health-port      : api never becomes healthy; reporter never starts
#   2) order-only       : api starts before migration finishes (race by design)
#   3) migrator-fails   : dependency exits 3; compose stops the chain
set -euo pipefail
cd "$(dirname "$0")/.."

mode="${1:-1}"
cp -n compose.yaml compose.yaml.bak
case "$mode" in
  1) cp broken/compose.health-port.yaml compose.yaml ;;
  2) cp broken/compose.order-only.yaml compose.yaml ;;
  3) cp broken/compose.migrator-fails.yaml compose.yaml ;;
  *) echo "usage: ./scripts/break.sh [1|2|3]" >&2; exit 2 ;;
esac

echo "BREAK $mode active (original saved as compose.yaml.bak). Now run:"
echo "  docker compose up --build -d ; docker compose ps -a"
echo "  docker compose logs migrator api reporter | tail -30"
