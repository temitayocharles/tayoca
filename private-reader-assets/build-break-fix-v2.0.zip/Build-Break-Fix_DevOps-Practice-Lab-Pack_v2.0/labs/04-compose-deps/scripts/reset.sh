#!/usr/bin/env bash
# Lab 04 — stop everything, restore the working compose file, drop the volume.
set -euo pipefail
cd "$(dirname "$0")/.."
docker compose down -v --remove-orphans 2>/dev/null || true
[[ -f compose.yaml.bak ]] && mv compose.yaml.bak compose.yaml
docker compose down -v --remove-orphans 2>/dev/null || true
echo "Lab 04 reset complete."
