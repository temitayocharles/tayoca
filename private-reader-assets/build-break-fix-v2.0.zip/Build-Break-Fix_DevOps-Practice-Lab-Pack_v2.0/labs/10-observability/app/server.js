// Lab 10 — the OBSERVABLE twin of the sample app.
// Teaches: structured JSON logs, log levels, request IDs, and metrics exposition.
//   LOG_LEVEL  (debug|info|error, default info) — what gets EMITTED
//   FAIL_RATE  (0..1, default 0) — how often /work fails, for log/metric analysis
const http = require('node:http');
const crypto = require('node:crypto');

const PORT = parseInt(process.env.PORT || '3100', 10);
const LOG_LEVEL = (process.env.LOG_LEVEL || 'info').toLowerCase();
const FAIL_RATE = parseFloat(process.env.FAIL_RATE || '0');

const LEVELS = { debug: 10, info: 20, error: 30 };
let emitted = 0;

function log(level, msg, fields = {}) {
  // Rule: a log line nobody can grep is a log line nobody will read.
  if ((LEVELS[level] || 0) < (LEVELS[LOG_LEVEL] || 0)) return;
  const line = JSON.stringify({ ts: new Date().toISOString(), level, msg, ...fields });
  emitted++;
  (level === 'error' ? console.error : console.log)(line);
}

// Counters — the Prometheus text exposition format (version 0.0.4).
const metrics = {
  requests_total: 0,
  status_2xx: 0,
  status_4xx: 0,
  status_5xx: 0,
};
const startedAt = Date.now();

const server = http.createServer((req, res) => {
  const reqId = crypto.randomUUID().slice(0, 8);
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  metrics.requests_total++;

  const finish = (status, body, type = 'application/json') => {
    res.writeHead(status, { 'Content-Type': type, 'X-Request-Id': reqId });
    res.end(body);
    if (status < 400) metrics.status_2xx++;
    else if (status < 500) metrics.status_4xx++;
    else metrics.status_5xx++;
    log('info', 'request handled', { req_id: reqId, method: req.method, path: url.pathname, status });
  };

  log('debug', 'request received', { req_id: reqId, path: url.pathname });

  if (req.method === 'GET' && url.pathname === '/health') {
    return finish(200, JSON.stringify({ status: 'ok' }));
  }
  if (req.method === 'GET' && url.pathname === '/work') {
    // Deterministic-ish failure injection: seeded by request id so runs are reproducible.
    const h = parseInt(reqId.slice(0, 4), 16) / 0xffff; // 0..1
    if (h < FAIL_RATE) {
      log('error', 'work failed', { req_id: reqId, reason: 'upstream timeout after 2000ms', retryable: true });
      return finish(500, JSON.stringify({ error: 'work failed', req_id: reqId }));
    }
    return finish(200, JSON.stringify({ done: true, req_id: reqId }));
  }
  if (req.method === 'GET' && url.pathname === '/metrics') {
    const body = [
      '# HELP bbf_requests_total Total requests received.',
      '# TYPE bbf_requests_total counter',
      `bbf_requests_total ${metrics.requests_total}`,
      '# HELP bbf_status_total Responses by class.',
      '# TYPE bbf_status_total counter',
      `bbf_status_total{class="2xx"} ${metrics.status_2xx}`,
      `bbf_status_total{class="4xx"} ${metrics.status_4xx}`,
      `bbf_status_total{class="5xx"} ${metrics.status_5xx}`,
      '# HELP bbf_uptime_seconds Process uptime.',
      '# TYPE bbf_uptime_seconds gauge',
      `bbf_uptime_seconds ${Math.round((Date.now() - startedAt) / 1000)}`,
    ].join('\n') + '\n';
    metrics.requests_total--; // do not count scrapes as traffic
    return finish(200, body, 'text/plain; version=0.0.4');
  }
  finish(404, JSON.stringify({ error: 'not found', path: url.pathname }));
});

server.listen(PORT, '0.0.0.0', () => {
  log('info', 'server listening', { port: PORT, log_level: LOG_LEVEL, fail_rate: FAIL_RATE, emitted: emitted });
});
process.on('SIGTERM', () => { log('info', 'sigterm received'); server.close(() => process.exit(0)); });
