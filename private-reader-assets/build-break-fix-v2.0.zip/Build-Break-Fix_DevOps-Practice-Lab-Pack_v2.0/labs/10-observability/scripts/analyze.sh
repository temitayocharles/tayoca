#!/usr/bin/env bash
# Lab 10 — turn raw logs into evidence. No jq required; python3 ships everywhere.
# Run this while the app from setup is STILL running and you have NOT scrolled
# its terminal. Usage: ./scripts/analyze.sh [server-output.log]
set -euo pipefail
LOG="${1:-server-output.log}"

[[ -f "$LOG" ]] || { echo "no log file at $LOG — start the app with output redirected:"; \
  echo "  cd app && FAIL_RATE=0.3 node server.js > ../server-output.log 2>&1"; exit 1; }

echo "== 1. Volume by level =="
grep -o '"level":"[a-z]*"' "$LOG" | sort | uniq -c

echo
echo "== 2. Error rate among handled requests =="
total=$(grep -c '"msg":"request handled"' "$LOG" || true)
errors=$(grep '"msg":"request handled"' "$LOG" | grep -c '"status":5' || true)
python3 - "$total" "$errors" <<'PY'
import sys
t, e = int(sys.argv[1]), int(sys.argv[2])
rate = (e / t * 100) if t else 0
print(f"handled={t}  5xx={e}  error_rate={rate:.1f}%")
PY

echo
echo "== 3. One failure, end to end (the correlating req_id) =="
fail_id=$(grep '"msg":"work failed"' "$LOG" | head -1 | grep -o '"req_id":"[a-f0-9]*"' | cut -d'"' -f4 || true)
if [[ -n "${fail_id:-}" ]]; then
  echo "following req_id=$fail_id through every line it touched:"
  grep "$fail_id" "$LOG"
else
  echo "(no 'work failed' lines — raise FAIL_RATE and rerun load.sh)"
fi

echo
echo "== 4. What the metrics endpoint would tell you (cross-check) =="
echo "curl -s http://127.0.0.1:3100/metrics | grep bbf_status_total"
echo "Logs answer WHY. Metrics answer HOW MUCH. Health checks answer ONLY NOW."
