#!/usr/bin/env bash
# Lab 10 — stop the app and remove generated logs.
set -euo pipefail
cd "$(dirname "$0")/.."
[[ -f server.pid ]] && kill "$(cat server.pid)" 2>/dev/null || true
rm -f server.pid server-output.log
echo "Lab 10 reset complete."
