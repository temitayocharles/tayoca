#!/usr/bin/env bash
# Lab 10 — start the observable app with a failure rate and capture its output.
set -euo pipefail
cd "$(dirname "$0")/.."
( cd app && exec env FAIL_RATE=0.3 PORT=3100 node server.js > ../server-output.log 2>&1 ) &
echo $! > server.pid
sleep 0.7
curl -s -o /dev/null -w 'health check: HTTP %{http_code}\n' http://127.0.0.1:3100/health
echo "Logging to server-output.log (pid $(cat server.pid)). Next: ./scripts/load.sh"
