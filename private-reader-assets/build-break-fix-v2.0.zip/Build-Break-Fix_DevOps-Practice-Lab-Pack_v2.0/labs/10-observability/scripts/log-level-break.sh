#!/usr/bin/env bash
# Lab 10 — the logging break: restart the app at the WRONG level.
# Symptom produced: the info lines vanish; errors remain; nothing crashed.
set -euo pipefail
cd "$(dirname "$0")/.."

if [[ -f server.pid ]] && kill -0 "$(cat server.pid)" 2>/dev/null; then
  kill "$(cat server.pid)"; sleep 0.5
fi
( cd app && exec env LOG_LEVEL=error PORT=3100 FAIL_RATE=0.3 node server.js > ../server-output.log 2>&1 ) &
echo $! > server.pid
sleep 0.7
echo "App restarted with LOG_LEVEL=error (pid $(cat server.pid))."
echo "Regenerate traffic:  ./scripts/load.sh"
echo "Then answer: which lines vanished, which stayed, and why is that dangerous at 03:00?"
