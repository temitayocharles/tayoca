#!/usr/bin/env bash
# Lab 10 — generate a realistic log/metrics history: mixed successes, failures, 404s.
# Usage: ./scripts/load.sh [port]   (default 3100)
set -uo pipefail
PORT="${1:-3100}"
BASE="http://127.0.0.1:$PORT"

echo "Sending traffic to $BASE (about 8 seconds)..."
for i in $(seq 1 30); do
  curl -s -o /dev/null "$BASE/work" &
  curl -s -o /dev/null "$BASE/work" &
  curl -s -o /dev/null "$BASE/no-page-$i" &   # some 404 noise, like real traffic
  wait
  sleep 0.2
done
echo "Done. Now count what happened:"
echo "  ./scripts/analyze.sh $PORT"
