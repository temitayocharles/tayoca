# Lab 10 — Observability Basics: Logs, Metrics, Health

**Loop stage:** BUILD (visible systems) → BREAK (the logs go dark)
**You will keep:** what logs, metrics, and health checks each *cannot* tell you — and how
a request ID stitches evidence together.

## Objective

Run an app that emits structured JSON logs and Prometheus-format metrics, generate real
traffic (including real failures), and practice the analysis: error rate from logs, a
failure followed end-to-end by `req_id`, and cross-checking logs against metrics.
Everything runs with Node only — no Docker, no cluster, no cloud.

## Prerequisites

Node ≥ 18, curl, python3, grep.

## Setup — expected working state

```bash
cd labs/10-observability
./scripts/start.sh        # starts app on :3100 with FAIL_RATE=0.3, logging to server-output.log
./scripts/load.sh         # ~90 requests over ~8s: mostly 2xx, some 5xx, some 404 noise
curl -s http://127.0.0.1:3100/metrics | grep bbf_status
head -3 server-output.log
```

Success criteria:

1. `server-output.log` lines are valid JSON (test: `head -1 server-output.log | python3 -m json.tool`).
2. Metrics show nonzero `2xx` **and** `5xx` counters.
3. `curl -i /health` returns 200 the whole time — the app never "went down".

## Break

```bash
./scripts/log-level-break.sh   # restarts with LOG_LEVEL=error
./scripts/load.sh
```

**Symptom:** nothing crashed, health is green, metrics still count — but the log now
contains only `error` lines. The story of what is happening has gone dark.

## Investigate — evidence checklist

1. Which messages vanished: `request handled`? `request received`? `server listening`?
   Compare line counts before/after (`grep -c ...`).
2. Can you still compute the error *rate* from logs alone? What exactly is missing?
3. Which source still knows the total? (`/metrics` — and note it survived the break).
4. Correlation: pick one `work failed` line; follow its `req_id` backwards to the
   received/handled lines (`./scripts/analyze.sh` step 3 does this once, then do it
   manually for a second ID).

**Hypothesis gate:** *"The system became less observable but not less healthy; the
operator's loss is ______, and the setting that caused it is ______."*

Solutions: `labs/solutions/10-observability.md`.

## Fix and prove recovery

Restart with `LOG_LEVEL=info` (see `scripts/start.sh`), rerun load, recovery proof =
`request handled` lines reappear **and** your before/after grep counts match the metrics
delta. Note: restart resets counters — say why in your log (counters are per-process
unless backed by storage; this is exactly why rate windows beat absolute counts).

## Reset

```bash
./scripts/reset.sh
```

## Prevention lesson

- Debug in dev, info in prod, error for things a human should see — decided centrally,
  not per `console.log`.
- Structured logs (JSON + `req_id`) make correlation mechanical; free-text logs make it
  impossible.
- Metrics survive log-level breaks; logs survive metric pipeline breaks; health checks
  answer only "now". Redundant signals are not waste.

## Portfolio prompt

"The night the logs went dark": narrate the break with your before/after grep counts and
the one req_id trace as evidence. It is a small story that demonstrates real instincts.

## Interview question

*"Your dashboards are green and health checks pass, but users complain the app is slow.
What can logs tell you that metrics cannot, and what would you add to find the slow
requests?"* (Hint: timing fields, and why this app's logs omit them — what would you add?)
