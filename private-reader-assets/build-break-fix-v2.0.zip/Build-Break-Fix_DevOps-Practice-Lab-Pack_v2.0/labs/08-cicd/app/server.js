// Lab 08 — CI twin of the Lab 02 app (kept local so this lab is self-contained).
// Identical behavior; see Lab 02 for the annotated original.
const http = require('node:http');

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '0.0.0.0';
let requestsTotal = 0;
const startedAt = Date.now();

const server = http.createServer((req, res) => {
  requestsTotal += 1;
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && url.pathname === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'ok', uptimeSeconds: Math.round((Date.now() - startedAt) / 1000) }));
    return;
  }
  if (req.method === 'GET' && url.pathname === '/api/items') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ items: [{ id: 1, name: 'widget' }, { id: 2, name: 'gadget' }] }));
    return;
  }
  res.writeHead(404, { 'Content-Type': 'application/json' });
  res.end(JSON.stringify({ error: 'not found', path: url.pathname }));
});

server.listen(PORT, HOST, () => {
  console.log(`[bbf-ci-app] listening on ${HOST}:${PORT}`);
});
process.on('SIGTERM', () => server.close(() => process.exit(0)));
