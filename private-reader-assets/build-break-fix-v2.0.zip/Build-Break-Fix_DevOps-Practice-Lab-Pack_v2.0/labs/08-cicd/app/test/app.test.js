// Lab 08 — pipeline tests. The BROKEN variant (broken/app.test.js.red) is swapped in
// by scripts/break.sh; the failure is the lesson, not the bug.
const test = require('node:test');
const assert = require('node:assert');
const { spawn } = require('node:child_process');
const http = require('node:http');

function get(pathname, port) {
  return new Promise((resolve, reject) => {
    const req = http.get({ host: '127.0.0.1', port, path: pathname, timeout: 2000 }, (res) => {
      let body = '';
      res.on('data', (c) => (body += c));
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); });
  });
}

async function withServer(port, fn) {
  const srv = spawn('node', ['server.js'], { env: { ...process.env, PORT: String(port) }, stdio: 'ignore' });
  try {
    for (let i = 0; i < 30; i++) {
      try { await get('/health', port); break; }
      catch { await new Promise((r) => setTimeout(r, 100)); }
    }
    await fn();
  } finally { srv.kill('SIGTERM'); }
}

test('health endpoint answers 200', async () => {
  await withServer(39901, async () => {
    const res = await get('/health', 39901);
    assert.equal(res.status, 200);
    assert.equal(JSON.parse(res.body).status, 'ok');
  });
});

test('unknown paths return 404 without crashing', async () => {
  await withServer(39902, async () => {
    const res = await get('/definitely-not-here', 39902);
    assert.equal(res.status, 404);
  });
});
