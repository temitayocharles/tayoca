# Lab 08 — CI/CD Failure & Recovery

**Loop stage:** BUILD (a green pipeline) → BREAK (three red-pipeline species)
**You will keep:** reading a pipeline failure as *stage → step → line*, and the habit of
asking "who is wrong — the code, the test, or the pipeline?" before touching anything.

## Objective

Own a small CI definition and its local twin (`scripts/bbf-ci.sh`) that runs the same
stages in seconds. Break the pipeline three ways and classify each red build by its
signature, not by trial and error.

## Prerequisites

Node ≥ 18. Docker optional (stage 3 skips politely without it). No GitHub account needed
for the local path; push to a real repo to watch the same failures in Actions' UI.

## Setup — expected working state

```bash
cd labs/08-cicd
./scripts/bbf-ci.sh
```

Success criteria: summary line reads `2 passed, 0 failed` (or `3 passed` with Docker).
The pipeline definition `.github/workflows/ci.yml` mirrors these stages: `test` then
`build` (`needs: test` — a dependency chain, like Lab 04).

## Break

```bash
./scripts/break.sh 1   # stage runs in the wrong directory (src vs app)
./scripts/break.sh 2   # typo'd command: npm instal
./scripts/break.sh 3   # the test expects 201; the app correctly returns 200
```

## Investigate — evidence checklist

Run `./scripts/bbf-ci.sh` after each break and record:

| Fault | Which stage? | Which step? | The decisive line | Fault class (pipeline/test/code) |
|---|---|---|---|---|
| 1 | | | | |
| 2 | | | | |
| 3 | | | | |

For fault 3, answer before fixing: the build is red — who is wrong, and how do you *know*?
(The answer is in the assertion message versus the app's contract in Lab 02.)

**Hypothesis gate:** *"This build is red because ______ is wrong; the evidence is the
line ______, and the right fix is to change ______, not ______."*

Solutions: `labs/solutions/08-cicd.md`.

## Fix and prove recovery

Recovery proof = `./scripts/bbf-ci.sh` green again AND (if you pushed) the Actions run
green on the remote. A skipped stage is not a green stage: check the summary count.

## Reset

```bash
./scripts/reset.sh && ./scripts/bbf-ci.sh
```

## Prevention lesson

- `defaults.run.working-directory` mismatches fail only at run time; keep the layout
  convention identical in CI and locally.
- Typos fail fast and loudly; assertion drift fails *confidently* — always read which
  expectation failed and ask whether the test or the code owns the truth.
- `needs:` chains make failures precise: fix the upstream job, not the blocked one.

## Portfolio prompt

"Three ways a pipeline lies to you" — or, more precisely, "three ways it tells the truth
you misread". Your table is the outline.

## Interview question

*"A CI pipeline that was green yesterday is red today; nobody changed the code. Where do
you look first?"* (Think: dependencies, runner image, external services, flakiness — and
what evidence separates them.)
