// BROKEN VARIANT — copy over app/test/app.test.js (scripts/break.sh 3).
// Fault class: the PIPELINE is honest; the TEST is wrong. The red build is
// doing its job — the lesson is not to "make it green" but to decide who is wrong.
const test = require('node:test');
const assert = require('node:assert');
const { spawn } = require('node:child_process');
const http = require('node:http');

function get(pathname, port) {
  return new Promise((resolve, reject) => {
    const req = http.get({ host: '127.0.0.1', port, path: pathname, timeout: 2000 }, (res) => {
      let body = '';
      res.on('data', (c) => (body += c));
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('timeout')); }
  );
}

test('health endpoint answers 200', async () => {
  const srv = spawn('node', ['server.js'], { env: { ...process.env, PORT: '39903' }, stdio: 'ignore' });
  try {
    for (let i = 0; i < 30; i++) {
      try { await get('/health', 39903); break; }
      catch { await new Promise((r) => setTimeout(r, 100)); }
    }
    const res = await get('/health', 39903);
    assert.equal(res.status, 201);   // WRONG expectation: the app correctly returns 200
  } finally { srv.kill('SIGTERM'); }
});
