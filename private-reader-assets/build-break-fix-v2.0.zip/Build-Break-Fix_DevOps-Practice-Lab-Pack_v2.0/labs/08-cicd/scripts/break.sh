#!/usr/bin/env bash
# Lab 08 — activate one of three pipeline faults.
#   1) working-directory typo  2) command typo  3) wrong test expectation
set -euo pipefail
cd "$(dirname "$0")/.."

mode="${1:-1}"
mkdir -p .github/workflows
cp -n .github/workflows/ci.yml .github/workflows/ci.yml.bak 2>/dev/null || true
cp -n app/test/app.test.js app/test/app.test.js.bak

case "$mode" in
  1) cp broken/ci.working-directory.yaml .github/workflows/ci.yml ;;
  2) cp broken/ci.typo-step.yaml .github/workflows/ci.yml ;;
  3) cp broken/app.test.js.red app/test/app.test.js ;;
  *) echo "usage: ./scripts/break.sh [1|2|3]" >&2; exit 2 ;;
esac

echo "BREAK $mode active. Reproduce locally in seconds:  ./scripts/bbf-ci.sh"
echo "Read it like a CI log: stage -> step -> line. Fix only after naming the fault class."
