#!/usr/bin/env bash
# Lab 08 — restore working pipeline files.
set -euo pipefail
cd "$(dirname "$0")/.."
[[ -f .github/workflows/ci.yml.bak ]] && mv .github/workflows/ci.yml.bak .github/workflows/ci.yml
[[ -f app/test/app.test.js.bak ]] && mv app/test/app.test.js.bak app/test/app.test.js
echo "Lab 08 reset complete. Verify: ./scripts/bbf-ci.sh"
