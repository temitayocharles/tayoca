#!/usr/bin/env bash
# Lab 08 — bbf-ci: a LOCAL twin of the GitHub Actions pipeline.
# Same stages, same order, same failure vocabulary — no push required.
# Stage 1 syntax -> Stage 2 test -> Stage 3 image build (skipped politely without Docker).
set -uo pipefail
cd "$(dirname "$0")/../app"

pass=0; fail=0
stage() { printf '\n=== stage %s ' "$1"; printf '%.0s-' $(seq 1 $((36 - ${#1}))); printf '\n'; }
ok()   { echo "PASS: $1"; pass=$((pass+1)); }
bad()  { echo "FAIL: $1"; fail=$((fail+1)); }

stage "1/3 syntax"
if node --check server.js 2>&1; then ok "server.js parses"; else bad "server.js does not parse"; fi

stage "2/3 test"
if npm test --silent >/tmp/bbf-ci-test.log 2>&1; then
  ok "test suite passed"; tail -4 /tmp/bbf-ci-test.log
else
  bad "test suite failed — first failure lines:"; grep -m4 -E "not ok|AssertionError|expected" /tmp/bbf-ci-test.log || head -8 /tmp/bbf-ci-test.log
fi

stage "3/3 build"
if command -v docker >/dev/null 2>&1; then
  if docker build -q -t bbf-ci-app:local . >/tmp/bbf-ci-build.log 2>&1; then
    ok "image built"; head -1 /tmp/bbf-ci-build.log
  else
    bad "image build failed — last lines:"; tail -4 /tmp/bbf-ci-build.log
  fi
else
  echo "SKIP: docker not present (this stage is optional locally)"
fi

printf '\n==== summary: %s passed, %s failed ====\n' "$pass" "$fail"
[[ "$fail" -eq 0 ]]
