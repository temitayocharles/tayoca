# Lab 06 — Configuration & Resources: ConfigMaps, Requests, Limits

**Loop stage:** BUILD (config as a cluster object) → BREAK (three failure layers)
**You will keep:** four pod-failure states that look identical from far away and are
trivially separable with `describe`: CreateContainerConfigError, OOMKilled/CrashLoopBackOff,
Pending, and a healthy-but-unconfigured app.

## Objective

Feed the app its configuration from a ConfigMap, prove delivery with a Job, then meet the
three classic configuration failure classes — and learn which evidence separates them.

## Prerequisites

The `bbf` kind cluster from Lab 05, with `bbf-sample-api:local` loaded (Lab 05's
`scripts/load.sh`).

## Setup — expected working state

```bash
cd labs/06-k8s-config
kubectl apply -f manifests/
kubectl rollout status deploy/api -n bbf-config --timeout=90s
kubectl get pods,job -n bbf-config
kubectl logs -n bbf-config job/smoke                 # {"status":"ok",...} smoke-ok
kubectl logs -n bbf-config deploy/api | head -3      # ... greeting=hello from the cluster
```

Success criteria:

1. Both pods `Running`; Job `smoke` shows `Completions 1/1`.
2. The pod log line `greeting=hello from the cluster` — proof the ConfigMap reached the
   process, not just the cluster.

## Break — three layers, one symptom class ("pods not working")

```bash
kubectl apply -f broken/missing-configmap.yaml
kubectl apply -f broken/memory-too-low.yaml
kubectl apply -f broken/cpu-request-huge.yaml
kubectl get pods -A | grep bbf-config
```

All three deployments are broken at the same moment. Diagnose all three.

## Investigate — evidence checklist

For each broken namespace (`bbf-config-broken`, `bbf-config-oom`, `bbf-config-pending`),
collect:

1. `kubectl get pods -n <ns>` — the STATUS column (your symptom map).
2. `kubectl describe pod -n <ns> -l app=api` — the Events section and the `State:` line
   with `Reason:`. This is where each of the three tells the truth.
3. `kubectl logs -n <ns> deploy/api` — note which failures produce logs and which do not,
   and why that makes sense (killed before start vs killed by kernel vs never scheduled).
4. `kubectl get events -n <ns> --sort-by=.lastTimestamp | tail -8`.

**Hypothesis gate:** match each namespace to its failure layer — *configuration*,
*runtime resources*, *scheduling* — with one line of evidence each, before solutions.

Solutions: `labs/solutions/06-k8s-config.md`.

## Fix and prove recovery

Repair each fault (the fix differs per layer: apply the ConfigMap into the right
namespace; raise the limit to what the runtime needs; right-size the request). Recovery
proof per namespace = `rollout status` completes **and** the smoke Job (or a
`port-forward` curl in the OOM case) returns `200`.

## Reset

```bash
kubectl delete ns bbf-config bbf-config-broken bbf-config-oom bbf-config-pending --ignore-not-found
```

## Prevention lesson

- Config references fail at *container start*, not at `kubectl apply` — the API server
  does not check that ConfigMaps exist. Smoke Jobs catch this before users do.
- Limits below runtime baseline produce OOMKill loops with misleadingly empty logs.
- Absurd requests do not error; they queue forever. `describe` > `get` for Pending pods.

## Portfolio prompt

Write the four-state table (status → reason → layer → first command) from memory and
attach your actual outputs.

## Interview question

*"A pod is in CrashLoopBackOff with no useful logs. Give me three possible causes and the
one command you would run first."*
