#!/usr/bin/env bash
# Build, Break, Fix — master reset. Cleans EVERY lab's footprint on this machine.
# Reviews what it will do, then does it. Read before running; it deletes state.
set -uo pipefail
cd "$(dirname "$0")"

echo "== Build, Break, Fix — master reset =="
echo "This will:"
echo "  - delete Kubernetes namespaces bbf-* and the kind cluster 'bbf' (if present)"
echo "  - stop and remove lab containers, networks, volumes, and the bbf-sample-api images"
echo "  - restore lab working files from *.bak where breaks were activated"
echo "  - run terraform destroy in Lab 09 local-basics and remove its state"
echo "  - stop the Lab 10 app and remove its logs/pid"
echo "  - remove Lab 12's local audit log"
echo
read -r -p "Continue? [y/N] " ans
[[ "${ans:-n}" == "y" ]] || { echo "aborted"; exit 0; }

# Kubernetes
if command -v kubectl >/dev/null 2>&1; then
  kubectl delete ns bbf-delivery bbf-config bbf-config-broken bbf-config-oom bbf-config-pending \
    bbf-quest-1 bbf-quest-2 bbf-quest-3 bbf-quest-4 bbf-capstone bbf-secrets --ignore-not-found 2>/dev/null
fi
command -v kind >/dev/null 2>&1 && kind delete cluster --name bbf 2>/dev/null

# Docker
if command -v docker >/dev/null 2>&1; then
  docker rm -f bbf-alpha bbf-pinger bbf-api bbf-site bbf-site-broken bbf-exit-demo 2>/dev/null
  docker network rm bbf-net 2>/dev/null
  (cd 04-compose-deps && docker compose down -v --remove-orphans 2>/dev/null)
  (cd 02-app-delivery/sample-app && docker compose down --remove-orphans 2>/dev/null)
  docker rmi bbf-sample-api:local bbf-sample-api:broken bbf-site:ok bbf-site:broken bbf-ci-app:local 2>/dev/null
fi

# Per-lab file restores
for f in 02-app-delivery/sample-app 03-image-runtime 08-cicd 09-terraform/local-basics; do
  (cd "$f" 2>/dev/null && for b in *.bak .github/workflows/ci.yml.bak app/test/app.test.js.bak; do
     [[ -f "$b" ]] || continue
     case "$b" in
       *.bak) mv "$b" "${b%.bak}" ;;
     esac
   done)
done
(cd 08-cicd && [[ -f .github/workflows/ci.yml.bak ]] && mv .github/workflows/ci.yml.bak .github/workflows/ci.yml || true)
(cd 08-cicd && [[ -f app/test/app.test.js.bak ]] && mv app/test/app.test.js.bak app/test/app.test.js || true)

# Terraform state
(cd 09-terraform/local-basics && command -v terraform >/dev/null && terraform destroy -auto-approve >/dev/null 2>&1; rm -rf generated .terraform .terraform.lock.hcl terraform.tfstate* main.tf.bak variables.tf.bak)

# Lab 10 / 12 artifacts
(cd 10-observability && [[ -f server.pid ]] && kill "$(cat server.pid)" 2>/dev/null; rm -f server.pid server-output.log)
(cd 12-ai-ops && rm -rf .audit)

echo
echo "Reset complete. Verify a clean slate: ./tools/check-env.sh"
