#!/usr/bin/env bash
# Lab 05 — load the locally built image into the kind cluster.
# kind nodes cannot see your local Docker image store until you load it.
set -euo pipefail
cd "$(dirname "$0")/.."

if ! docker image inspect bbf-sample-api:local >/dev/null 2>&1; then
  echo "image bbf-sample-api:local not found — building it from Lab 02 first:"
  (cd ../02-app-delivery/sample-app && docker build -t bbf-sample-api:local .)
fi
kind load docker-image bbf-sample-api:local --name bbf
echo "Image loaded into kind cluster 'bbf'."
