# Lab 05 — Kubernetes Delivery: Deployments, Services, Endpoints

**Loop stage:** BUILD (labels carry traffic) → BREAK (the label chain snaps)
**You will keep:** Deployment → Pod → Service → Endpoint as an evidence chain you can
inspect at every hop.

## Objective

Run the Lab 02 app on a local Kubernetes cluster (kind), prove traffic flows, then break
the label chain two different ways and diagnose from cluster evidence — not from the YAML.

## Prerequisites

- Docker, `kind`, `kubectl` (see the book's Environment Setup chapter)
- The Lab 02 image built: `cd labs/02-app-delivery/sample-app && docker build -t bbf-sample-api:local .`

## Setup — expected working state

```bash
cd labs/05-k8s-delivery
kind create cluster --name bbf            # once for all K8s labs
kubectl config use-context kind-bbf
./scripts/load.sh                         # kind load docker-image bbf-sample-api:local
kubectl apply -f manifests/
kubectl rollout status deploy/api -n bbf-delivery --timeout=90s
kubectl get pods,svc,endpoints -n bbf-delivery
```

Expected: 3/3 pods `Running`, one Service, and — the line that matters —
`endpoints/api` with **three addresses** in the `ENDPOINTS` column (your three pods).

Final proof:

```bash
kubectl port-forward -n bbf-delivery svc/api 8080:80 &
curl -i http://localhost:8080/health      # 200 OK
```

## Break

```bash
kubectl apply -f broken/service-selector-typo.yaml
kubectl get endpoints -n bbf-delivery
curl --max-time 3 -i http://localhost:8080/health   # via a NEW port-forward to svc/api-broken
```

Or the quieter variant: `kubectl apply -f broken/target-port-wrong.yaml` (redeploys api
with the wrong `targetPort`; pods stay Running and Ready).

## Investigate — evidence checklist

1. `kubectl get pods -n bbf-delivery --show-labels` — what labels exist?
2. `kubectl describe svc api-broken -n bbf-delivery` — what does the Service *want*
   (`Selector:`) versus what pods *have*?
3. `kubectl get endpoints -n bbf-delivery` — `<none>` means the Service found no pods.
4. For the targetPort variant: pods are Ready, endpoints are populated, yet `curl` gets
   `connection refused`. Where does the refusal come from — the Service or the pod?

**Hypothesis gate:** *"Traffic stops at the ______ because ______ does not match ______."*

Solutions: `labs/solutions/05-k8s-delivery.md`.

## Fix and prove recovery

`kubectl delete -f broken/... ; kubectl apply -f manifests/` then recovery proof =
`kubectl get endpoints` shows the pod IPs again **and** the port-forward `curl` returns
`200`. A `Rollout complete` message alone is not recovery — the user path must work.

## Reset

```bash
kubectl delete ns bbf-delivery --ignore-not-found
```

## Prevention lesson

Labels are an API between the Service and the Deployment. Treat selector/label changes
like schema changes: check both sides (`--show-labels`, `describe svc`) before and after.
Port chains must agree three times: containerPort → targetPort → port.

## Portfolio prompt

Redraw the Deployment→Pod→Service→Endpoint diagram with your actual evidence pasted at
each hop (pod labels, svc selector, endpoints list, curl output).

## Interview question

*"All pods are Running and Ready but requests to the Service fail. Give me your
diagnostic order and the single command that would most likely identify the cause."*
