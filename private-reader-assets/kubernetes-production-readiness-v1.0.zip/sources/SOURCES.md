# Source Ledger

Primary technical references are current Kubernetes documentation for pod lifecycle/disruptions, resource management, security and Pod Security Standards, NetworkPolicy, storage, cluster logging, API auditing, and encryption at rest. The checklist also draws on recovered Kubernetes operational materials in the publication library. Controls are editorial synthesis, not copied standards text.
