Kubernetes Production Readiness Checklist v1.0 — Reconstructed Edition
Includes the 150-control PDF, scored tracker, journey map, canonical CSV, and source ledger.
