<!--
COVER LETTER SKELETON
Keep it to one page. Replace every [BRACKET]. Lead with the employer's problem,
not your biography. Tie one portfolio project directly to the role.
-->
[Your Name]
[email] · [phone] · [city, region] · [github/portfolio url]

[Date]

[Hiring Manager Name or "Hiring Team"]
[Company Name]
[Company Address or "City, Region"]

Dear [Hiring Manager Name or "Hiring Team"],

I'm writing about the [exact job title] role at [Company]. Your posting describes
[restate the core problem in one sentence — e.g., "automating support triage with LLMs"].
That is exactly the work I've been building toward.

In [project name], I [what you built] using [stack], which [outcome, with a metric if
you have one]. It taught me the part most demos skip: [the hard part you solved — evaluation,
guardrails, or reliability].

At [Company], I'd focus first on [the specific outcome that matters to them], because
[one sentence on why it fits their context]. I've attached my resume and a short case
study of the project above.

Thank you for considering my application. I'd welcome the chance to walk through the
automation design in an interview.

Sincerely,
[Your Name]
[linkedin url]
