<!--
90-DAY JOB-HUNT TRACKER
Copy this file and update it weekly (see Chapter 3). Keep it simple so you
actually use it. "Status" values: planned | active | done | blocked.
-->
# 90-Day Job-Hunt Tracker

Target role: [one sentence]
Niche: [chosen vertical]
Start date: [YYYY-MM-DD]

## Weekly metrics
| Week | Applications sent | Referrals requested | Interviews | Notes |
| --- | --- | --- | --- | --- |
| 1 |  |  |  |  |
| 2 |  |  |  |  |
| 3 |  |  |  |  |
| 4 |  |  |  |  |
| 5 |  |  |  |  |
| 6 |  |  |  |  |
| 7 |  |  |  |  |
| 8 |  |  |  |  |
| 9 |  |  |  |  |
| 10 |  |  |  |  |
| 11 |  |  |  |  |
| 12 |  |  |  |  |
| 13 |  |  |  |  |
| 14 |  |  |  |  |

## Portfolio checklist
| Project | Status | Repo | Demo | Case study |
| --- | --- | --- | --- | --- |
| Project 1 | planned |  |  |  |
| Project 2 | planned |  |  |  |
| Eval harness | planned |  |  |  |
| Guardrails layer | planned |  |  |  |

## This week's blocker + fix
- Blocker: [what stopped you]
- Fix: [one concrete action]
