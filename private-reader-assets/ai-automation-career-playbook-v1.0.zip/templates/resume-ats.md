<!--
ATS-FRIENDLY RESUME TEMPLATE
Copy this file, replace every [BRACKET] with your own content, and keep the
section order and plain formatting so Applicant Tracking Systems can parse it.
Save as PDF (and keep a plain-text copy) when submitting.
-->
# [YOUR NAME]
[City, Region] · [email@domain.com] · [phone] · [github.com/you] · [linkedin.com/in/you]

## Summary
AI automation engineer who builds systems that combine LLMs, workflow orchestration, and RPA to remove manual work from [target industry] pipelines. Recent proof: [one sentence on your strongest project and its result].

## Skills
- Foundations: Python, REST APIs, JSON, Git, SQL, cloud basics
- AI building blocks: LLM APIs, prompting, RAG, vector stores
- Automation: n8n / Zapier / Power Automate, UiPath / Automation Anywhere
- Production: evaluation, guardrails, observability, CI basics

## Experience
### [Job Title] — [Company] — [Dates]
- Automated [process] using [tool/LLM], reducing manual effort by [metric] on a [sample size] sample.
- Built [system] that [what it did], measured by [evaluation method].
- Owned [responsibility] end to end, including [monitoring/rollback/safety].

### [Job Title] — [Company] — [Dates]
- [Achievement with a measurable outcome.]
- [Achievement that shows automation or AI-adjacent work.]

## Projects
### [Project Name] — [one-line problem]
- Stack: [tools]. Result: [outcome]. Hard part solved: [tradeoff or bug].
- Repo: [url] · Demo: [url]

### [Project Name] — [one-line problem]
- Stack: [tools]. Result: [outcome]. Hard part solved: [tradeoff or bug].

## Education
- [Degree, Field] — [Institution] — [Year]

## Certifications
- [Certification] — [Issuer] — [Year] (optional)
