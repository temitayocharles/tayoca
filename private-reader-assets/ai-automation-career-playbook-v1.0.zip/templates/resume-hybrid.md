<!--
HYBRID RESUME TEMPLATE (career changers)
Lead with skills and projects, not a long job history. Keep it ATS-safe:
no tables, text boxes, or columns. Fill every [BRACKET].
-->
# [YOUR NAME]
[City, Region] · [email@domain.com] · [phone] · [github.com/you] · [linkedin.com/in/you]

## Summary
Transitioning from [current field] into AI automation engineering, with hands-on proof of [what you can build]. Targeting [niche, e.g., support automation for SaaS].

## Skills
- Foundations: Python, APIs, Git, SQL, cloud literacy
- AI building blocks: LLM APIs, prompting, RAG, embeddings
- Automation: n8n / Power Automate, RPA fundamentals
- Production: evaluation, guardrails, observability

## Projects
### [Project Name] — [problem in one line]
- Approach: [stack and key decision].
- Result: [outcome, even on sample data].
- Proof: [repo url] · [demo url]

### [Project Name] — [problem in one line]
- Approach: [stack and key decision].
- Result: [outcome].
- Proof: [repo url]

## Experience
### [Job Title] — [Company] — [Dates]
- [Responsibility refactored to show automation/AI relevance.]
- [Win expressed as a result, not a duty.]

### [Job Title] — [Company] — [Dates]
- [Responsibility with a measurable outcome.]

## Education & Certifications
- [Degree / Field] — [Institution] — [Year]
- [Certification] — [Issuer] — [Year] (optional)
