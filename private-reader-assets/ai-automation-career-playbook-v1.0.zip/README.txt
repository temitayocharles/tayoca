AI Automation Career Playbook — Rebuilt Edition 1.0
Author: Temitayo Charles
Imprint: Tayoca Books

Customer bundle:
- AI-Automation-Career-Playbook.pdf
- 90-day-tracker.md
- resume-ats.md
- resume-hybrid.md
- cover-letter.md

The employer list is an August 2026 discovery map, not a guarantee of open roles. Re-check careers pages before applying.
Salary guidance is a negotiation framework, not a promised compensation range.
