# Severity Matrix Template

Customize these criteria and targets for your organization.

| Severity | Typical impact | Example acknowledgement target | Engagement | External communication |
|---|---|---:|---:|---|
| SEV1 Critical | Widespread outage, material security/data risk, critical user journey unavailable | 5 min | 10 min | Immediate after confirmation |
| SEV2 Major | Significant degradation or partial outage with meaningful user impact | 15 min | 30 min | If customer impact is confirmed or incident persists |
| SEV3 Minor | Limited impact with workaround; most users unaffected | 4 business hours | As needed | Usually internal |
| SEV4 Low | Cosmetic/informational/minimal operational impact | Next business day | N/A | None |

Severity is determined by impact and risk, not by how difficult the technical fix appears.
