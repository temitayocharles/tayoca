# Incident Communication Templates

## Initial internal update
**Status:** Investigating  
**Impact:** [who/what is affected]  
**Started/Detected:** [UTC]  
**Evidence:** [confirmed facts only]  
**Mitigation:** [what is being tried now]  
**Next update:** [exact timestamp]

## External status update
We are investigating an issue affecting [user journey/service]. Impact began at approximately [time UTC]. We are [investigating/mitigating] and will provide another update by [time UTC].

## Mitigation update
**Status:** Mitigating  
**Change:** [reversible mitigation applied]  
**Observed result:** [metrics/user checks]  
**Remaining impact:** [facts]  
**Next update:** [timestamp]

## Resolved update
The service has recovered as of [time UTC]. We have verified [critical user journeys/SLIs]. We will continue monitoring and will complete a post-incident review for follow-up actions.

Do not speculate about root cause in public communication before evidence supports it. Do not include secrets, customer records, internal hostnames, private dashboards, or personal data.
