# Incident Command Record

- Incident ID:
- Title:
- Severity:
- Started at (UTC):
- Detected at (UTC):
- Incident Commander:
- Technical Lead:
- Comms Lead:
- Scribe:
- Impacted services/user journeys:
- Customer/business impact:
- Current status: investigating | identified | mitigating | monitoring | resolved
- Current mitigation:
- Next update at:

## Evidence links
- Alert:
- Dashboard:
- Logs/traces:
- Recent changes:
- Incident channel:
- Status page:

## Timeline
| Time UTC | Observation / action | Evidence | Owner | Result |
|---|---|---|---|---|
