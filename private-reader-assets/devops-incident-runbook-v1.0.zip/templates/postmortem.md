# Blameless Post-Incident Review

## Summary
- Incident:
- Date:
- Severity:
- Duration:
- Customer/business impact:
- Detection method:

## What happened
Describe the technical sequence and system conditions without attributing failure to an individual.

## Timeline
| Time UTC | Event / evidence | Decision / action | Result |
|---|---|---|---|

## Contributing factors
- Technical conditions:
- Process conditions:
- Detection/observability gaps:
- Change/review conditions:
- Dependency conditions:

## Mitigation and recovery
What reduced impact? What restored service? How was recovery verified?

## What went well

## What made response harder

## Action items
| Action | Type | Owner | Priority | Due date | Verification / effectiveness measure | Status |
|---|---|---|---|---|---|---|

## Learning review checklist
- [ ] Facts separated from hypotheses
- [ ] User/business impact quantified where evidence allows
- [ ] No individual blame or vague "human error" endpoint
- [ ] Contributing system/process conditions documented
- [ ] Detection and response gaps addressed
- [ ] Actions have owners, due dates, and effectiveness checks
- [ ] Runbooks/alerts/tests updated where appropriate
