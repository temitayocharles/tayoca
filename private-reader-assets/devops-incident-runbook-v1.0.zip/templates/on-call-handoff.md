# On-Call Handoff

- Rotation/date range:
- Outgoing engineer:
- Incoming engineer:

## Active incidents

## Degraded services / known risks

## Recent SEV1/SEV2 incidents and open actions

## Active alert silences
| Alert | Reason | Owner | Expiry | Ticket |
|---|---|---|---|---|

## Planned changes / maintenance

## SLO / error-budget concerns

## Access or tooling concerns

## Notes for next on-call
