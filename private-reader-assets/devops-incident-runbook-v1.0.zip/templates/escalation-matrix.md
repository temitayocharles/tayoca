# Escalation Matrix Template

Times below are examples. Align them to your paging policy and staffing model.

| Elapsed | Trigger | Action | Owner | Evidence |
|---:|---|---|---|---|
| 0 min | Alert fires | Page primary; create alert record | Alerting system | Alert ID |
| 10 min | No acknowledgement | Page secondary / manager-on-call | Alerting system | Escalation record |
| 15 min | SEV1/SEV2 confirmed | Create incident room, ticket, roles, timeline | Primary until IC assigned | Links in incident record |
| 30 min | Unresolved or ownership unclear | Escalate to incident commander / service owner | IC | Escalation note |
| 60 min | High-impact incident persists | Add senior engineering/business decision maker | IC | Decision log |

## Organization contacts
| Function | Primary | Backup | Channel / pager |
|---|---|---|---|
| On-call primary | | | |
| On-call secondary | | | |
| Incident commander | | | |
| Service owner | | | |
| Security/privacy | | | |
| Customer support/comms | | | |
| Executive escalation | | | |
