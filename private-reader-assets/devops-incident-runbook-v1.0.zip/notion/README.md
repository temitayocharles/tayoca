# Notion-ready import

Import `../templates/notion-ready-import.csv` into a Notion database. Treat the supplied columns as a starter schema, then add your own select/status properties if desired.

Recommended properties:
- Incident ID: title
- Severity: select
- Status: status
- Started At: date
- Incident Commander: person or text
- Technical Lead: person or text
- Comms Lead: person or text
- Scribe: person or text
- Impact: text
- Current Mitigation: text
- Next Update: date
- Postmortem Due: date

The CSV contains placeholders only. No organization-specific contacts, domains, credentials, or private incident history are included.
