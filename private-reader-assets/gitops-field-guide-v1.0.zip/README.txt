GitOps Field Guide — Reconstructed Edition 1.0
Author: Temitayo Charles
Imprint: Tayoca Books

Customer bundle contents:
- publication/GitOps_Field_Guide_v1.0.pdf
- reference-repo/ scaffold
- sources/SOURCES.md

Validation summary:
- Helm v4.2.4 lint/template PASS
- Kustomize v5.8.1 staging, production, and platform builds PASS
- YAML and semantic checks PASS

Provider credentials, secret-store authentication, and environment-specific rollout policy are intentionally excluded from the bundle.
