# Source and provenance ledger

This reconstructed edition is based on:

- the existing commercial product contract for **GitOps Field Guide**;
- recovered operational GitOps material covering Argo CD, Flux, Helm, environment promotion, multi-cluster operation, drift detection, External Secrets, and GitOps repository structure;
- a recovered hands-on Argo CD lab demonstrating Git as desired state and Argo CD as the deployment reconciler;
- current upstream documentation reviewed on 2026-08-28.

## Current upstream references

- Argo CD sync phases and waves: https://argo-cd.readthedocs.io/en/latest/user-guide/sync-waves/
- Flux Kustomization dependencies and health checks: https://fluxcd.io/flux/components/kustomize/kustomizations/
- External Secrets Operator SecretStore: https://external-secrets.io/main/api/secretstore/
- External Secrets Operator ExternalSecret: https://external-secrets.io/main/api/externalsecret/
- Argo Rollouts: https://argoproj.github.io/rollouts/
- Kustomize releases: https://github.com/kubernetes-sigs/kustomize/releases
- Helm releases: https://github.com/helm/helm/releases

## Recovery status

The exact historical commercial customer bundle was not recovered. This release is explicitly a **new validated reconstructed edition**, not a byte-for-byte restoration.

## Privacy and provenance rule

Operational source material is used for general architecture and operating patterns only. Organization-specific infrastructure names, private URLs, credentials, internal service identifiers, and proprietary operating details are not included in the customer package.
