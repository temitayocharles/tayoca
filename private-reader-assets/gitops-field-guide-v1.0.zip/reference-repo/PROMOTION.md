# Promotion model

Promote by pull request, not by mutating the cluster. A release PR changes an immutable image tag or digest in the staging overlay. After validation, a second reviewed PR applies the same tested artifact to production. Keep environment-specific policy and replica settings in overlays; keep application identity in the base.
