# External Secrets

`external-secret.yaml` uses the current `external-secrets.io/v1` API and references a namespaced `SecretStore` called `platform-secret-store`. Create that store separately for your provider (AWS Secrets Manager, Vault, Azure Key Vault, etc.) using workload identity or another least-privilege auth method. Do not commit provider credentials here.
