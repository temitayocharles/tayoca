# GitOps Reference Repository

This scaffold demonstrates Argo CD and Flux patterns side by side. Choose one reconciler for a given workload path; do not have both controllers own the same resources.

- `argocd/`: AppProject, root application, ApplicationSet and sync-wave examples.
- `flux/`: GitRepository/Kustomization dependency examples.
- `apps/demo/`: Kustomize base and staging/production overlays.
- `helm/demo/`: small Helm chart used by the examples.
- `secrets/`: External Secrets resource with a deliberately unresolved provider store reference.
- `progressive/`: Argo Rollouts canary example.

The provider-specific SecretStore is intentionally not embedded because credentials and provider auth differ by environment.
