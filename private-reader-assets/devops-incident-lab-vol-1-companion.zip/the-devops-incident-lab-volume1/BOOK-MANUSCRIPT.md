# The DevOps Incident Lab

## No Theories. Roll Up Your Sleeves, Grab Your Coffee, and Get Your Hands Dirty.

### The promise

Most engineers are taught what working systems look like. Senior engineers are shaped by the moments when systems stop behaving as expected, evidence conflicts, time matters, and an easy fix creates a more dangerous failure.

This book compresses those moments into controlled, repeatable incident laboratories.

You will inherit broken systems, misleading success signals, incomplete operational context, unsafe suggestions, and business constraints. You will investigate, change configuration, validate recovery, and produce evidence another engineer can audit.

This is not a command cookbook. The commands are the easy part.

The difficult work is deciding:

- what evidence is trustworthy;
- which symptom is causal;
- what must not be changed;
- how much risk a fix introduces;
- how to prove users recovered;
- how to preserve rollback and auditability;
- what prevents recurrence.

### Who this is for

The labs are designed for intermediate DevOps engineers, platform engineers, cloud engineers, SREs, security-minded infrastructure engineers, and senior candidates who already understand basic tools but need production judgment.

A beginner can complete the early incidents with careful research. An experienced engineer should still find the later incidents demanding because they combine identity, safety, sequencing, reliability, and business constraints.

### The operating contract

Every incident follows one cycle:

> **Perform. Decide. Prove. Document.**

**Perform:** reproduce the failure and change the environment.  
**Decide:** choose among plausible remediations and reject unsafe shortcuts.  
**Prove:** pass technical, security, recovery, and user-facing gates.  
**Document:** leave an engineering record another operator can use.

A lab is not complete because a process starts, a command exits zero, or a pipeline turns green. It is complete only when the intended production contract is restored and the evidence proves it.

---

# Part I: Enter the Incident Room

## Chapter 1: Success signals can lie

A manifest being accepted does not prove a rollout succeeded. A green build does not prove the correct artifact reached production. A backup job completing does not prove recovery. A permission error disappearing does not prove the new policy is safe.

Treat every success signal as evidence with a defined scope. Ask what it proves and what it does not prove.

## Chapter 2: Evidence before action

Before changing production, capture the current state. At minimum, record:

1. user-visible impact;
2. the earliest known failure time;
3. recent changes;
4. workload, dependency, and infrastructure evidence;
5. the hypothesis your next action is testing;
6. the rollback path.

Do not collect logs without a question. Do not change configuration without a falsifiable hypothesis.

## Chapter 3: Symptoms, mechanisms, and root causes

A pod restarting is a symptom. The mechanism may be process exit, failed liveness, eviction, or node disruption. The root cause may be invalid configuration, a missing resource, or a dependency contract.

Use three layers in your notes:

- **Symptom:** what operators or users observe;
- **Mechanism:** how the system produces that symptom;
- **Cause:** why the mechanism exists.

## Chapter 4: The unsafe-shortcut test

Before accepting a remediation, ask:

- Did we remove a control instead of fixing the system?
- Did we broaden permissions beyond the failing operation?
- Did we introduce a mutable identity?
- Did we hide queueing by adding capacity?
- Did we preserve rollback?
- Did we expose a secret?
- Did we replace a production identity unnecessarily?
- Did we validate the user journey?

The validators intentionally reject common shortcuts.

## Chapter 5: Validation as an engineering artifact

Validation should be explicit, repeatable, and tied to the production contract. A strong validation set covers:

- intended functionality;
- safety and least privilege;
- identity and version correctness;
- rollout or migration completion;
- user-facing behavior;
- rollback or recovery capability;
- empty-plan or steady-state evidence;
- documentation.

## Chapter 6: Scoring

Each incident is scored through automated gates. For coaching or team use, apply this 100-point rubric:

| Dimension | Weight | Evidence |
|---|---:|---|
| Diagnosis | 25 | Correct causal explanation supported by evidence |
| Remediation | 25 | Complete technical repair |
| Safety | 20 | Constraints preserved; shortcuts rejected |
| Validation | 20 | Repeatable proof of recovery |
| Communication | 10 | Clear incident record and defense |

A technically working but unsafe fix cannot score above 60. A response without validation cannot score above 70. A response without documentation cannot be marked complete.

## Chapter 7: How to run a lab

```bash
./labctl start <ID>
./labctl status <ID>
```

Open the briefing and evidence. Work only in `.workspaces/<ID>/`. Record the timeline as you investigate.

Use `status` to observe the current simulated production phase. Use `validate` only when you believe the incident is repaired and documented.

```bash
./labctl validate <ID>
```

When finished, reset and reproduce the failure:

```bash
./labctl reset <ID>
./labctl status <ID>
```

Reproducibility matters. A lab that cannot reliably return to its broken state cannot reliably teach or test the incident.

---

# Part II — Kubernetes Incidents

Kubernetes incidents punish shallow interpretation. A workload can be Running but not Ready, Ready but unreachable, or correctly configured while a controller contract is broken. These labs require you to trace behavior across process, probe, pod, Service, controller, and secret boundaries.

## Part completion standard

Complete every incident, retain the engineering records, and compare your decisions across incidents. Look for recurring patterns: weak identity, incomplete contracts, missing evidence, uncontrolled amplification, and recovery paths that were never tested.

# Incident 001: The Deployment That Passed but Never Worked

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** readiness probes, Service routing, rollout verification, safe remediation

## Situation

A release pipeline accepted every manifest and reported success, but customers receive errors and the Deployment never becomes fully available.

## Your mission

1. Find every independent fault preventing a healthy rollout.
2. Repair the workload without deleting probes, reducing replicas, or exposing the Service publicly.
3. Prove readiness, Service routing, and the user-facing request path.

## Operational constraints

- Keep two replicas.
- Keep the Service as ClusterIP.
- Preserve the readiness probe and resource controls.
- Do not route around the Service.

## Start the incident

```bash
./labctl start 001
./labctl status 001
```

Edit the files inside:

```text
.workspaces/001/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `deployment.yaml`
- `service.yaml`

## Evidence supplied

- `pipeline-output.txt`
- `deployment-events.txt`

## Completion standard

Run:

```bash
./labctl validate 001
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/001/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 002: The Pod That Would Not Stay Alive

**Level:** Intermediate  
**Target time:** 50–80 minutes  
**Core skills:** CrashLoopBackOff, previous logs, liveness, security context

## Situation

A payments API enters CrashLoopBackOff after a configuration change. The first obvious fix only reveals a second restart mechanism.

## Your mission

1. Use the failure sequence to distinguish process exit from kubelet restart.
2. Repair startup and liveness contracts.
3. Preserve non-root execution, resource controls, and readiness.

## Operational constraints

- Do not remove liveness or readiness probes.
- Do not run as root.
- Do not increase restart tolerance to hide the defect.

## Start the incident

```bash
./labctl start 002
./labctl status 002
```

Edit the files inside:

```text
.workspaces/002/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `runtime-config.yaml`
- `content-config.yaml`
- `deployment.yaml`
- `service.yaml`

## Evidence supplied

- `previous-container.log`
- `pod-events.txt`

## Completion standard

Run:

```bash
./labctl validate 002
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/002/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 004: The Secret That Never Reached the Cluster

**Level:** Intermediate  
**Target time:** 50–85 minutes  
**Core skills:** External Secrets, contract mapping, secret governance, rotation

## Situation

External Secrets reports reconciliation errors, and the application cannot resolve DB_PASSWORD. A rushed engineer proposes embedding the value in the Deployment.

## Your mission

1. Repair the governed secret store reference.
2. Align the generated Secret key with the Deployment contract.
3. Keep the value outside Git and preserve secret rotation.

## Operational constraints

- No plaintext secret values.
- No manually created static Secret.
- Keep hourly refresh.
- Use the governed production store.

## Start the incident

```bash
./labctl start 004
./labctl status 004
```

Edit the files inside:

```text
.workspaces/004/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `external-secret.yaml`
- `deployment.yaml`

## Evidence supplied

- `external-secret-status.txt`
- `pod-event.txt`

## Completion standard

Run:

```bash
./labctl validate 004
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/004/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 019: The Helm Release That Failed Halfway

**Level:** Advanced  
**Target time:** 60–95 minutes  
**Core skills:** Helm, atomic upgrades, hooks, rollback

## Situation

A pre-upgrade hook fails after several resources have changed, leaving a mixed release and no reliable rollback point.

## Your mission

1. Make the release atomic and readiness-gated.
2. Protect stateful data before upgrade.
3. Use immutable artifacts and deterministic hook cleanup.

## Operational constraints

- No manual deletion of failed resources.
- No mutable image tags.
- Rollback must preserve data.

## Start

```bash
./labctl start 019
./labctl status 019
```

Edit `.workspaces/019/` only.

## Files under your control

- `helm-values.yaml`
- `release.json`

## Evidence

- `helm-error.txt`

## Completion

```bash
./labctl validate 019
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 020: The Persistent Volume That Would Not Reattach

**Level:** Advanced  
**Target time:** 65–105 minutes  
**Core skills:** persistent volumes, fencing, attachment recovery, data integrity

## Situation

A stateful pod moves after node failure, but its ReadWriteOnce volume remains attached to the former node.

## Your mission

1. Prove the old writer is fenced.
2. Recover attachment without force-detach corruption risk.
3. Validate filesystem and application data.

## Operational constraints

- Do not switch to ReadWriteMany.
- Do not force detach before fencing.
- Verify backup first.

## Start

```bash
./labctl start 020
./labctl status 020
```

Edit `.workspaces/020/` only.

## Files under your control

- `storage-recovery.json`

## Evidence

- `volume-events.txt`

## Completion

```bash
./labctl validate 020
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 021: The HPA That Watched Traffic but Never Scaled

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** HPA, resource requests, stabilization, load testing

## Situation

Traffic triples, latency rises, and the HorizontalPodAutoscaler remains at two replicas because utilization cannot be calculated.

## Your mission

1. Restore meaningful utilization metrics.
2. Create a real scaling range and stable behavior.
3. Prove scaling under controlled load.

## Operational constraints

- Do not add fixed replicas as the final answer.
- Keep two minimum replicas.
- Avoid scale-down flapping.

## Start

```bash
./labctl start 021
./labctl status 021
```

Edit `.workspaces/021/` only.

## Files under your control

- `hpa.yaml`
- `deployment.yaml`

## Evidence

- `hpa-status.txt`

## Completion

```bash
./labctl validate 021
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 022: The NetworkPolicy That Blocked DNS

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** NetworkPolicy, DNS, egress controls, connectivity testing

## Situation

A default-deny egress policy protects the namespace but silently blocks cluster DNS, making every dependency appear unavailable.

## Your mission

1. Allow only required DNS traffic.
2. Preserve default deny.
3. Prove DNS and HTTPS dependency access.

## Operational constraints

- No allow-all egress.
- Scope DNS to kube-system and DNS pods.
- Keep dependency port restricted.

## Start

```bash
./labctl start 022
./labctl status 022
```

Edit `.workspaces/022/` only.

## Files under your control

- `network-policy.yaml`

## Evidence

- `connection-test.txt`

## Completion

```bash
./labctl validate 022
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 023: The Emergency Hotfix GitOps Tried to Undo

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** GitOps drift, emergency change, self-healing, governance

## Situation

An engineer patches production directly during an outage. The fix works, but Git still contains the broken revision and self-healing is disabled.

## Your mission

1. Represent the emergency fix in Git.
2. Converge cluster and desired SHA.
3. Restore drift detection and controlled self-healing.

## Operational constraints

- No permanent kubectl-only fix.
- Pruning needs approval.
- Keep an emergency change record.

## Start

```bash
./labctl start 023
./labctl status 023
```

Edit `.workspaces/023/` only.

## Files under your control

- `gitops-state.json`

## Evidence

- `drift.txt`

## Completion

```bash
./labctl validate 023
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.

---

# Part III — CI/CD and GitOps Incidents

Delivery systems fail when identity is ambiguous. Branches, tags, mirrors, and release jobs can all report success while different components refer to different artifacts or commits. These labs make artifact identity and release evidence explicit.

## Part completion standard

Complete every incident, retain the engineering records, and compare your decisions across incidents. Look for recurring patterns: weak identity, incomplete contracts, missing evidence, uncontrolled amplification, and recovery paths that were never tested.

# Incident 005: The Pipeline Was Green but Deployed the Wrong Image

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** immutable artifacts, digest pinning, release verification, provenance

## Situation

The pipeline is green, but production still runs yesterday’s checkout service. The release uses mutable tags and never verifies the running artifact.

## Your mission

1. Connect build output to deployment through one immutable digest.
2. Eliminate mutable-tag ambiguity.
3. Add deployed-digest verification and a user-facing smoke gate.

## Operational constraints

- Do not force a random restart.
- Do not use latest or stable tags.
- Record release provenance.

## Start the incident

```bash
./labctl start 005
./labctl status 005
```

Edit the files inside:

```text
.workspaces/005/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `artifact.json`
- `workflow.yaml`
- `deployment.yaml`

## Evidence supplied

- `pipeline-log.txt`
- `registry-inspection.txt`

## Completion standard

Run:

```bash
./labctl validate 005
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/005/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 006: The GitOps Release That Deployed Yesterday’s Commit

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** Git mirror consistency, GitOps revision pinning, release gates, evidence

## Situation

Forgejo reports a successful release, but the GitHub mirror is behind. Argo CD follows main and reconciles a stale commit.

## Your mission

1. Make mirror synchronization an explicit release gate.
2. Compare source and mirror SHAs.
3. Pin Argo CD and release evidence to the intended commit.

## Operational constraints

- Do not add arbitrary sleep.
- Use a bounded wait.
- Fail on SHA mismatch.
- Deploy an exact commit, not a branch.

## Start the incident

```bash
./labctl start 006
./labctl status 006
```

Edit the files inside:

```text
.workspaces/006/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `mirror.json`
- `workflow.yaml`
- `argocd-application.yaml`

## Evidence supplied

- `mirror-status.txt`
- `argocd-history.txt`

## Completion standard

Run:

```bash
./labctl validate 006
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/006/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 007: The Rollback That Could Not Roll Back

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** rollback design, artifact retention, deployment evidence, recovery timing

## Situation

A release fails. The rollback job points to stable, but stable was overwritten by the bad build and the prior digest was never retained.

## Your mission

1. Create an immutable current and previous release chain.
2. Define a bounded rollback to a known digest.
3. Require rollback smoke tests and evidence.

## Operational constraints

- Do not rebuild the previous version.
- Do not use mutable tags.
- Do not call rollback complete before smoke validation.

## Start the incident

```bash
./labctl start 007
./labctl status 007
```

Edit the files inside:

```text
.workspaces/007/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `release-history.json`
- `pipeline.yaml`
- `deployment.yaml`

## Evidence supplied

- `release-history.txt`
- `rollback-log.txt`

## Completion standard

Run:

```bash
./labctl validate 007
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/007/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 024: The Deployment Credential That Expired at Release Time

**Level:** Advanced  
**Target time:** 50–80 minutes  
**Core skills:** OIDC, CI identity, AWS STS, least privilege

## Situation

A production release fails because a long-lived AWS key expired. The proposed fallback stores a new administrator key in CI.

## Your mission

1. Replace static credentials with OIDC.
2. Restrict trust to one repository and branch.
3. Bound permissions and session duration.

## Operational constraints

- No static fallback.
- No write-all repository permission.
- Assume one governed role.

## Start

```bash
./labctl start 024
./labctl status 024
```

Edit `.workspaces/024/` only.

## Files under your control

- `oidc-workflow.yaml`

## Evidence

- `auth-error.txt`

## Completion

```bash
./labctl validate 024
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 025: The Vulnerability Gate That Passed a Dangerous Image

**Level:** Advanced  
**Target time:** 50–85 minutes  
**Core skills:** vulnerability gates, exception governance, digest scanning, fail closed

## Situation

The scanner reports a high-severity exploitable package, but the pipeline blocks only critical findings and exceptions never expire.

## Your mission

1. Scan the immutable digest with a fresh database.
2. Fail on high and critical risk.
3. Govern every exception with owner, ticket, and expiry.

## Operational constraints

- Do not ignore unfixed risk.
- Fail closed on scanner error.
- No permanent allowlist.

## Start

```bash
./labctl start 025
./labctl status 025
```

Edit `.workspaces/025/` only.

## Files under your control

- `vulnerability-policy.yaml`

## Evidence

- `scan.txt`

## Completion

```bash
./labctl validate 025
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 026: The CDN That Kept Serving Yesterday’s Release

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** CDN caching, invalidation, checksums, release verification

## Situation

Origin files are correct, but users receive an old index page because HTML and hashed assets share the same long cache policy.

## Your mission

1. Separate mutable entry-point and immutable asset caching.
2. Invalidate only what must change.
3. Verify content through the CDN.

## Operational constraints

- Do not invalidate every asset.
- Keep hashed assets cacheable for a year.
- Prove edge content.

## Start

```bash
./labctl start 026
./labctl status 026
```

Edit `.workspaces/026/` only.

## Files under your control

- `cdn-release.yaml`

## Evidence

- `cdn-check.txt`

## Completion

```bash
./labctl validate 026
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 027: The Build Cache That Hid a Dependency Change

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** build caching, lockfiles, deterministic builds, dependency evidence

## Situation

A branch cache restores an incompatible dependency tree, and npm install quietly rewrites resolution despite a changed lockfile.

## Your mission

1. Bind cache identity to lockfile and toolchain.
2. Use deterministic installation.
3. Record dependency evidence.

## Operational constraints

- No branch-only cache key.
- No broad cross-version restore key.
- Do not rewrite lockfiles in CI.

## Start

```bash
./labctl start 027
./labctl status 027
```

Edit `.workspaces/027/` only.

## Files under your control

- `cache-policy.yaml`

## Evidence

- `build-log.txt`

## Completion

```bash
./labctl validate 027
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 028: The Tag Trigger That Bypassed Production Approval

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** approval gates, protected environments, signed tags, change control

## Situation

Main-branch deploys require approval, but a release tag follows a separate job that writes directly to production.

## Your mission

1. Route every production path through one protected environment.
2. Bind approval to a signed tag, digest, and change record.
3. Audit emergency release paths.

## Operational constraints

- No conditional bypass.
- At least one required reviewer.
- Post-deploy verification remains mandatory.

## Start

```bash
./labctl start 028
./labctl status 028
```

Edit `.workspaces/028/` only.

## Files under your control

- `production-gate.yaml`

## Evidence

- `workflow-audit.txt`

## Completion

```bash
./labctl validate 028
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.

---

# Part IV — Terraform and Cloud Incidents

Infrastructure incidents are often identity and state incidents. The safest action may be to move an address, adopt an object, constrain one permission, or remove a value from state. Replacement and broad access are deliberately treated as last resorts.

## Part completion standard

Complete every incident, retain the engineering records, and compare your decisions across incidents. Look for recurring patterns: weak identity, incomplete contracts, missing evidence, uncontrolled amplification, and recovery paths that were never tested.

# Incident 003: The Terraform Plan That Wanted to Destroy Production

**Level:** Intermediate  
**Target time:** 45–70 minutes  
**Core skills:** plan review, for_each identity, moved blocks, state safety

## Situation

A harmless naming cleanup changes for_each keys. Terraform now proposes destroying and recreating two production resources.

## Your mission

1. Explain why the resource addresses changed identity.
2. Represent the refactor with declarative state moves.
3. Prove the final plan contains no create or destroy actions.

## Operational constraints

- Do not use targeted apply.
- Do not manually edit state JSON.
- Do not accept replacement.
- Preserve both resource identities.

## Start the incident

```bash
./labctl start 003
./labctl status 003
```

Edit the files inside:

```text
.workspaces/003/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `migration.tf`

## Evidence supplied

- `initial-plan.txt`
- `change-request.md`

## Completion standard

Run:

```bash
./labctl validate 003
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/003/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 008: The Partial Apply and the Orphaned Production Resource

**Level:** Advanced  
**Target time:** 70–110 minutes  
**Core skills:** drift analysis, import/adoption, partial apply recovery, identity preservation

## Situation

A failed apply created a production instance outside state while an out-of-band security-group change opened ingress globally.

## Your mission

1. Assess actual state before changing anything.
2. Adopt the orphaned resource.
3. Reconcile drift without replacing the production instance.
4. Require an empty post-apply plan.

## Operational constraints

- No resource replacement.
- Use state locking.
- Begin with refresh-only assessment.
- Restore the approved CIDR.

## Start the incident

```bash
./labctl start 008
./labctl status 008
```

Edit the files inside:

```text
.workspaces/008/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `observed-state.json`
- `desired-state.json`
- `remediation.json`

## Evidence supplied

- `cloud-inventory.json`
- `failed-apply.log`

## Completion standard

Run:

```bash
./labctl validate 008
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/008/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 009: The IAM Denial and the Dangerous One-Line Fix

**Level:** Intermediate  
**Target time:** 50–80 minutes  
**Core skills:** IAM diagnosis, least privilege, KMS context, policy review

## Situation

The deployment role cannot read an encrypted release artifact. A proposed fix grants s3:* and kms:* on every resource.

## Your mission

1. Grant only the missing object-read and decrypt capabilities.
2. Scope S3 to the release prefix and KMS to one key.
3. Constrain decrypt with encryption context.

## Operational constraints

- No wildcard action.
- No Resource "*".
- Do not grant write permissions.
- Preserve least privilege.

## Start the incident

```bash
./labctl start 009
./labctl status 009
```

Edit the files inside:

```text
.workspaces/009/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `policy.json`

## Evidence supplied

- `access-denied.json`
- `cloudtrail-event.json`

## Completion standard

Run:

```bash
./labctl validate 009
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/009/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 010: The Secret That Terraform Remembered Forever

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** Terraform state security, secret references, state remediation, data classification

## Situation

A database password was passed into Terraform and now exists in local state, backups, and plan artifacts despite being marked sensitive.

## Your mission

1. Remove the value from Terraform configuration and state.
2. Model only a governed external secret reference.
3. Prevent outputs or declassification from reintroducing exposure.

## Operational constraints

- Sensitive is not sufficient if the value remains in state.
- Do not replace one plaintext variable with another.
- Do not expose the value through outputs.

## Start the incident

```bash
./labctl start 010
./labctl status 010
```

Edit the files inside:

```text
.workspaces/010/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `main.tf`
- `state.json`

## Evidence supplied

- `state-audit.txt`
- `plan-redaction.txt`

## Completion standard

Run:

```bash
./labctl validate 010
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/010/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 029: The Terraform State Lock Nobody Should Force-Unlock Yet

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** state locking, concurrency, force unlock, state recovery

## Situation

Terraform reports a lock. The operation began three minutes ago, and nobody has confirmed whether the runner is still alive.

## Your mission

1. Identify the lock owner and operation.
2. Distinguish active from stale lock.
3. Back up state and perform controlled recovery only when safe.

## Operational constraints

- No blind force-unlock.
- Target the exact lock ID.
- Run refresh-only assessment afterward.

## Start

```bash
./labctl start 029
./labctl status 029
```

Edit `.workspaces/029/` only.

## Files under your control

- `state-lock-recovery.json`

## Evidence

- `lock-info.txt`

## Completion

```bash
./labctl validate 029
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 030: The Reusable Module That Created a Public Database

**Level:** Advanced  
**Target time:** 60–95 minutes  
**Core skills:** Terraform modules, RDS security, validation, secure defaults

## Situation

A default combination places production RDS in public subnets with broad CIDR ingress and no deletion protection.

## Your mission

1. Make network placement private.
2. Restrict ingress to the runtime security group.
3. Enforce encryption, backups, deletion protection, and unsafe-combination validation.

## Operational constraints

- No public CIDR.
- Fix the reusable module contract, not only one caller.
- Preserve recoverability.

## Start

```bash
./labctl start 030
./labctl status 030
```

Edit `.workspaces/030/` only.

## Files under your control

- `database-module.yaml`

## Evidence

- `plan.txt`

## Completion

```bash
./labctl validate 030
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 031: The Teardown Plan That Targeted Shared Infrastructure

**Level:** Advanced  
**Target time:** 60–100 minutes  
**Core skills:** safe teardown, ownership, shared resources, orphan cleanup

## Situation

An application teardown includes the shared VPC, state bucket, and lock table because ownership boundaries were never encoded.

## Your mission

1. Delete only owned resources.
2. Preserve shared control-plane infrastructure.
3. Remove only the application state prefix and prove cleanup.

## Operational constraints

- No shared VPC deletion.
- No state bucket deletion.
- Run dependency and orphan scans.

## Start

```bash
./labctl start 031
./labctl status 031
```

Edit `.workspaces/031/` only.

## Files under your control

- `teardown-plan.json`

## Evidence

- `destroy-plan.txt`

## Completion

```bash
./labctl validate 031
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 032: The Quiet Cloud Configuration That Became a Cost Incident

**Level:** Intermediate  
**Target time:** 50–85 minutes  
**Core skills:** FinOps, right-sizing, retention, budget controls

## Situation

Non-production runs three NAT gateways, infinite logs, oversized compute, and idle environments around the clock without budgets.

## Your mission

1. Reduce structural network cost.
2. Bound retention and idle runtime.
3. Right-size from evidence and add cost observability.

## Operational constraints

- Do not sacrifice production resilience assumptions blindly.
- Keep cost-allocation tags.
- Set measurable budget alerts.

## Start

```bash
./labctl start 032
./labctl status 032
```

Edit `.workspaces/032/` only.

## Files under your control

- `cost-controls.yaml`

## Evidence

- `cost-report.txt`

## Completion

```bash
./labctl validate 032
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.

---

# Part V — SRE and Production Operations

SRE work begins where component health stops explaining user experience. These incidents focus on latency, amplification, recoverability, alert usability, and measurable operational objectives.

## Part completion standard

Complete every incident, retain the engineering records, and compare your decisions across incidents. Look for recurring patterns: weak identity, incomplete contracts, missing evidence, uncontrolled amplification, and recovery paths that were never tested.

# Incident 011: The Service Was Slow but CPU Looked Fine

**Level:** Advanced  
**Target time:** 65–100 minutes  
**Core skills:** latency decomposition, queueing, retry amplification, SLO validation

## Situation

Checkout p95 exceeds two seconds while CPU remains below 35%. Traces show queueing at the database pool and retries extending request lifetimes.

## Your mission

1. Use latency evidence instead of CPU assumptions.
2. Bound queues, retries, and deadlines.
3. Resize the connection pool from measured concurrency.
4. Prove the SLO through simulation.

## Operational constraints

- Do not simply add CPU.
- Keep tracing enabled.
- Database timeout must remain below the request deadline.

## Start the incident

```bash
./labctl start 011
./labctl status 011
```

Edit the files inside:

```text
.workspaces/011/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `service-config.yaml`

## Evidence supplied

- `trace-summary.json`
- `slo-dashboard.txt`

## Completion standard

Run:

```bash
./labctl validate 011
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/011/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 012: The Dependency Failure That Took Down Healthy Services

**Level:** Advanced  
**Target time:** 65–100 minutes  
**Core skills:** circuit breakers, bulkheads, retry control, graceful degradation

## Situation

The tax service slows down. Five retries per request exhaust upstream pools, and otherwise healthy services begin failing.

## Your mission

1. Contain dependency pressure.
2. Introduce bounded retries, jitter, bulkheads, deadlines, and a circuit breaker.
3. Provide a controlled degraded response.

## Operational constraints

- Do not remove all failure handling.
- Do not increase global thread pools.
- Keep customer responses deterministic.

## Start the incident

```bash
./labctl start 012
./labctl status 012
```

Edit the files inside:

```text
.workspaces/012/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `resilience.yaml`

## Evidence supplied

- `dependency-graph.json`
- `retry-metrics.txt`

## Completion standard

Run:

```bash
./labctl validate 012
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/012/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 013: The Backup That Existed but Could Not Restore

**Level:** Advanced  
**Target time:** 70–110 minutes  
**Core skills:** recoverability, restore testing, encryption dependencies, RTO/RPO

## Situation

Nightly backups are green, but a restore rehearsal fails because encryption-key context and secret metadata were not captured.

## Your mission

1. Make the backup set operationally complete.
2. Align the runbook to the current format.
3. Pass integrity, RTO, and RPO gates in a controlled restore test.

## Operational constraints

- Do not call a backup valid without restore evidence.
- Retain an immutable copy.
- Verify key access before restore.

## Start the incident

```bash
./labctl start 013
./labctl status 013
```

Edit the files inside:

```text
.workspaces/013/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `backup-policy.yaml`
- `restore-runbook.json`
- `restore-test.json`

## Evidence supplied

- `backup-job.log`
- `restore-failure.txt`

## Completion standard

Run:

```bash
./labctl validate 013
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/013/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 014: The Alert Storm That Hid the Real Outage

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** alert design, SLO burn rates, inhibition, on-call usability

## Situation

One database outage creates eight pages from six downstream services. The on-call engineer spends the first ten minutes acknowledging symptoms.

## Your mission

1. Reduce pages to causal, actionable signals.
2. Group and deduplicate alerts.
3. Inhibit downstream symptoms.
4. Use fast and slow SLO burn routing.

## Operational constraints

- Do not silence the outage.
- Every page needs a runbook.
- Keep slow-burn risk visible without paging.

## Start the incident

```bash
./labctl start 014
./labctl status 014
```

Edit the files inside:

```text
.workspaces/014/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `alerts.yaml`

## Evidence supplied

- `pager-timeline.txt`
- `alert-sample.json`

## Completion standard

Run:

```bash
./labctl validate 014
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/014/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 033: The SLO That Stayed Green During a Checkout Outage

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** SLIs, SLOs, error budgets, synthetic monitoring

## Situation

The service reports 99.99% availability because the SLI counts a lightweight health endpoint while payment callbacks fail.

## Your mission

1. Measure the complete critical journey.
2. Define latency and availability indicators.
3. Drive fast and slow burn response.

## Operational constraints

- Do not count health checks as customer success.
- Include asynchronous completion.
- Keep a synthetic journey.

## Start

```bash
./labctl start 033
./labctl status 033
```

Edit `.workspaces/033/` only.

## Files under your control

- `slo.yaml`

## Evidence

- `incident.txt`

## Completion

```bash
./labctl validate 033
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 034: The On-Call Handover That Lost an Unresolved Risk

**Level:** Intermediate  
**Target time:** 40–70 minutes  
**Core skills:** on-call handover, operational communication, risk ownership, continuity

## Situation

A degraded queue remains under observation, but the next shift receives only “all quiet” and no evidence, owner, or next check.

## Your mission

1. Carry unresolved incidents and known risks across shifts.
2. Assign ownership and next verification time.
3. Link evidence, rollback state, and customer impact.

## Operational constraints

- No vague “monitoring” statement.
- Receiver must acknowledge.
- Keep evidence links.

## Start

```bash
./labctl start 034
./labctl status 034
```

Edit `.workspaces/034/` only.

## Files under your control

- `handover.json`

## Evidence

- `handover-chat.txt`

## Completion

```bash
./labctl validate 034
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 035: The Disk With Plenty of Space but No Performance Left

**Level:** Advanced  
**Target time:** 60–95 minutes  
**Core skills:** IOPS, storage latency, queueing, benchmarking

## Situation

Database storage is only 40% full, yet I/O latency spikes because a small gp2 volume exhausts burst credits and queues thousands of writes.

## Your mission

1. Diagnose performance rather than capacity.
2. Provision independent IOPS and throughput.
3. Bound application queues and prove a storage baseline.

## Operational constraints

- Do not solve by adding disk capacity alone.
- Keep free-space headroom.
- Add actionable latency alerts.

## Start

```bash
./labctl start 035
./labctl status 035
```

Edit `.workspaces/035/` only.

## Files under your control

- `storage-performance.yaml`

## Evidence

- `storage-metrics.txt`

## Completion

```bash
./labctl validate 035
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 036: The DNS Failure That Looked Like Every Application Failed

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** DNS reliability, synthetics, caching, runbooks

## Situation

A single cluster resolver fails. Applications report dependency timeouts, but no DNS-specific synthetic or runbook exists.

## Your mission

1. Remove the resolver single point.
2. Bound query retries and add caching.
3. Monitor DNS directly and document response.

## Operational constraints

- No infinite application retries.
- Keep TTL recovery-friendly.
- Use redundant resolvers.

## Start

```bash
./labctl start 036
./labctl status 036
```

Edit `.workspaces/036/` only.

## Files under your control

- `dns-reliability.yaml`

## Evidence

- `timeout-sample.txt`

## Completion

```bash
./labctl validate 036
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.

---

# Part VI — Senior Engineer Challenges

The senior challenges combine systems and constraints. There is no single component to restart. You must order changes, preserve data, enforce trust, control automation, meet recovery objectives, and leave an auditable path for the next engineer.

## Part completion standard

Complete every incident, retain the engineering records, and compare your decisions across incidents. Look for recurring patterns: weak identity, incomplete contracts, missing evidence, uncontrolled amplification, and recovery paths that were never tested.

# Incident 015: Senior Challenge: Checkout Failed Across App, Database, and Queue

**Level:** Senior  
**Target time:** 100–160 minutes  
**Core skills:** multi-system reasoning, safe sequencing, feature flags, data integrity

## Situation

A checkout feature was enabled before a schema migration completed. Messages back up, retries duplicate work, and rollback risks incompatible writes.

## Your mission

1. Stabilize traffic without data loss.
2. Sequence feature flags, backward-compatible migration, queue control, deployment, and smoke tests.
3. Create a rollback checkpoint before reactivation.

## Operational constraints

- Zero data loss.
- No destructive database rollback.
- Keep a dead-letter path.
- Document the exact recovery order.

## Start the incident

```bash
./labctl start 015
./labctl status 015
```

Edit the files inside:

```text
.workspaces/015/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `feature-flags.json`
- `database.json`
- `queue.yaml`
- `change-plan.json`

## Evidence supplied

- `incident-timeline.json`
- `queue-depth.txt`
- `database-errors.txt`

## Completion standard

Run:

```bash
./labctl validate 015
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/015/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 016: Senior Challenge: The Artifact Came From the Wrong Builder

**Level:** Senior  
**Target time:** 85–140 minutes  
**Core skills:** supply-chain security, signatures, provenance, admission policy

## Situation

A correctly named image digest arrives from an untrusted workflow. The cluster admits it because signature and provenance enforcement are optional.

## Your mission

1. Verify digest, signature, issuer, subject, SBOM, and provenance.
2. Enforce the checks at admission.
3. Make verification a pre-deployment pipeline gate.

## Operational constraints

- Do not trust a tag or registry location alone.
- Trust one issuer and one repository subject.
- Reject unsigned artifacts.

## Start the incident

```bash
./labctl start 016
./labctl status 016
```

Edit the files inside:

```text
.workspaces/016/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `attestation.json`
- `admission-policy.yaml`
- `workflow.yaml`

## Evidence supplied

- `registry-event.json`
- `admission-audit.txt`

## Completion standard

Run:

```bash
./labctl validate 016
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/016/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 017: Senior Challenge: The AI Agent Proposed a Dangerous Fix

**Level:** Senior  
**Target time:** 90–145 minutes  
**Core skills:** AI operations safety, prompt injection, least privilege, human approval

## Situation

An operations agent reads a malicious instruction embedded in logs and proposes deleting a Deployment. Its tool role allows wildcard verbs and no approval.

## Your mission

1. Separate untrusted evidence from instructions.
2. Make investigation read-only by default.
3. Require independent evidence, approval, bounded patch permissions, and rollback.

## Operational constraints

- No wildcard verbs.
- No delete permission.
- Every write requires approval.
- Actions remain namespace-scoped.

## Start the incident

```bash
./labctl start 017
./labctl status 017
```

Edit the files inside:

```text
.workspaces/017/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `agent-policy.yaml`
- `tool-permissions.json`
- `proposed-action.json`

## Evidence supplied

- `agent-transcript.txt`
- `rbac-audit.json`

## Completion standard

Run:

```bash
./labctl validate 017
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/017/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 018: Senior Challenge: The Fifteen-Minute Disaster Recovery Capstone

**Level:** Senior  
**Target time:** 120–180 minutes  
**Core skills:** DR orchestration, RTO/RPO, fencing, failover/failback

## Situation

The primary region is unavailable. DNS TTL is 30 minutes, replication lag is 12 minutes, and the runbook can promote without fencing the former primary.

## Your mission

1. Design and prove a failover that meets RTO 15 and RPO 5.
2. Prevent split brain.
3. Validate critical journeys after promotion.
4. Capture evidence and define failback.

## Operational constraints

- Primary fencing before promotion.
- Controlled approval.
- RTO ≤15 minutes.
- RPO ≤5 minutes.
- Full exercise evidence required.

## Start the incident

```bash
./labctl start 018
./labctl status 018
```

Edit the files inside:

```text
.workspaces/018/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `dr-plan.yaml`
- `failover-runbook.json`

## Evidence supplied

- `regional-status.json`
- `replication-lag.txt`
- `exercise-log.txt`

## Completion standard

Run:

```bash
./labctl validate 018
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/018/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 037: Senior Challenge: The Zero-Downtime Schema Migration

**Level:** Senior  
**Target time:** 100–160 minutes  
**Core skills:** database migration, expand-contract, backfill, rollback

## Situation

A migration drops an old column in the same release that introduces a replacement, while old application instances are still serving traffic.

## Your mission

1. Design an expand-and-contract sequence.
2. Keep every phase backward compatible.
3. Throttle backfill, verify parity, preserve rollback, and delay contract.

## Operational constraints

- No same-release destructive contract.
- Lock time under 500 ms.
- Prove zero downtime.

## Start

```bash
./labctl start 037
./labctl status 037
```

Edit `.workspaces/037/` only.

## Files under your control

- `migration-plan.json`

## Evidence

- `migration-error.txt`

## Completion

```bash
./labctl validate 037
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 038: Senior Challenge: Regional Failover Replayed Every Message

**Level:** Senior  
**Target time:** 95–150 minutes  
**Core skills:** messaging, idempotency, regional failover, replay

## Situation

The secondary region starts consuming from an old checkpoint, and consumers assumed exactly-once delivery, duplicating payment side effects.

## Your mission

1. Make business operations idempotent.
2. Replicate replay checkpoints.
3. Use transactional outbox, deduplication, DLQ, and replay validation.

## Operational constraints

- Do not assume exactly once.
- Protect business side effects.
- Keep poison messages auditable.

## Start

```bash
./labctl start 038
./labctl status 038
```

Edit `.workspaces/038/` only.

## Files under your control

- `message-failover.yaml`

## Evidence

- `duplicate-events.txt`

## Completion

```bash
./labctl validate 038
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 039: Senior Challenge: One Tenant Could Read Another Tenant’s Data

**Level:** Senior  
**Target time:** 100–160 minutes  
**Core skills:** multi-tenancy, RLS, cache isolation, authorization

## Situation

The API trusts a tenant header, the cache key omits tenant identity, and the database has no row-level security.

## Your mission

1. Derive tenant identity from verified authentication.
2. Enforce independent database isolation.
3. Scope cache, storage, tests, audit, and logs.

## Operational constraints

- Do not trust client tenant headers.
- Add cross-tenant negative tests.
- Redact customer data in logs.

## Start

```bash
./labctl start 039
./labctl status 039
```

Edit `.workspaces/039/` only.

## Files under your control

- `tenant-isolation.yaml`

## Evidence

- `security-report.txt`

## Completion

```bash
./labctl validate 039
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 040: Senior Challenge: The Production Readiness Review

**Level:** Senior  
**Target time:** 120–180 minutes  
**Core skills:** production readiness, risk review, recovery, operational ownership

## Situation

A new service can deploy and pass a happy-path demo, but ownership, SLOs, rollback, restore, DR, provenance, capacity, and risk acceptance are incomplete.

## Your mission

1. Decide whether the service is actually ready for production.
2. Close reliability, recovery, security, capacity, and ownership gaps.
3. Require accountable launch approval.

## Operational constraints

- No launch with unaccepted critical risk.
- Rollback and restore must be tested.
- Readiness is broader than deployment success.

## Start

```bash
./labctl start 040
./labctl status 040
```

Edit `.workspaces/040/` only.

## Files under your control

- `production-readiness.json`

## Evidence

- `review.txt`

## Completion

```bash
./labctl validate 040
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.

---

# Appendices

## Appendix A: Command reference

```bash
./labctl list
./labctl start <ID>
./labctl status <ID>
./labctl validate <ID>
./labctl reset <ID>
./labctl destroy <ID>
```

The regression-only command below applies the reference remediation. Learners should not use it during normal work:

```bash
./labctl apply-reference <ID>
```

## Appendix B: Workspace anatomy

```text
labs/<ID>-<slug>/
├── briefing/INCIDENT.md
├── broken-environment/
├── partial-environment/
├── evidence/
├── templates/INCIDENT-NOTES.md
├── validators/validate.sh
├── solution/
│   ├── SOLUTION.md
│   ├── REFERENCE-NOTES.md
│   └── fixed-environment/
└── postmortem/POSTMORTEM-TEMPLATE.md
```

The reset source is immutable during the exercise. All learner changes belong in `.workspaces/<ID>/`.

## Appendix C: Team facilitation

For a team exercise:

1. assign incident commander, investigator, operator, and scribe roles;
2. reveal evidence incrementally;
3. require a hypothesis before each change;
4. time-box investigation but never bypass safety gates;
5. rotate the incident commander role;
6. review rejected shortcuts, not only the final fix;
7. run the reset test at the end.

## Appendix D: Interview simulation

A candidate should be able to explain:

- what they observed first;
- what evidence changed their hypothesis;
- which action they deliberately avoided;
- how they bounded blast radius;
- what they used as proof of recovery;
- how they would prevent recurrence.

Do not score candidates by matching the reference solution word for word. Score the quality, safety, and defensibility of their reasoning.

## Appendix E: Glossary

**Blast radius:** the users, systems, or data potentially affected by a change.  
**Causal signal:** evidence directly connected to the failure mechanism.  
**Circuit breaker:** a control that temporarily stops calls to an unhealthy dependency.  
**Digest:** immutable content identity for an artifact.  
**Fencing:** preventing a former primary from accepting writes before another node is promoted.  
**Partial apply:** an infrastructure operation that changed some resources before failing.  
**RPO:** maximum acceptable data-loss window.  
**RTO:** maximum acceptable recovery duration.  
**SLO burn rate:** speed at which a service consumes its error budget.  
**State identity:** the address and object identity Terraform uses to correlate configuration with infrastructure.  
**Unsafe shortcut:** a change that hides symptoms or weakens controls instead of restoring the intended contract.

## Appendix F: Production disclaimer

The portable simulator is intentionally deterministic and creates no cloud resources. The live extensions use local KIND and Terraform/OpenTofu. Do not apply lab configurations to an employer or client environment. Never place real credentials in a lab workspace.
