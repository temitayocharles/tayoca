# Volume 1 Release Notes

## Included

- 18 complete portable incident labs;
- six book parts plus appendices;
- broken, partial, fixed, documented, and reset states;
- 40 standalone validator wrappers;
- deterministic dependency-free Python engine;
- full regression report;
- three preserved live-tool extensions;
- progress tracker and postmortem templates.

## Validation result

All 40 incidents passed the full sandbox lifecycle regression on August 4, 2026.

See `reports/full-regression-report.txt` for the exact phase progression and gate counts.
