#!/usr/bin/env python3
from __future__ import annotations
import importlib.util
import pathlib
import shutil
import sys
from datetime import datetime, timezone

ROOT = pathlib.Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("incident_engine", ROOT / "engine" / "incident_engine.py")
engine = importlib.util.module_from_spec(spec)
assert spec and spec.loader
sys.modules[spec.name] = engine
spec.loader.exec_module(engine)

REPORT = ROOT / "reports" / "full-regression-report.txt"
lines: list[str] = []

def log(message: str = "") -> None:
    print(message)
    lines.append(message)

def combined(lab_id: str, work: pathlib.Path):
    technical = engine.VALIDATORS[lab_id](work)
    docs = engine.documentation_checks(work)
    return technical, docs

if engine.WORKSPACES.exists():
    shutil.rmtree(engine.WORKSPACES)
engine.WORKSPACES.mkdir(parents=True)

log("The DevOps Incident Lab — Full Sandbox Regression")
log(f"UTC: {datetime.now(timezone.utc).isoformat()}")
log()
completed = 0
for n in range(1, 41):
    lab_id = f"{n:03d}"
    lab = engine.resolve_lab(lab_id)
    work = engine.workspace(lab_id)

    # Broken state
    engine.copy_tree_contents(lab / "broken-environment", work)
    shutil.copy2(lab / "templates" / "INCIDENT-NOTES.md", work / "INCIDENT-NOTES.md")
    broken, broken_docs = combined(lab_id, work)
    assert not broken.healthy, f"{lab_id}: broken state unexpectedly healthy"
    assert not all(ok for ok, _ in broken_docs), f"{lab_id}: incomplete notes unexpectedly passed"

    # Partial state
    engine.copy_tree_contents(lab / "partial-environment", work)
    partial = engine.VALIDATORS[lab_id](work)
    assert not partial.healthy, f"{lab_id}: partial remediation unexpectedly healthy"

    # Complete reference state
    engine.copy_tree_contents(lab / "solution" / "fixed-environment", work)
    shutil.copy2(lab / "solution" / "REFERENCE-NOTES.md", work / "INCIDENT-NOTES.md")
    fixed, fixed_docs = combined(lab_id, work)
    assert fixed.healthy, f"{lab_id}: fixed environment failed: {[x for x in fixed.checks if not x[0]]}"
    assert all(ok for ok, _ in fixed_docs), f"{lab_id}: reference documentation failed"

    # Reset state
    shutil.rmtree(work)
    engine.copy_tree_contents(lab / "broken-environment", work)
    shutil.copy2(lab / "templates" / "INCIDENT-NOTES.md", work / "INCIDENT-NOTES.md")
    reset = engine.VALIDATORS[lab_id](work)
    assert not reset.healthy, f"{lab_id}: reset did not reproduce failure"
    shutil.rmtree(work)

    meta = engine.load_json(lab / "metadata.json")
    log(
        f"PASS {lab_id} | broken={broken.phase} | partial={partial.phase} | "
        f"fixed={fixed.phase} | technical_gates={fixed.passed} | documentation_gates=3 | {meta['title']}"
    )
    completed += 1

log()
log("FULL REGRESSION: PASS")
log(f"{completed} incidents passed broken → partial → complete → documented → reset lifecycle testing.")
REPORT.write_text("\n".join(lines) + "\n", encoding="utf-8")
