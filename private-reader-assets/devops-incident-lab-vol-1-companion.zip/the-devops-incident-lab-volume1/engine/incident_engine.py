#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import pathlib
import re
import shutil
import sys
from dataclasses import dataclass
from typing import Any, Callable

ROOT = pathlib.Path(__file__).resolve().parents[1]
LABS = ROOT / "labs"
WORKSPACES = ROOT / ".workspaces"


@dataclass
class Result:
    checks: list[tuple[bool, str]]
    phase: str
    summary: str

    @property
    def passed(self) -> int:
        return sum(1 for ok, _ in self.checks if ok)

    @property
    def failed(self) -> int:
        return sum(1 for ok, _ in self.checks if not ok)

    @property
    def healthy(self) -> bool:
        return self.failed == 0


def load_json(path: pathlib.Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise ValueError(f"missing required file: {path.name}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"{path.name} is not valid JSON-compatible YAML/JSON: {exc}") from exc


def text(path: pathlib.Path) -> str:
    try:
        return path.read_text(encoding="utf-8")
    except FileNotFoundError as exc:
        raise ValueError(f"missing required file: {path.name}") from exc


def dig(obj: Any, *keys: Any, default: Any = None) -> Any:
    cur = obj
    for key in keys:
        try:
            if isinstance(key, int):
                cur = cur[key]
            else:
                cur = cur[key]
        except (KeyError, IndexError, TypeError):
            return default
    return cur


def check(condition: Any, label: str) -> tuple[bool, str]:
    return bool(condition), label


def manifest_container(deployment: dict[str, Any]) -> dict[str, Any]:
    return dig(deployment, "spec", "template", "spec", "containers", 0, default={}) or {}


def env_map(container: dict[str, Any]) -> dict[str, Any]:
    return {str(item.get("name")): item for item in container.get("env", []) if isinstance(item, dict)}


def validate_001(w: pathlib.Path) -> Result:
    d = load_json(w / "deployment.yaml")
    s = load_json(w / "service.yaml")
    c = manifest_container(d)
    labels = dig(d, "spec", "template", "metadata", "labels", default={}) or {}
    selector = dig(s, "spec", "selector", default={}) or {}
    ports = c.get("ports", [])
    probe = c.get("readinessProbe", {})
    service_port = dig(s, "spec", "ports", 0, default={}) or {}
    checks = [
        check(dig(d, "spec", "replicas") == 2, "Deployment preserves two replicas"),
        check(dig(probe, "httpGet", "path") == "/ready", "Readiness probe checks /ready"),
        check(dig(probe, "httpGet", "port") == "http", "Readiness probe targets the named application port"),
        check(any(p.get("name") == "http" and p.get("containerPort") == 8080 for p in ports), "Container exposes named port http:8080"),
        check(service_port.get("targetPort") in ("http", 8080), "Service targets the application port"),
        check(dig(s, "spec", "type") == "ClusterIP", "Service remains internal ClusterIP"),
        check(selector == {"app": "storefront"}, "Service selector is precise"),
        check(labels.get("app") == "storefront", "Pod labels match the Service selector"),
        check(dig(c, "resources", "limits", "memory") is not None, "Container retains a memory limit"),
    ]
    if dig(probe, "httpGet", "path") != "/ready":
        phase, summary = "RunningNotReady", "Pods run, but the readiness endpoint returns 404."
    elif service_port.get("targetPort") not in ("http", 8080):
        phase, summary = "ReadyButUnreachable", "Pods are ready, but Service traffic is routed to the wrong port."
    else:
        phase, summary = "Healthy", "The rollout is ready and user traffic reaches both replicas."
    return Result(checks, phase, summary)


def validate_002(w: pathlib.Path) -> Result:
    runtime = load_json(w / "runtime-config.yaml")
    content = load_json(w / "content-config.yaml")
    d = load_json(w / "deployment.yaml")
    s = load_json(w / "service.yaml")
    c = manifest_container(d)
    app_env = dig(runtime, "data", "APP_ENV")
    healthz = dig(content, "data", "healthz")
    checks = [
        check(app_env == "production", "Runtime uses the accepted APP_ENV value"),
        check(bool(healthz), "The liveness resource exists"),
        check(dig(c, "livenessProbe", "httpGet", "path") == "/healthz", "Liveness probe checks /healthz"),
        check(dig(c, "readinessProbe", "httpGet", "path") == "/ready", "Readiness probe checks /ready"),
        check(dig(c, "securityContext", "runAsNonRoot") is True, "Container remains non-root"),
        check(dig(c, "securityContext", "runAsUser") == 10001, "Container runs as UID 10001"),
        check(dig(c, "resources", "requests", "cpu") is not None, "Resource requests are retained"),
        check(dig(c, "resources", "limits", "memory") is not None, "Resource limits are retained"),
        check(dig(s, "spec", "type") == "ClusterIP", "Service remains internal"),
    ]
    if app_env != "production":
        phase, summary = "CrashLoopBackOff", f"The process exits with code 42 because APP_ENV={app_env!r}."
    elif not healthz:
        phase, summary = "RunningButRestarting", "The application starts, but kubelet restarts it when /healthz returns 404."
    else:
        phase, summary = "Healthy", "Startup, liveness, readiness, and security contracts are satisfied."
    return Result(checks, phase, summary)


def parse_moves(body: str) -> set[tuple[str, str]]:
    pattern = re.compile(r'moved\s*\{\s*from\s*=\s*([^\s]+)\s*to\s*=\s*([^\s]+)\s*\}', re.S)
    return set(pattern.findall(body))


def validate_003(w: pathlib.Path) -> Result:
    body = text(w / "migration.tf")
    expected = {
        ('terraform_data.database["prod"]', 'terraform_data.database["production"]'),
        ('terraform_data.gateway["prod"]', 'terraform_data.gateway["production"]'),
    }
    moves = parse_moves(body)
    missing = expected - moves
    destroys = len(missing)
    checks = [
        check(expected.issubset(moves), "Both for_each address migrations are declared"),
        check('terraform_data.database["prod"]' in body, "Database source address is exact"),
        check('terraform_data.gateway["prod"]' in body, "Gateway source address is exact"),
        check('terraform_data.database["production"]' in body, "Database destination address is exact"),
        check('terraform_data.gateway["production"]' in body, "Gateway destination address is exact"),
        check(destroys == 0, "Simulated plan contains no destroy actions"),
        check(destroys == 0, "Existing object identities are preserved"),
    ]
    if destroys:
        phase, summary = "DestructivePlan", f"Plan proposes {destroys} replacement(s) because state addresses were not fully migrated."
    else:
        phase, summary = "SafeMigration", "The refactor is represented as two in-place state address moves."
    return Result(checks, phase, summary)


def validate_004(w: pathlib.Path) -> Result:
    es = load_json(w / "external-secret.yaml")
    d = load_json(w / "deployment.yaml")
    c = manifest_container(d)
    env = env_map(c)
    target_data = dig(es, "spec", "target", "template", "data", default={}) or {}
    checks = [
        check(dig(es, "spec", "secretStoreRef", "name") == "vault-prod", "ExternalSecret uses the governed production store"),
        check(dig(es, "spec", "target", "name") == "db-credentials", "ExternalSecret writes the expected Secret name"),
        check("DB_PASSWORD" in target_data, "Rendered Secret contains DB_PASSWORD"),
        check("DATABASE_PASSWORD" not in target_data, "No conflicting password key is rendered"),
        check(dig(env, "DB_PASSWORD", "valueFrom", "secretKeyRef", "name") == "db-credentials", "Deployment references the generated Secret"),
        check(dig(env, "DB_PASSWORD", "valueFrom", "secretKeyRef", "key") == "DB_PASSWORD", "Deployment and Secret key contracts match"),
        check("password" not in json.dumps(d).lower().replace("db_password", ""), "No plaintext password is embedded in the Deployment"),
        check(dig(es, "spec", "refreshInterval") in ("1h", "60m"), "Secret refresh is enabled"),
    ]
    if dig(es, "spec", "secretStoreRef", "name") != "vault-prod":
        phase, summary = "SecretStoreError", "The controller cannot resolve the referenced production secret store."
    elif "DB_PASSWORD" not in target_data:
        phase, summary = "CreateContainerConfigError", "The Secret syncs, but the pod requests a key that does not exist."
    else:
        phase, summary = "Healthy", "The external secret is synchronized and consumed through a matching key contract."
    return Result(checks, phase, summary)


def validate_005(w: pathlib.Path) -> Result:
    artifact = load_json(w / "artifact.json")
    flow = load_json(w / "workflow.yaml")
    d = load_json(w / "deployment.yaml")
    image = dig(manifest_container(d), "image")
    digest = artifact.get("release_digest")
    checks = [
        check(isinstance(digest, str) and digest.startswith("sha256:"), "Build produces an immutable release digest"),
        check(flow.get("publish_reference") == digest, "Pipeline publishes the exact digest"),
        check(flow.get("deploy_reference") == digest, "Deployment stage consumes the exact digest"),
        check(flow.get("verify_deployed_digest") is True, "Pipeline verifies the running digest"),
        check(isinstance(image, str) and f"@{digest}" in image, "Kubernetes Deployment is pinned to the release digest"),
        check(":latest" not in str(image), "Mutable latest tag is not deployed"),
        check(flow.get("smoke_test") is True, "A user-facing smoke test gates success"),
        check(flow.get("record_release_metadata") is True, "Release provenance is recorded"),
    ]
    if flow.get("publish_reference") == "latest":
        phase, summary = "GreenPipelineStaleRelease", "The build is green, but the mutable tag does not prove which image was deployed."
    elif f"@{digest}" not in str(image):
        phase, summary = "DigestMismatch", "The pipeline produced a digest that the Deployment did not consume."
    else:
        phase, summary = "Healthy", "Build, deployment, verification, and release evidence agree on one immutable artifact."
    return Result(checks, phase, summary)


def validate_006(w: pathlib.Path) -> Result:
    mirror = load_json(w / "mirror.json")
    flow = load_json(w / "workflow.yaml")
    app = load_json(w / "argocd-application.yaml")
    source = mirror.get("source_sha")
    checks = [
        check(flow.get("wait_for_mirror") is True, "Deployment waits for mirror synchronization"),
        check(flow.get("compare_source_and_mirror_sha") is True, "Pipeline compares source and mirror SHAs"),
        check(flow.get("deploy_revision") == source, "Pipeline deploys the source commit SHA"),
        check(dig(app, "spec", "source", "targetRevision") == source, "Argo CD is pinned to the exact commit"),
        check(flow.get("timeout_seconds", 0) >= 120, "Mirror wait has a bounded timeout"),
        check(flow.get("fail_on_mismatch") is True, "SHA mismatch fails the release"),
        check(flow.get("post_release_sha") is True, "Release evidence records the deployed SHA"),
    ]
    if not flow.get("wait_for_mirror"):
        phase, summary = "MirrorRace", "Deployment starts before the GitHub mirror contains the source commit."
    elif flow.get("deploy_revision") != source:
        phase, summary = "StaleRevision", "The release still follows a moving branch instead of the intended commit."
    else:
        phase, summary = "Healthy", "Source, mirror, Argo CD, and release evidence converge on one SHA."
    return Result(checks, phase, summary)


def validate_007(w: pathlib.Path) -> Result:
    history = load_json(w / "release-history.json")
    flow = load_json(w / "pipeline.yaml")
    deploy = load_json(w / "deployment.yaml")
    current = history.get("current_digest")
    previous = history.get("previous_digest")
    image = dig(manifest_container(deploy), "image")
    checks = [
        check(flow.get("retain_previous_digest") is True, "Release process retains the previous digest"),
        check(flow.get("rollback_reference") == previous, "Rollback targets the previous immutable digest"),
        check(flow.get("rollback_smoke_test") is True, "Rollback includes a user-facing smoke test"),
        check(flow.get("rollback_timeout_seconds", 0) <= 300, "Rollback has a bounded completion timeout"),
        check(isinstance(image, str) and f"@{current}" in image, "Current Deployment is digest-pinned"),
        check(":stable" not in str(image), "Mutable stable tag is not used"),
        check(flow.get("record_rollback_evidence") is True, "Rollback evidence is persisted"),
        check(current != previous, "Current and rollback artifacts are distinct"),
    ]
    if not flow.get("retain_previous_digest"):
        phase, summary = "RollbackTargetUnknown", "The release replaced the only mutable tag and lost the prior artifact identity."
    elif flow.get("rollback_reference") != previous:
        phase, summary = "UnsafeRollback", "The rollback command still points at a mutable or incorrect reference."
    else:
        phase, summary = "Healthy", "The release has a tested, bounded rollback path to a known prior digest."
    return Result(checks, phase, summary)


def validate_008(w: pathlib.Path) -> Result:
    observed = load_json(w / "observed-state.json")
    desired = load_json(w / "desired-state.json")
    rem = load_json(w / "remediation.json")
    checks = [
        check(rem.get("import_orphaned_resource") is True, "Orphaned resource is adopted into state"),
        check(rem.get("reconcile_drift") is True, "Out-of-band drift is reconciled"),
        check(rem.get("allow_replacement") is False, "Production replacement is explicitly prohibited"),
        check(rem.get("preserve_resource_ids") is True, "Existing resource identities are preserved"),
        check(rem.get("security_group_cidr") == desired.get("security_group_cidr"), "Security group is restored to the approved CIDR"),
        check(rem.get("state_locking") is True, "State locking is required during recovery"),
        check(rem.get("refresh_only_plan_first") is True, "Recovery begins with a refresh-only assessment"),
        check(rem.get("post_apply_empty_plan") is True, "An empty post-apply plan is required"),
        check(observed.get("instance_id") == desired.get("instance_id"), "The observed production instance is preserved"),
    ]
    if not rem.get("import_orphaned_resource"):
        phase, summary = "UnmanagedResource", "A partially created production object exists outside Terraform state."
    elif rem.get("allow_replacement"):
        phase, summary = "DestructiveRecovery", "The proposed recovery would replace a production resource unnecessarily."
    else:
        phase, summary = "Healthy", "Drift and partial apply are reconciled without replacing production identities."
    return Result(checks, phase, summary)


def wildcard(value: str) -> bool:
    return value == "*" or value.endswith(":*") or value.endswith("/*") and value.count(":") < 5


def validate_009(w: pathlib.Path) -> Result:
    p = load_json(w / "policy.json")
    statements = p.get("Statement", [])
    actions = [a for st in statements for a in (st.get("Action") if isinstance(st.get("Action"), list) else [st.get("Action")]) if a]
    resources = [r for st in statements for r in (st.get("Resource") if isinstance(st.get("Resource"), list) else [st.get("Resource")]) if r]
    get_stmt = next((st for st in statements if "s3:GetObject" in (st.get("Action") if isinstance(st.get("Action"), list) else [st.get("Action")])), {})
    kms_stmt = next((st for st in statements if "kms:Decrypt" in (st.get("Action") if isinstance(st.get("Action"), list) else [st.get("Action")])), {})
    checks = [
        check("s3:GetObject" in actions, "Policy grants the required s3:GetObject action"),
        check("kms:Decrypt" in actions, "Policy grants the required kms:Decrypt action"),
        check(not any(wildcard(str(a)) for a in actions), "Policy contains no wildcard actions"),
        check(not any(str(r) == "*" for r in resources), "Policy contains no global resource wildcard"),
        check(str(get_stmt.get("Resource", "")).startswith("arn:aws:s3:::prod-artifacts/releases/"), "S3 access is restricted to the release prefix"),
        check(str(kms_stmt.get("Resource", "")).startswith("arn:aws:kms:us-east-1:123456789012:key/"), "KMS access is restricted to one key"),
        check(bool(kms_stmt.get("Condition")), "KMS decrypt is constrained by encryption context"),
        check(all(st.get("Effect") == "Allow" for st in statements), "Statements use explicit least-privilege allows"),
    ]
    if "s3:GetObject" not in actions:
        phase, summary = "AccessDenied", "The deployment role cannot read the release artifact."
    elif "kms:Decrypt" not in actions:
        phase, summary = "DecryptDenied", "Object access is repaired, but the role still cannot decrypt the release artifact."
    elif any(wildcard(str(a)) for a in actions) or "*" in resources:
        phase, summary = "OverPrivileged", "The incident is masked by a dangerous wildcard policy."
    elif any(not ok for ok, _ in checks):
        phase, summary = "PolicyStillUnsafe", "The policy grants access, but at least one least-privilege constraint remains unsafe."
    else:
        phase, summary = "Healthy", "The deployment can retrieve and decrypt only the approved release artifact."
    return Result(checks, phase, summary)


def validate_010(w: pathlib.Path) -> Result:
    tf = text(w / "main.tf")
    state = load_json(w / "state.json")
    all_text = tf + json.dumps(state)
    secret_patterns = [r"SuperSecret", r'(?i)password\s*=\s*"[^$]', r'(?i)db_password"\s*:\s*"(?!<external>)']
    leaks = [p for p in secret_patterns if re.search(p, all_text)]
    checks = [
        check(not leaks, "No secret value is present in configuration or state"),
        check("secret_arn" in tf, "Terraform stores only an external secret reference"),
        check("aws_secretsmanager_secret" in tf or "external_secret_reference" in tf, "Configuration models an external secret object"),
        check("sensitive = true" in tf, "Secret reference input is marked sensitive"),
        check("db_password" not in json.dumps(state).lower(), "State contains no database password field"),
        check(str(dig(state, "resources", 0, "values", "secret_arn", default="")).startswith("arn:"), "State contains only the governed secret ARN"),
        check("nonsensitive(" not in tf, "Configuration does not deliberately declassify secret data"),
        check("output \"db_password\"" not in tf, "No secret-valued output is declared"),
    ]
    if leaks:
        phase, summary = "SecretExposure", "A database credential remains recoverable from Terraform configuration or state."
    else:
        phase, summary = "Healthy", "Terraform tracks only a governed secret reference; the value remains outside state."
    return Result(checks, phase, summary)


def latency_estimate(cfg: dict[str, Any]) -> int:
    pool = max(int(cfg.get("db_pool_size", 1)), 1)
    retries = int(cfg.get("max_retries", 0))
    queue = int(cfg.get("queue_limit", 0))
    timeout = int(cfg.get("request_timeout_ms", 5000))
    return min(timeout, int(5200 / pool * 5 + retries * 180 + queue * 0.8))


def validate_011(w: pathlib.Path) -> Result:
    cfg = load_json(w / "service-config.yaml")
    p95 = latency_estimate(cfg)
    checks = [
        check(20 <= cfg.get("db_pool_size", 0) <= 50, "Database pool is sized for measured concurrency"),
        check(cfg.get("max_retries") <= 1, "Retries are bounded to avoid amplification"),
        check(cfg.get("retry_backoff") == "exponential-jitter", "Retries use exponential backoff with jitter"),
        check(cfg.get("request_timeout_ms") <= 1000, "Request timeout fails fast"),
        check(cfg.get("queue_limit") <= 200, "Queue length is bounded"),
        check(cfg.get("trace_sampling") is True, "Distributed tracing remains enabled"),
        check(cfg.get("db_timeout_ms") < cfg.get("request_timeout_ms"), "Database timeout is below the request deadline"),
        check(p95 < 1000, f"Simulated p95 latency is below 1000 ms (calculated {p95} ms)"),
    ]
    if p95 >= 1000:
        phase, summary = "LatencySLOViolation", f"CPU appears normal, but queueing and retry amplification drive p95 to {p95} ms."
    else:
        phase, summary = "Healthy", f"Backpressure, pool sizing, and deadlines reduce simulated p95 to {p95} ms."
    return Result(checks, phase, summary)


def validate_012(w: pathlib.Path) -> Result:
    cfg = load_json(w / "resilience.yaml")
    amplification = (1 + int(cfg.get("max_retries", 0))) * (100 / max(int(cfg.get("bulkhead_concurrency", 1)), 1))
    checks = [
        check(cfg.get("max_retries") <= 1, "Dependency retries are bounded"),
        check(cfg.get("backoff") == "exponential-jitter", "Retry backoff includes jitter"),
        check(cfg.get("circuit_breaker_enabled") is True, "Circuit breaker is enabled"),
        check(3 <= cfg.get("failure_threshold", 0) <= 10, "Circuit opens after a measured failure threshold"),
        check(10 <= cfg.get("bulkhead_concurrency", 0) <= 30, "A dependency bulkhead limits concurrent pressure"),
        check(cfg.get("timeout_ms") <= 1000, "Dependency timeout is bounded"),
        check(cfg.get("fallback") == "degraded-response", "A controlled degraded response is defined"),
        check(amplification <= 10, f"Simulated dependency amplification is controlled ({amplification:.1f}x)"),
    ]
    if not cfg.get("circuit_breaker_enabled"):
        phase, summary = "CascadingFailure", "Retries continue hammering an unhealthy dependency until upstream pools are exhausted."
    elif amplification > 10:
        phase, summary = "RetryStorm", f"Retry and concurrency settings still amplify dependency load by {amplification:.1f}x."
    else:
        phase, summary = "Healthy", "Bulkheads, bounded retries, deadlines, and a circuit breaker contain the dependency failure."
    return Result(checks, phase, summary)


def validate_013(w: pathlib.Path) -> Result:
    policy = load_json(w / "backup-policy.yaml")
    runbook = load_json(w / "restore-runbook.json")
    test = load_json(w / "restore-test.json")
    checks = [
        check(policy.get("include_database") is True, "Database data is included"),
        check(policy.get("include_secret_metadata") is True, "Secret metadata required for restore is included"),
        check(policy.get("include_encryption_key_reference") is True, "Encryption key reference is captured"),
        check(policy.get("immutable_copy") is True, "An immutable backup copy is retained"),
        check(runbook.get("backup_format_version") == policy.get("format_version"), "Runbook matches the current backup format"),
        check(runbook.get("preflight_key_access") is True, "Restore preflight verifies key access"),
        check(runbook.get("data_integrity_check") is True, "Restore validates data integrity"),
        check(test.get("status") == "passed", "A controlled restore test has passed"),
        check(test.get("rto_minutes", 999) <= 30, "Restore test meets the 30-minute RTO"),
        check(test.get("rpo_minutes", 999) <= 15, "Restore test meets the 15-minute RPO"),
    ]
    if not policy.get("include_encryption_key_reference"):
        phase, summary = "UndecryptableBackup", "Backup data exists, but the restore process cannot resolve its encryption key."
    elif test.get("status") != "passed":
        phase, summary = "UnprovenRecovery", "The backup exists, but no successful restore evidence exists."
    else:
        phase, summary = "Healthy", "Backup completeness and a controlled restore test prove recoverability."
    return Result(checks, phase, summary)


def validate_014(w: pathlib.Path) -> Result:
    cfg = load_json(w / "alerts.yaml")
    alerts = cfg.get("alerts", [])
    paging = [a for a in alerts if a.get("route") == "page"]
    checks = [
        check(set(cfg.get("group_by", [])) >= {"service", "cluster"}, "Alerts group by service and cluster"),
        check(cfg.get("inhibit_downstream_symptoms") is True, "Downstream symptom alerts are inhibited"),
        check(cfg.get("deduplication_window_minutes", 0) >= 10, "Alert deduplication window is configured"),
        check(any(a.get("name") == "slo-fast-burn" and a.get("route") == "page" for a in alerts), "Fast SLO burn pages the on-call engineer"),
        check(any(a.get("name") == "slo-slow-burn" and a.get("route") in ("ticket", "chat") for a in alerts), "Slow SLO burn creates non-page work"),
        check(len(paging) <= 2, f"Incident produces at most two paging alerts (configured {len(paging)})"),
        check(all(a.get("runbook_url") for a in paging), "Every page links to a runbook"),
        check(cfg.get("notification_tested") is True, "Notification routing has been tested"),
    ]
    if len(paging) > 2:
        phase, summary = "AlertStorm", f"One outage generates {len(paging)} pages and hides the causal signal."
    elif not cfg.get("inhibit_downstream_symptoms"):
        phase, summary = "NoisyIncident", "Grouped alerts still repeat downstream symptoms without inhibition."
    else:
        phase, summary = "Healthy", "SLO-based paging, grouping, inhibition, and runbooks produce an actionable signal."
    return Result(checks, phase, summary)


def validate_015(w: pathlib.Path) -> Result:
    ff = load_json(w / "feature-flags.json")
    db = load_json(w / "database.json")
    queue = load_json(w / "queue.yaml")
    plan = load_json(w / "change-plan.json")
    expected_order = ["disable-feature", "apply-backward-compatible-migration", "drain-queue", "deploy-application", "enable-feature", "smoke-test"]
    checks = [
        check(db.get("schema_version") >= 2, "Database schema reaches version 2"),
        check(db.get("migration_complete") is True, "Database migration completed"),
        check(db.get("backward_compatible") is True, "Migration remains compatible during rollout"),
        check(queue.get("max_in_flight") <= 100, "Queue concurrency is reduced during recovery"),
        check(queue.get("dead_letter_enabled") is True, "Failed messages are retained in a dead-letter queue"),
        check(plan.get("steps") == expected_order, "Recovery actions follow the safe operational order"),
        check(plan.get("rollback_checkpoint") == "before-enable-feature", "Rollback checkpoint exists before feature activation"),
        check(plan.get("data_loss_tolerance") == "zero", "Recovery explicitly requires zero data loss"),
        check(ff.get("checkout_v2") is True, "Feature is re-enabled only after migration and validation"),
        check(plan.get("smoke_test_passed") is True, "End-to-end checkout smoke test passes"),
    ]
    if db.get("schema_version", 0) < 2 and ff.get("checkout_v2"):
        phase, summary = "SchemaMismatch", "The new application path is serving traffic before the required schema exists."
    elif plan.get("steps") != expected_order:
        phase, summary = "UnsafeRecoveryOrder", "The proposed change order risks message loss or incompatible writes."
    else:
        phase, summary = "Healthy", "Schema, queue, rollout, feature activation, and smoke validation are safely sequenced."
    return Result(checks, phase, summary)


def validate_016(w: pathlib.Path) -> Result:
    att = load_json(w / "attestation.json")
    policy = load_json(w / "admission-policy.yaml")
    flow = load_json(w / "workflow.yaml")
    checks = [
        check(att.get("signed") is True, "Artifact has a valid signature"),
        check(att.get("digest", "").startswith("sha256:"), "Artifact identity is an immutable digest"),
        check(att.get("issuer") == "https://token.actions.githubusercontent.com", "Signature issuer is the approved OIDC provider"),
        check(att.get("subject") == "repo:tayoca/devops-incident-lab:ref:refs/heads/main", "Signature subject matches the approved repository and ref"),
        check(att.get("sbom_attached") is True, "Artifact includes an SBOM attestation"),
        check(att.get("provenance_level") in ("slsa-2", "slsa-3"), "Build provenance meets the required level"),
        check(policy.get("require_signature") is True, "Admission requires a signature"),
        check(policy.get("require_digest") is True, "Admission rejects mutable tags"),
        check(policy.get("trusted_issuers") == [att.get("issuer")], "Admission trusts only the approved issuer"),
        check(flow.get("verify_before_deploy") is True, "Pipeline verifies provenance before deployment"),
    ]
    if not att.get("signed"):
        phase, summary = "UntrustedArtifact", "An unsigned artifact from an unverified builder reached the deployment stage."
    elif not policy.get("require_signature"):
        phase, summary = "PolicyBypass", "The artifact is signed, but the cluster does not enforce verification."
    else:
        phase, summary = "Healthy", "Digest, signature, issuer, subject, SBOM, provenance, and admission policy all agree."
    return Result(checks, phase, summary)


def validate_017(w: pathlib.Path) -> Result:
    policy = load_json(w / "agent-policy.yaml")
    perms = load_json(w / "tool-permissions.json")
    action = load_json(w / "proposed-action.json")
    verbs = perms.get("kubernetes_verbs", [])
    checks = [
        check(policy.get("default_mode") == "read-only", "Agent starts in read-only mode"),
        check(policy.get("human_approval_for_writes") is True, "Every write requires human approval"),
        check(policy.get("minimum_independent_evidence") >= 3, "Remediation requires at least three independent evidence sources"),
        check(policy.get("treat_tool_output_as_untrusted") is True, "Logs and tickets are treated as untrusted input"),
        check(policy.get("rollback_required") is True, "Every write proposal includes a rollback"),
        check("delete" not in verbs, "Agent cannot delete Kubernetes resources"),
        check("*" not in verbs, "Agent has no wildcard Kubernetes verb"),
        check(set(verbs) <= {"get", "list", "watch", "patch"}, "Tool permissions are narrowly bounded"),
        check(action.get("operation") == "patch", "Proposed remediation is a bounded patch"),
        check(bool(action.get("approval_id")), "Approved change identifier is attached"),
        check(bool(action.get("rollback")), "Proposed action contains an executable rollback"),
        check(action.get("namespace") == "payments", "Action is namespace-scoped"),
    ]
    if policy.get("default_mode") != "read-only" or "delete" in verbs or "*" in verbs:
        phase, summary = "UnsafeAutonomy", "The agent can execute destructive remediation from untrusted evidence without sufficient control."
    elif not action.get("approval_id"):
        phase, summary = "ApprovalMissing", "The proposed write is bounded but has not passed the human approval gate."
    else:
        phase, summary = "Healthy", "Read-only investigation, evidence thresholds, approval, bounded permissions, and rollback constrain automation."
    return Result(checks, phase, summary)


def validate_018(w: pathlib.Path) -> Result:
    dr = load_json(w / "dr-plan.yaml")
    runbook = load_json(w / "failover-runbook.json")
    expected = ["declare-incident", "fence-primary", "confirm-replication-lag", "promote-replica", "switch-dns", "run-smoke-tests", "observe", "prepare-failback"]
    checks = [
        check(dr.get("dns_ttl_seconds") <= 60, "DNS TTL supports the recovery objective"),
        check(dr.get("maximum_replication_lag_minutes") <= 5, "Replication lag meets the five-minute RPO"),
        check(dr.get("primary_fencing_required") is True, "Primary fencing prevents split brain"),
        check(dr.get("promotion_requires_approval") is True, "Replica promotion requires controlled approval"),
        check(dr.get("cross_region_backup_verified") is True, "Cross-region backup has been verified"),
        check(dr.get("projected_rto_minutes") <= 15, "Projected RTO is at most 15 minutes"),
        check(dr.get("projected_rpo_minutes") <= 5, "Projected RPO is at most five minutes"),
        check(runbook.get("steps") == expected, "Failover steps follow the safe operational sequence"),
        check(runbook.get("smoke_tests") == ["write", "read", "queue", "payment-callback"], "Failover validates critical user journeys"),
        check(runbook.get("failback_plan") is True, "Runbook includes a controlled failback plan"),
        check(runbook.get("evidence_capture") is True, "Every recovery stage records evidence"),
        check(runbook.get("exercise_status") == "passed", "A full disaster-recovery exercise has passed"),
    ]
    if dr.get("maximum_replication_lag_minutes", 999) > 5:
        phase, summary = "RPOBreach", "The replica is too far behind to meet the declared data-loss objective."
    elif not dr.get("primary_fencing_required"):
        phase, summary = "SplitBrainRisk", "Promotion can occur without fencing the former primary."
    elif runbook.get("exercise_status") != "passed":
        phase, summary = "UnprovenDR", "The plan is documented but has not passed a controlled exercise."
    else:
        phase, summary = "Healthy", "The failover sequence meets RTO/RPO, prevents split brain, validates service, and plans failback."
    return Result(checks, phase, summary)


def validate_019(w: pathlib.Path) -> Result:
    v = load_json(w / "helm-values.yaml")
    r = load_json(w / "release.json")
    checks = [
        check(r.get("atomic") is True, "Helm release is atomic"),
        check(r.get("wait") is True, "Helm waits for workload readiness"),
        check(180 <= r.get("timeout_seconds", 0) <= 600, "Release timeout is bounded and realistic"),
        check(r.get("rollback_on_failure") is True, "Failed upgrade automatically rolls back"),
        check(r.get("pre_upgrade_backup") is True, "Stateful upgrade takes a pre-change backup"),
        check(r.get("hook_delete_policy") == "before-hook-creation,hook-succeeded", "Hooks are cleaned deterministically"),
        check("@sha256:" in v.get("image", ""), "Chart deploys an immutable image digest"),
        check(v.get("readiness_gate") is True, "Chart retains a readiness gate"),
    ]
    if not r.get("atomic"):
        phase, summary = "PartialHelmRelease", "The upgrade can leave a mixture of old and new resources after a hook failure."
    elif not r.get("pre_upgrade_backup"):
        phase, summary = "RollbackWithoutDataSafety", "Workload rollback exists, but stateful data has no pre-change recovery point."
    else:
        phase, summary = "Healthy", "The Helm upgrade is immutable, readiness-gated, atomic, backed up, and rollback-capable."
    return Result(checks, phase, summary)


def validate_020(w: pathlib.Path) -> Result:
    c = load_json(w / "storage-recovery.json")
    checks = [
        check(c.get("access_mode") == "ReadWriteOnce", "Volume access mode remains ReadWriteOnce"),
        check(c.get("old_node_fenced") is True, "The former node is fenced before reattachment"),
        check(c.get("detach_confirmed") is True, "Controller detach is confirmed"),
        check(c.get("force_detach") is False, "Unsafe force detach is not used"),
        check(c.get("backup_verified") is True, "Recent backup is verified before storage surgery"),
        check(c.get("filesystem_check") is True, "Filesystem integrity is checked after attachment"),
        check(c.get("pod_rescheduled_after_attach") is True, "Pod starts only after volume attachment succeeds"),
        check(c.get("data_smoke_test") is True, "Recovered data path passes a smoke test"),
    ]
    if not c.get("old_node_fenced"):
        phase, summary = "MultiAttachRisk", "The volume cannot be safely attached while the former node may still write."
    elif c.get("force_detach"):
        phase, summary = "DataCorruptionRisk", "Force detach bypasses proof that the old writer is gone."
    elif any(not ok for ok, _ in checks):
        phase, summary = "RecoveryUnproven", "Attachment controls improve, but integrity or application data validation is incomplete."
    else:
        phase, summary = "Healthy", "Fencing, controlled detach, integrity checks, and data validation restore the volume safely."
    return Result(checks, phase, summary)


def validate_021(w: pathlib.Path) -> Result:
    h = load_json(w / "hpa.yaml")
    d = load_json(w / "deployment.yaml")
    c = manifest_container(d)
    checks = [
        check(dig(c, "resources", "requests", "cpu") is not None, "CPU request exists for utilization-based scaling"),
        check(h.get("minReplicas") == 2, "HPA preserves two minimum replicas"),
        check(h.get("maxReplicas", 0) >= 8, "HPA can scale beyond the baseline"),
        check(50 <= h.get("targetCPUUtilizationPercentage", 0) <= 70, "CPU target provides useful headroom"),
        check(h.get("scaleUpStabilizationSeconds", 999) <= 60, "Scale-up reacts within one minute"),
        check(h.get("scaleDownStabilizationSeconds", 0) >= 300, "Scale-down avoids flapping"),
        check(h.get("load_test_verified") is True, "Scaling behavior passed a controlled load test"),
        check(dig(d, "spec", "replicas") == 2, "Deployment baseline aligns with HPA minimum"),
    ]
    if dig(c, "resources", "requests", "cpu") is None:
        phase, summary = "MetricsUnavailable", "CPU utilization cannot be calculated because the pod has no CPU request."
    elif h.get("maxReplicas", 0) <= h.get("minReplicas", 0):
        phase, summary = "ScalingCapped", "Metrics work, but the HPA is configured with no scaling range."
    else:
        phase, summary = "Healthy", "Resource requests, scaling range, stabilization, and load evidence prove autoscaling."
    return Result(checks, phase, summary)


def validate_022(w: pathlib.Path) -> Result:
    n = load_json(w / "network-policy.yaml")
    checks = [
        check(n.get("default_deny") is True, "Namespace retains default-deny egress"),
        check(n.get("allow_dns_udp_53") is True, "UDP DNS egress is allowed"),
        check(n.get("allow_dns_tcp_53") is True, "TCP DNS fallback is allowed"),
        check(n.get("dns_namespace_selector") == "kubernetes.io/metadata.name=kube-system", "DNS allowance is namespace-scoped"),
        check(n.get("dns_pod_selector") == "k8s-app=kube-dns", "DNS allowance targets cluster DNS pods"),
        check(n.get("allow_dependency_port") == 443, "Application dependency is limited to HTTPS"),
        check(n.get("allow_all_egress") is False, "No allow-all egress shortcut exists"),
        check(n.get("dns_and_dependency_tested") is True, "DNS and dependency connectivity were tested"),
    ]
    if not n.get("allow_dns_udp_53"):
        phase, summary = "DNSBlocked", "The pod cannot resolve its dependency because egress policy omitted cluster DNS."
    elif n.get("allow_all_egress"):
        phase, summary = "PolicyBypassed", "Connectivity is restored by disabling meaningful egress isolation."
    elif any(not ok for ok, _ in checks):
        phase, summary = "ConnectivityUnproven", "DNS rules improve, but scoping or end-to-end connectivity evidence is incomplete."
    else:
        phase, summary = "Healthy", "The policy allows only cluster DNS and the required HTTPS dependency."
    return Result(checks, phase, summary)


def validate_023(w: pathlib.Path) -> Result:
    g = load_json(w / "gitops-state.json")
    checks = [
        check(g.get("hotfix_committed") is True, "Emergency change is represented in Git"),
        check(g.get("desired_sha") == g.get("cluster_sha"), "Git and cluster converge on the same revision"),
        check(g.get("self_heal") is True, "GitOps self-healing is enabled"),
        check(g.get("drift_detection") is True, "Drift detection is active"),
        check(g.get("direct_kubectl_changes_allowed") is False, "Direct unmanaged production changes are prohibited"),
        check(g.get("prune_requires_approval") is True, "Destructive pruning requires approval"),
        check(g.get("emergency_change_record") is True, "Emergency change has a governed record"),
        check(g.get("post_sync_smoke_test") is True, "Reconciliation is followed by a smoke test"),
    ]
    if not g.get("hotfix_committed"):
        phase, summary = "UnmanagedHotfix", "The cluster contains a production fix that Git will later overwrite."
    elif g.get("desired_sha") != g.get("cluster_sha"):
        phase, summary = "DriftRemaining", "The hotfix is committed, but Git and cluster still reference different revisions."
    elif any(not ok for ok, _ in checks):
        phase, summary = "GovernanceIncomplete", "Git and cluster converge, but drift, approval, or verification controls remain incomplete."
    else:
        phase, summary = "Healthy", "The emergency fix is governed, reconciled, self-healing, and tested."
    return Result(checks, phase, summary)


def validate_024(w: pathlib.Path) -> Result:
    c = load_json(w / "oidc-workflow.yaml")
    checks = [
        check(c.get("use_oidc") is True, "Workflow uses short-lived OIDC credentials"),
        check(c.get("static_credentials_fallback") is False, "No static cloud credential fallback exists"),
        check(c.get("id_token_permission") == "write", "Workflow can request an OIDC token"),
        check(c.get("contents_permission") == "read", "Repository permission is read-only"),
        check(c.get("audience") == "sts.amazonaws.com", "OIDC audience matches AWS STS"),
        check(c.get("role_arn") == "arn:aws:iam::123456789012:role/prod-deployer", "Workflow assumes only the governed deploy role"),
        check(c.get("session_duration_seconds", 99999) <= 3600, "Cloud session is short-lived"),
        check(c.get("subject_restriction") == "repo:tayoca/platform:ref:refs/heads/main", "Trust policy restricts repository and branch"),
    ]
    if not c.get("use_oidc"):
        phase, summary = "ExpiredCredential", "The release depends on a long-lived credential that has expired."
    elif c.get("static_credentials_fallback"):
        phase, summary = "SecretFallbackRisk", "OIDC works, but the workflow can silently fall back to static credentials."
    elif any(not ok for ok, _ in checks):
        phase, summary = "IdentityMisbound", "OIDC is enabled, but audience, role, session, or subject restrictions remain unsafe."
    else:
        phase, summary = "Healthy", "The workflow uses a short-lived, repository-bound deployment identity."
    return Result(checks, phase, summary)


def validate_025(w: pathlib.Path) -> Result:
    c = load_json(w / "vulnerability-policy.yaml")
    checks = [
        check(set(c.get("fail_severities", [])) == {"HIGH", "CRITICAL"}, "High and critical findings fail the release"),
        check(c.get("fail_closed") is True, "Scanner failure blocks deployment"),
        check(c.get("database_max_age_hours", 999) <= 24, "Vulnerability database is fresh"),
        check(c.get("exceptions_require_owner") is True, "Every exception has an accountable owner"),
        check(c.get("exceptions_require_expiry") is True, "Every exception expires"),
        check(c.get("exceptions_require_ticket") is True, "Every exception links to tracked remediation"),
        check(c.get("ignore_unfixed") is False, "Unfixed critical risk remains visible"),
        check(c.get("scan_digest_not_tag") is True, "The exact release digest is scanned"),
    ]
    if "HIGH" not in c.get("fail_severities", []):
        phase, summary = "GateTooWeak", "Known high-severity vulnerabilities can pass the release gate."
    elif not c.get("exceptions_require_expiry"):
        phase, summary = "PermanentException", "A vulnerability exception can become an ungoverned permanent bypass."
    else:
        phase, summary = "Healthy", "Fresh digest scanning and governed exceptions enforce the release risk policy."
    return Result(checks, phase, summary)


def validate_026(w: pathlib.Path) -> Result:
    c = load_json(w / "cdn-release.yaml")
    checks = [
        check(c.get("html_cache_control") == "no-cache", "HTML is revalidated on every request"),
        check(c.get("asset_cache_control") == "public,max-age=31536000,immutable", "Hashed assets use immutable caching"),
        check(c.get("invalidate_paths") == ["/", "/index.html"], "Release invalidates only mutable entry points"),
        check(c.get("origin_checksum_verified") is True, "Uploaded origin content checksum is verified"),
        check(c.get("cdn_checksum_verified") is True, "CDN response checksum is verified"),
        check(c.get("wait_for_invalidation") is True, "Pipeline waits for invalidation completion"),
        check(c.get("smoke_test_from_cdn") is True, "Smoke test runs through the CDN"),
        check(c.get("release_id_header") is True, "Response exposes a release identity header"),
    ]
    if c.get("html_cache_control") != "no-cache":
        phase, summary = "StaleEntryPoint", "The CDN serves an old HTML entry point that references obsolete assets."
    elif not c.get("cdn_checksum_verified"):
        phase, summary = "UnprovenInvalidation", "The pipeline requested invalidation but never proved edge content changed."
    else:
        phase, summary = "Healthy", "Entry points revalidate, assets remain immutable, and edge content is verified."
    return Result(checks, phase, summary)


def validate_027(w: pathlib.Path) -> Result:
    c = load_json(w / "cache-policy.yaml")
    checks = [
        check(c.get("key_includes_lock_hash") is True, "Cache key includes the dependency lock hash"),
        check(c.get("key_includes_runtime_version") is True, "Cache key includes runtime/toolchain version"),
        check(c.get("restore_keys_are_bounded") is True, "Fallback restore keys cannot cross incompatible builds"),
        check(c.get("install_command") == "npm ci", "Dependencies install exactly from the lockfile"),
        check(c.get("lockfile_integrity_check") is True, "Pipeline verifies lockfile integrity"),
        check(c.get("clean_on_cache_mismatch") is True, "Mismatched cache is discarded"),
        check(c.get("cache_hit_reported") is True, "Build evidence records cache use"),
        check(c.get("post_install_dependency_hash") is True, "Installed dependency tree is hashed"),
    ]
    if not c.get("key_includes_lock_hash"):
        phase, summary = "StaleDependencyCache", "A branch-level cache restores dependencies from an incompatible lockfile."
    elif c.get("install_command") != "npm ci":
        phase, summary = "NonDeterministicInstall", "The cache key is improved, but installation can still rewrite dependency resolution."
    elif any(not ok for ok, _ in checks):
        phase, summary = "CacheEvidenceIncomplete", "Cache identity and install mode improve, but integrity or evidence controls remain incomplete."
    else:
        phase, summary = "Healthy", "Cache identity, deterministic install, and dependency evidence agree."
    return Result(checks, phase, summary)


def validate_028(w: pathlib.Path) -> Result:
    c = load_json(w / "production-gate.yaml")
    checks = [
        check(c.get("all_prod_paths_use_environment") is True, "Every production trigger uses the protected environment"),
        check(c.get("required_reviewers", 0) >= 1, "Production requires at least one reviewer"),
        check(c.get("signed_tag_required") is True, "Release tags must be signed"),
        check(c.get("artifact_digest_required") is True, "Approval references an immutable artifact digest"),
        check(c.get("change_record_required") is True, "Release links to an approved change record"),
        check(c.get("tag_trigger_bypass") is False, "Tag events cannot bypass approval"),
        check(c.get("emergency_path_audited") is True, "Emergency release path is audited"),
        check(c.get("post_deploy_verification") is True, "Approved release still requires post-deploy verification"),
    ]
    if c.get("tag_trigger_bypass"):
        phase, summary = "ApprovalBypass", "A production tag can deploy without entering the protected environment."
    elif not c.get("artifact_digest_required"):
        phase, summary = "AmbiguousApproval", "Reviewers approve a release name without knowing the exact artifact."
    else:
        phase, summary = "Healthy", "Every production path binds reviewer approval to an immutable, governed release."
    return Result(checks, phase, summary)


def validate_029(w: pathlib.Path) -> Result:
    c = load_json(w / "state-lock-recovery.json")
    checks = [
        check(c.get("lock_owner_verified") is True, "Lock owner and operation are identified"),
        check(c.get("owner_process_active") is False, "No active apply owns the lock"),
        check(c.get("lock_age_minutes", 0) >= 30, "Lock is old enough to be considered stale"),
        check(c.get("state_backup_created") is True, "State is backed up before lock recovery"),
        check(c.get("force_unlock_approved") is True, "Exceptional force unlock has explicit approval"),
        check(c.get("lock_id_matches") is True, "Force unlock targets the exact lock ID"),
        check(c.get("lock_timeout_seconds", 0) >= 300, "Future operations wait for normal lock release"),
        check(c.get("post_unlock_refresh_plan") is True, "Recovery runs a refresh plan before changes"),
    ]
    if c.get("owner_process_active"):
        phase, summary = "ActiveStateLock", "Another apply still owns the lock; force unlock could permit concurrent state writes."
    elif not c.get("state_backup_created"):
        phase, summary = "UnsafeUnlock", "The lock appears stale, but state recovery evidence is incomplete."
    elif any(not ok for ok, _ in checks):
        phase, summary = "UnlockControlsIncomplete", "The lock appears stale, but approval, lock identity, timeout, or refresh controls are incomplete."
    else:
        phase, summary = "Healthy", "The stale lock is verified, approved, backed up, precisely removed, and followed by refresh."
    return Result(checks, phase, summary)


def validate_030(w: pathlib.Path) -> Result:
    c = load_json(w / "database-module.yaml")
    checks = [
        check(c.get("publicly_accessible") is False, "Database is not publicly accessible"),
        check(c.get("subnet_class") == "private", "Database uses private subnets"),
        check(c.get("allowed_security_group") == "app-runtime-sg", "Ingress is limited to the application security group"),
        check(c.get("allowed_cidr") is None, "No broad CIDR ingress is configured"),
        check(c.get("storage_encrypted") is True, "Storage encryption is enabled"),
        check(c.get("deletion_protection") is True, "Deletion protection is enabled"),
        check(c.get("backup_retention_days", 0) >= 7, "Backups retain at least seven days"),
        check(c.get("module_validation") is True, "Module rejects unsafe public combinations"),
    ]
    if c.get("publicly_accessible"):
        phase, summary = "PublicDatabase", "Module defaults place the production database on a public network path."
    elif not c.get("module_validation"):
        phase, summary = "UnsafeDefaultPossible", "This instance is private, but the reusable module still permits unsafe combinations."
    else:
        phase, summary = "Healthy", "Network placement, ingress, encryption, protection, backups, and module validation are safe."
    return Result(checks, phase, summary)


def validate_031(w: pathlib.Path) -> Result:
    c = load_json(w / "teardown-plan.json")
    checks = [
        check(c.get("delete_shared_vpc") is False, "Shared VPC is preserved"),
        check(c.get("delete_state_bucket") is False, "Terraform state bucket is preserved"),
        check(c.get("delete_lock_table") is False, "Shared lock table is preserved"),
        check(c.get("delete_only_owned_resources") is True, "Teardown is constrained by ownership"),
        check(c.get("remove_state_prefix_only") == "apps/storefront/", "Only the application state prefix is removed"),
        check(c.get("orphan_scan") is True, "Post-teardown orphan scan is required"),
        check(c.get("dependency_check") is True, "Shared-resource consumers are checked"),
        check(c.get("final_plan_empty") is True, "Final governed plan is empty"),
    ]
    if c.get("delete_shared_vpc") or c.get("delete_state_bucket"):
        phase, summary = "SharedInfrastructureDeletion", "The teardown plan includes shared control-plane resources."
    elif not c.get("orphan_scan"):
        phase, summary = "IncompleteTeardown", "Shared resources are preserved, but disposable resources may remain orphaned."
    else:
        phase, summary = "Healthy", "Teardown deletes only owned resources, preserves shared controls, and proves cleanup."
    return Result(checks, phase, summary)


def validate_032(w: pathlib.Path) -> Result:
    c = load_json(w / "cost-controls.yaml")
    monthly = (c.get("nat_gateways", 0) * 35 + c.get("instance_monthly_cost", 0) + c.get("log_retention_days", 3650) * 0.6 + c.get("idle_environment_hours_month", 720) * 0.8)
    checks = [
        check(c.get("nat_gateways", 99) <= 1, "Non-production uses at most one NAT gateway"),
        check(c.get("vpc_endpoints_for_high_volume_services") is True, "High-volume AWS traffic uses VPC endpoints"),
        check(c.get("log_retention_days", 9999) <= 30, "Default log retention is bounded"),
        check(c.get("right_sized_instance") is True, "Compute is right-sized from utilization evidence"),
        check(c.get("idle_schedule_enabled") is True, "Disposable environments stop outside working hours"),
        check(c.get("budget_alerts") is True, "Budget thresholds notify owners"),
        check(c.get("cost_allocation_tags") is True, "Resources have cost-allocation tags"),
        check(monthly <= 350, f"Estimated monthly cost is within the lab target ({monthly:.0f})"),
    ]
    if monthly > 600:
        phase, summary = "CostRunaway", f"Unbounded retention, idle runtime, and network architecture estimate {monthly:.0f} per month."
    elif not c.get("budget_alerts"):
        phase, summary = "UnobservedCost", "Costs improve, but no governed alert detects regression."
    else:
        phase, summary = "Healthy", f"Architecture, retention, scheduling, sizing, tags, and budgets reduce estimated cost to {monthly:.0f}."
    return Result(checks, phase, summary)


def validate_033(w: pathlib.Path) -> Result:
    c = load_json(w / "slo.yaml")
    checks = [
        check(c.get("availability_indicator") == "successful-checkout-journey", "Availability measures the critical user journey"),
        check(c.get("latency_indicator") == "checkout-p95", "Latency SLI covers checkout performance"),
        check(c.get("exclude_health_endpoint") is True, "Health endpoint is excluded from user availability"),
        check(c.get("success_requires_payment_callback") is True, "Journey success includes the asynchronous callback"),
        check(c.get("target_percent", 0) >= 99.9, "SLO target is explicitly defined"),
        check(c.get("fast_burn_alert") is True, "Fast error-budget burn pages"),
        check(c.get("slow_burn_alert") is True, "Slow burn creates follow-up work"),
        check(c.get("synthetic_journey") is True, "Synthetic critical-journey monitoring exists"),
    ]
    if c.get("availability_indicator") == "health-endpoint-200":
        phase, summary = "FalseHealthySLO", "The SLO is green because it measures a health endpoint while checkout fails."
    elif not c.get("success_requires_payment_callback"):
        phase, summary = "IncompleteJourney", "The SLI measures request acceptance but not business completion."
    elif any(not ok for ok, _ in checks):
        phase, summary = "SLOResponseIncomplete", "The journey is measured, but target, burn-rate, or synthetic controls remain incomplete."
    else:
        phase, summary = "Healthy", "The SLO measures the complete customer journey and drives burn-rate response."
    return Result(checks, phase, summary)


def validate_034(w: pathlib.Path) -> Result:
    c = load_json(w / "handover.json")
    checks = [
        check(len(c.get("unresolved_incidents", [])) >= 1, "Unresolved incident is explicitly handed over"),
        check(len(c.get("known_risks", [])) >= 1, "Known risks are recorded"),
        check(bool(c.get("next_owner")), "A named next owner is assigned"),
        check(bool(c.get("next_check_time")), "Next verification time is explicit"),
        check(len(c.get("evidence_links", [])) >= 2, "Handover links to evidence"),
        check(bool(c.get("rollback_state")), "Current rollback capability is documented"),
        check(bool(c.get("customer_impact")), "Customer impact is summarized"),
        check(c.get("receiver_acknowledged") is True, "Receiving engineer acknowledged the handover"),
    ]
    if not c.get("unresolved_incidents"):
        phase, summary = "RiskDroppedAtHandover", "An unresolved production risk disappears from the shift transition."
    elif not c.get("receiver_acknowledged"):
        phase, summary = "UnconfirmedOwnership", "The handover is written, but no engineer has accepted operational ownership."
    else:
        phase, summary = "Healthy", "Impact, risks, evidence, rollback, ownership, timing, and acknowledgement survive the shift change."
    return Result(checks, phase, summary)


def validate_035(w: pathlib.Path) -> Result:
    c = load_json(w / "storage-performance.yaml")
    checks = [
        check(c.get("volume_type") == "gp3", "Workload uses independently provisioned gp3 performance"),
        check(c.get("provisioned_iops", 0) >= 3000, "Provisioned IOPS meets measured demand"),
        check(c.get("throughput_mibps", 0) >= 125, "Throughput meets the workload floor"),
        check(c.get("application_queue_limit", 99999) <= 200, "Application queue is bounded"),
        check(c.get("io_latency_alert_ms", 9999) <= 20, "Storage latency has an actionable alert"),
        check(c.get("fio_baseline_test") is True, "Storage performance was benchmarked"),
        check(c.get("filesystem_free_percent", 0) >= 25, "Capacity headroom is preserved"),
        check(c.get("burst_balance_alert") is True, "Burst-credit exhaustion remains observable"),
    ]
    if c.get("provisioned_iops", 0) < 1000:
        phase, summary = "IOPSSaturation", "The disk has free capacity but cannot service the operation rate."
    elif c.get("application_queue_limit", 9999) > 200:
        phase, summary = "QueueingStillHigh", "Storage is faster, but unbounded application queueing still inflates latency."
    elif any(not ok for ok, _ in checks):
        phase, summary = "PerformanceUnproven", "Provisioned performance improves, but alerting, headroom, or benchmark evidence is incomplete."
    else:
        phase, summary = "Healthy", "Provisioned performance, bounded queues, alerts, and benchmark evidence restore latency."
    return Result(checks, phase, summary)


def validate_036(w: pathlib.Path) -> Result:
    c = load_json(w / "dns-reliability.yaml")
    checks = [
        check(c.get("record_ttl_seconds", 9999) <= 60, "Service DNS TTL supports recovery"),
        check(c.get("resolver_replicas", 0) >= 2, "DNS has redundant resolver replicas"),
        check(c.get("node_local_cache") is True, "Node-local DNS caching reduces dependency pressure"),
        check(c.get("query_timeout_ms", 9999) <= 1000, "DNS queries have a bounded timeout"),
        check(c.get("attempts", 99) <= 2, "Resolver retries are bounded"),
        check(c.get("synthetic_lookup") is True, "Synthetic DNS lookup monitors resolution"),
        check(c.get("dns_runbook") is True, "DNS failure has a dedicated runbook"),
        check(c.get("application_fallback_cache") is True, "Application has a short safe resolution cache"),
    ]
    if c.get("resolver_replicas", 0) < 2:
        phase, summary = "ResolverSinglePoint", "A single DNS resolver failure presents as a broad application outage."
    elif not c.get("synthetic_lookup"):
        phase, summary = "DNSBlindSpot", "Redundancy improves, but DNS is still inferred only from application failures."
    else:
        phase, summary = "Healthy", "Redundancy, caching, bounded queries, synthetic monitoring, and runbooks harden DNS."
    return Result(checks, phase, summary)


def validate_037(w: pathlib.Path) -> Result:
    c = load_json(w / "migration-plan.json")
    expected = ["expand-schema", "deploy-dual-read-write", "backfill-throttled", "verify-parity", "switch-read-path", "stop-old-writes", "contract-later"]
    checks = [
        check(c.get("steps") == expected, "Migration follows expand-and-contract order"),
        check(c.get("backward_compatible") is True, "Every rollout stage is backward compatible"),
        check(c.get("backfill_rate_limited") is True, "Backfill is throttled"),
        check(c.get("parity_check") is True, "Old and new data paths are compared"),
        check(c.get("rollback_before_contract") is True, "Rollback remains possible until contract"),
        check(c.get("drop_old_column_same_release") is False, "Old schema is not removed in the cutover release"),
        check(c.get("lock_time_budget_ms", 99999) <= 500, "Schema operations respect a lock-time budget"),
        check(c.get("zero_downtime_exercise") is True, "Migration passed a zero-downtime rehearsal"),
    ]
    if c.get("drop_old_column_same_release"):
        phase, summary = "DestructiveMigration", "The release removes the old schema before every application instance has cut over."
    elif c.get("steps") != expected:
        phase, summary = "UnsafeMigrationOrder", "The migration components exist but are sequenced unsafely."
    else:
        phase, summary = "Healthy", "Expand, dual operation, throttled backfill, parity, cutover, rollback, and delayed contract are proven."
    return Result(checks, phase, summary)


def validate_038(w: pathlib.Path) -> Result:
    c = load_json(w / "message-failover.yaml")
    checks = [
        check(c.get("idempotency_key_required") is True, "Consumers require an idempotency key"),
        check(c.get("deduplication_window_hours", 0) >= 24, "Deduplication covers the failover replay window"),
        check(c.get("transactional_outbox") is True, "Producers use a transactional outbox"),
        check(c.get("replicated_checkpoint") is True, "Consumer replay checkpoint is replicated"),
        check(c.get("dead_letter_queue") is True, "Poison messages move to a DLQ"),
        check(c.get("exactly_once_assumption") is False, "Design does not depend on exactly-once delivery"),
        check(c.get("replay_dry_run") is True, "Replay is assessed before activation"),
        check(c.get("duplicate_business_event_test") is True, "Business-level duplicate handling is tested"),
    ]
    if c.get("exactly_once_assumption"):
        phase, summary = "DuplicateSideEffects", "Regional replay repeats messages and the consumer performs duplicate business actions."
    elif not c.get("replicated_checkpoint"):
        phase, summary = "UnboundedReplay", "Idempotency exists, but failover has no trusted point from which to resume."
    else:
        phase, summary = "Healthy", "Outbox, checkpoints, idempotency, deduplication, DLQ, and replay tests contain duplicates."
    return Result(checks, phase, summary)


def validate_039(w: pathlib.Path) -> Result:
    c = load_json(w / "tenant-isolation.yaml")
    checks = [
        check(c.get("tenant_source") == "verified-auth-claim", "Tenant identity comes from a verified authentication claim"),
        check(c.get("trust_client_tenant_header") is False, "Client-supplied tenant header is not trusted"),
        check(c.get("database_rls") is True, "Database row-level security enforces tenant scope"),
        check(c.get("cache_key_includes_tenant") is True, "Cache identity includes tenant"),
        check(c.get("object_storage_prefix_isolated") is True, "Object storage paths are tenant-scoped"),
        check(c.get("cross_tenant_test") is True, "Automated tests attempt cross-tenant access"),
        check(c.get("audit_log_tenant_context") is True, "Audit logs record tenant context"),
        check(c.get("logs_redact_customer_data") is True, "Operational logs redact customer data"),
    ]
    if c.get("trust_client_tenant_header"):
        phase, summary = "TenantSpoofing", "A caller can select another tenant by changing an untrusted request header."
    elif not c.get("database_rls"):
        phase, summary = "ApplicationOnlyIsolation", "Application checks improve, but the database has no independent tenant boundary."
    elif any(not ok for ok, _ in checks):
        phase, summary = "IsolationIncomplete", "Core identity and database controls improve, but storage, tests, audit, or logging remain incomplete."
    else:
        phase, summary = "Healthy", "Identity, database, cache, storage, tests, audit, and logging enforce tenant isolation."
    return Result(checks, phase, summary)


def validate_040(w: pathlib.Path) -> Result:
    c = load_json(w / "production-readiness.json")
    required = [
        ("ownership", "Service ownership is assigned"),
        ("runbook", "Operational runbook exists"),
        ("slo", "User-facing SLO is defined"),
        ("alerts_tested", "Alert routing is tested"),
        ("capacity_test", "Capacity test passed"),
        ("rollback_test", "Rollback test passed"),
        ("restore_test", "Backup restore test passed"),
        ("dr_exercise", "Disaster-recovery exercise passed"),
        ("security_scan", "Security scan gate passed"),
        ("provenance_enforced", "Artifact provenance is enforced"),
        ("least_privilege_review", "Least-privilege review passed"),
        ("post_deploy_smoke", "Post-deploy smoke test is automated"),
    ]
    checks = [check(c.get(key) is True, label) for key, label in required]
    checks += [
        check(c.get("error_budget_remaining_percent", 0) >= 50, "Error budget supports launch risk"),
        check(c.get("open_critical_risks", 99) == 0, "No unaccepted critical risks remain"),
        check(c.get("launch_approval") == "approved", "Accountable owners approved launch"),
    ]
    missing = [label for ok, label in checks if not ok]
    if not c.get("rollback_test") or not c.get("restore_test"):
        phase, summary = "RecoveryNotProven", "The service can deploy, but rollback or restore has not been demonstrated."
    elif missing:
        phase, summary = "ReadinessGaps", f"Production readiness still has {len(missing)} failed control(s)."
    else:
        phase, summary = "Healthy", "Ownership, reliability, recovery, security, capacity, observability, and approval gates support launch."
    return Result(checks, phase, summary)


VALIDATORS: dict[str, Callable[[pathlib.Path], Result]] = {
    f"{i:03d}": globals()[f"validate_{i:03d}"] for i in range(1, 41)
}


def resolve_lab(lab_id: str) -> pathlib.Path:
    matches = sorted(LABS.glob(f"{lab_id}-*"))
    if len(matches) != 1:
        raise ValueError(f"unknown lab ID {lab_id}; run './labctl list'")
    return matches[0]


def workspace(lab_id: str) -> pathlib.Path:
    return WORKSPACES / lab_id


def copy_tree_contents(source: pathlib.Path, target: pathlib.Path) -> None:
    target.mkdir(parents=True, exist_ok=True)
    for item in source.iterdir():
        dest = target / item.name
        if item.is_dir():
            if dest.exists():
                shutil.rmtree(dest)
            shutil.copytree(item, dest)
        else:
            shutil.copy2(item, dest)


def start(lab_id: str, force: bool = False) -> int:
    lab = resolve_lab(lab_id)
    work = workspace(lab_id)
    if work.exists() and not force:
        print(f"Workspace already exists: {work.relative_to(ROOT)}")
        print(f"Use './labctl reset {lab_id}' to restore the broken state.")
        return 0
    if work.exists():
        shutil.rmtree(work)
    copy_tree_contents(lab / "broken-environment", work)
    shutil.copy2(lab / "templates" / "INCIDENT-NOTES.md", work / "INCIDENT-NOTES.md")
    print(f"INCIDENT {lab_id} STARTED")
    print(f"Workspace: {work.relative_to(ROOT)}")
    print(f"Briefing: {lab.relative_to(ROOT) / 'briefing' / 'INCIDENT.md'}")
    result = VALIDATORS[lab_id](work)
    print(f"Initial phase: {result.phase}")
    print(result.summary)
    return 0


def status(lab_id: str) -> int:
    work = workspace(lab_id)
    if not work.exists():
        raise ValueError(f"lab {lab_id} has not been started")
    result = VALIDATORS[lab_id](work)
    print(f"PHASE: {result.phase}")
    print(f"SUMMARY: {result.summary}")
    print(f"GATES: {result.passed} passing, {result.failed} failing")
    return 0 if result.healthy else 1


def documentation_checks(work: pathlib.Path) -> list[tuple[bool, str]]:
    notes_path = work / "INCIDENT-NOTES.md"
    try:
        notes = notes_path.read_text(encoding="utf-8")
    except FileNotFoundError:
        notes = ""
    def section_has_content(header: str, minimum: int = 80) -> bool:
        if header not in notes:
            return False
        tail = notes.split(header, 1)[1]
        next_header = tail.find("\n## ")
        body = tail if next_header < 0 else tail[:next_header]
        return len(body.strip()) >= minimum
    return [
        check(notes.startswith("STATUS: COMPLETE"), "Incident engineering record is marked complete"),
        check(section_has_content("## Validation evidence"), "Validation evidence is documented"),
        check(section_has_content("## Senior-engineer defense"), "The remediation decision is defended"),
    ]


def validate(lab_id: str) -> int:
    work = workspace(lab_id)
    if not work.exists():
        raise ValueError(f"lab {lab_id} has not been started")
    technical = VALIDATORS[lab_id](work)
    result = Result(technical.checks + documentation_checks(work), technical.phase, technical.summary)
    print(f"Validating Incident {lab_id}...")
    for ok, label in result.checks:
        print(f"{'PASS' if ok else 'FAIL'}: {label}")
    print(f"\nScore: {result.passed} passed, {result.failed} failed")
    if result.healthy:
        print(f"INCIDENT {lab_id} COMPLETE")
        return 0
    return 1


def reset(lab_id: str) -> int:
    lab = resolve_lab(lab_id)
    work = workspace(lab_id)
    if work.exists():
        shutil.rmtree(work)
    copy_tree_contents(lab / "broken-environment", work)
    shutil.copy2(lab / "templates" / "INCIDENT-NOTES.md", work / "INCIDENT-NOTES.md")
    print(f"Incident {lab_id} reset to the original broken state.")
    return 0


def destroy(lab_id: str) -> int:
    work = workspace(lab_id)
    if work.exists():
        shutil.rmtree(work)
    print(f"Incident {lab_id} workspace removed.")
    return 0


def apply_reference(lab_id: str) -> int:
    lab = resolve_lab(lab_id)
    work = workspace(lab_id)
    if not work.exists():
        start(lab_id)
    copy_tree_contents(lab / "solution" / "fixed-environment", work)
    reference_notes = lab / "solution" / "REFERENCE-NOTES.md"
    if reference_notes.exists():
        shutil.copy2(reference_notes, work / "INCIDENT-NOTES.md")
    print(f"Reference remediation applied to Incident {lab_id} workspace.")
    return 0


def list_labs() -> int:
    for path in sorted(LABS.iterdir()):
        if not path.is_dir():
            continue
        meta = load_json(path / "metadata.json")
        print(f"{meta['id']}  {meta['title']}  [{meta['part']}] ")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="The DevOps Incident Lab portable engine")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("list")
    for name in ("start", "status", "validate", "reset", "destroy", "apply-reference"):
        p = sub.add_parser(name)
        p.add_argument("lab_id", choices=sorted(VALIDATORS))
        if name == "start":
            p.add_argument("--force", action="store_true")
    args = parser.parse_args()
    try:
        if args.command == "list":
            return list_labs()
        if args.command == "start":
            return start(args.lab_id, args.force)
        if args.command == "status":
            return status(args.lab_id)
        if args.command == "validate":
            return validate(args.lab_id)
        if args.command == "reset":
            return reset(args.lab_id)
        if args.command == "destroy":
            return destroy(args.lab_id)
        if args.command == "apply-reference":
            return apply_reference(args.lab_id)
    except ValueError as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
