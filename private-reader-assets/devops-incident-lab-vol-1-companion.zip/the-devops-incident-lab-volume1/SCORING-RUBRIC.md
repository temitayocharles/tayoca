# Incident Scoring Rubric

| Dimension | Weight | Full-credit standard |
|---|---:|---|
| Diagnosis | 25 | Root cause distinguishes symptom, mechanism, and cause and cites evidence |
| Remediation | 25 | Every causal defect is repaired; partial fixes do not pass |
| Safety | 20 | Constraints, least privilege, identity, rollback, and data protections are preserved |
| Validation | 20 | Repeatable technical and user-facing proof is captured |
| Communication | 10 | Timeline, rejected shortcuts, evidence, prevention, and decision defense are complete |

## Hard caps

- Unsafe remediation: maximum 60.
- No repeatable validation: maximum 70.
- Missing incident record: incomplete regardless of technical score.
- Destructive shortcut that violates the briefing: fail.

## Suggested interpretation

- 90–100: senior-ready response
- 80–89: strong production response with minor gaps
- 70–79: technically useful but requires supervision
- Below 70: incomplete or unsafe incident handling
