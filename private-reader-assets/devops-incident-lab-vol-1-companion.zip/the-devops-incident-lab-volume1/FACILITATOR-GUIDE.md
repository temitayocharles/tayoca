# Facilitator Guide

## Roles

Assign an incident commander, investigator, operator, and scribe. Rotate roles between incidents.

## Delivery pattern

1. Give the briefing and initial evidence only.
2. Require a written hypothesis before each change.
3. Ask what the proposed action proves and what it risks.
4. Introduce the partial remediation when the team reaches the obvious fix.
5. Require technical validation and a completed engineering record.
6. Review rejected shortcuts before revealing the reference solution.
7. Reset the incident and have another engineer explain the failure from scratch.

## Debrief questions

- Which success signal was misleading?
- What evidence changed the working hypothesis?
- Which shortcut would have restored symptoms while weakening safety?
- How was blast radius bounded?
- What proved user recovery?
- What control prevents recurrence?

## Assessment

Use `SCORING-RUBRIC.md`. Do not score command memorization. Score evidence quality, causal reasoning, safety, validation, and communication.
