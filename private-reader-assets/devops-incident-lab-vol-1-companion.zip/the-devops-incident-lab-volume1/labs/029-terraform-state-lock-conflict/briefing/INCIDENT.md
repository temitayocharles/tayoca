# Incident 029: The Terraform State Lock Nobody Should Force-Unlock Yet

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** state locking, concurrency, force unlock, state recovery

## Situation

Terraform reports a lock. The operation began three minutes ago, and nobody has confirmed whether the runner is still alive.

## Your mission

1. Identify the lock owner and operation.
2. Distinguish active from stale lock.
3. Back up state and perform controlled recovery only when safe.

## Operational constraints

- No blind force-unlock.
- Target the exact lock ID.
- Run refresh-only assessment afterward.

## Start

```bash
./labctl start 029
./labctl status 029
```

Edit `.workspaces/029/` only.

## Files under your control

- `state-lock-recovery.json`

## Evidence

- `lock-info.txt`

## Completion

```bash
./labctl validate 029
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
