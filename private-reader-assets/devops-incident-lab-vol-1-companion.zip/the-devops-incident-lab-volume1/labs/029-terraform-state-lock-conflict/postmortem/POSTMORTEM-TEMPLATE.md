# Postmortem: Incident 029

## Impact

## Detection

## Timeline

## Root cause

## Contributing factors

## Corrective actions

| Action | Owner | Priority | Verification |
|---|---|---|---|
| | | | |
