# Incident 022: The NetworkPolicy That Blocked DNS

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** NetworkPolicy, DNS, egress controls, connectivity testing

## Situation

A default-deny egress policy protects the namespace but silently blocks cluster DNS, making every dependency appear unavailable.

## Your mission

1. Allow only required DNS traffic.
2. Preserve default deny.
3. Prove DNS and HTTPS dependency access.

## Operational constraints

- No allow-all egress.
- Scope DNS to kube-system and DNS pods.
- Keep dependency port restricted.

## Start

```bash
./labctl start 022
./labctl status 022
```

Edit `.workspaces/022/` only.

## Files under your control

- `network-policy.yaml`

## Evidence

- `connection-test.txt`

## Completion

```bash
./labctl validate 022
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
