# Senior Engineer Walkthrough: Incident 022

Compare your workspace with `fixed-environment/` only after completing or abandoning the investigation.

```bash
diff -ru .workspaces/022 labs/022-network-policy-blocked-dns/solution/fixed-environment
```

The reference is not merely a set of correct values. It demonstrates the minimum defensible production contract and the controls that prevent recurrence.
