# Incident 019: The Helm Release That Failed Halfway

**Level:** Advanced  
**Target time:** 60–95 minutes  
**Core skills:** Helm, atomic upgrades, hooks, rollback

## Situation

A pre-upgrade hook fails after several resources have changed, leaving a mixed release and no reliable rollback point.

## Your mission

1. Make the release atomic and readiness-gated.
2. Protect stateful data before upgrade.
3. Use immutable artifacts and deterministic hook cleanup.

## Operational constraints

- No manual deletion of failed resources.
- No mutable image tags.
- Rollback must preserve data.

## Start

```bash
./labctl start 019
./labctl status 019
```

Edit `.workspaces/019/` only.

## Files under your control

- `helm-values.yaml`
- `release.json`

## Evidence

- `helm-error.txt`

## Completion

```bash
./labctl validate 019
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
