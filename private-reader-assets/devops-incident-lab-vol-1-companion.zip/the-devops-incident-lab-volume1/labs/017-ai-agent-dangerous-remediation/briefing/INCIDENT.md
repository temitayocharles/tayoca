# Incident 017: Senior Challenge: The AI Agent Proposed a Dangerous Fix

**Level:** Senior  
**Target time:** 90–145 minutes  
**Core skills:** AI operations safety, prompt injection, least privilege, human approval

## Situation

An operations agent reads a malicious instruction embedded in logs and proposes deleting a Deployment. Its tool role allows wildcard verbs and no approval.

## Your mission

1. Separate untrusted evidence from instructions.
2. Make investigation read-only by default.
3. Require independent evidence, approval, bounded patch permissions, and rollback.

## Operational constraints

- No wildcard verbs.
- No delete permission.
- Every write requires approval.
- Actions remain namespace-scoped.

## Start the incident

```bash
./labctl start 017
./labctl status 017
```

Edit the files inside:

```text
.workspaces/017/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `agent-policy.yaml`
- `tool-permissions.json`
- `proposed-action.json`

## Evidence supplied

- `agent-transcript.txt`
- `rbac-audit.json`

## Completion standard

Run:

```bash
./labctl validate 017
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/017/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
