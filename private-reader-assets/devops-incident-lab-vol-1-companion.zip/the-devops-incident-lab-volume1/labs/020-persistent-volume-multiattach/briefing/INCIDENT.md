# Incident 020: The Persistent Volume That Would Not Reattach

**Level:** Advanced  
**Target time:** 65–105 minutes  
**Core skills:** persistent volumes, fencing, attachment recovery, data integrity

## Situation

A stateful pod moves after node failure, but its ReadWriteOnce volume remains attached to the former node.

## Your mission

1. Prove the old writer is fenced.
2. Recover attachment without force-detach corruption risk.
3. Validate filesystem and application data.

## Operational constraints

- Do not switch to ReadWriteMany.
- Do not force detach before fencing.
- Verify backup first.

## Start

```bash
./labctl start 020
./labctl status 020
```

Edit `.workspaces/020/` only.

## Files under your control

- `storage-recovery.json`

## Evidence

- `volume-events.txt`

## Completion

```bash
./labctl validate 020
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
