# Incident 016: Senior Challenge: The Artifact Came From the Wrong Builder

**Level:** Senior  
**Target time:** 85–140 minutes  
**Core skills:** supply-chain security, signatures, provenance, admission policy

## Situation

A correctly named image digest arrives from an untrusted workflow. The cluster admits it because signature and provenance enforcement are optional.

## Your mission

1. Verify digest, signature, issuer, subject, SBOM, and provenance.
2. Enforce the checks at admission.
3. Make verification a pre-deployment pipeline gate.

## Operational constraints

- Do not trust a tag or registry location alone.
- Trust one issuer and one repository subject.
- Reject unsigned artifacts.

## Start the incident

```bash
./labctl start 016
./labctl status 016
```

Edit the files inside:

```text
.workspaces/016/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `attestation.json`
- `admission-policy.yaml`
- `workflow.yaml`

## Evidence supplied

- `registry-event.json`
- `admission-audit.txt`

## Completion standard

Run:

```bash
./labctl validate 016
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/016/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
