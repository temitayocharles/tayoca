# Incident 011: The Service Was Slow but CPU Looked Fine

**Level:** Advanced  
**Target time:** 65–100 minutes  
**Core skills:** latency decomposition, queueing, retry amplification, SLO validation

## Situation

Checkout p95 exceeds two seconds while CPU remains below 35%. Traces show queueing at the database pool and retries extending request lifetimes.

## Your mission

1. Use latency evidence instead of CPU assumptions.
2. Bound queues, retries, and deadlines.
3. Resize the connection pool from measured concurrency.
4. Prove the SLO through simulation.

## Operational constraints

- Do not simply add CPU.
- Keep tracing enabled.
- Database timeout must remain below the request deadline.

## Start the incident

```bash
./labctl start 011
./labctl status 011
```

Edit the files inside:

```text
.workspaces/011/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `service-config.yaml`

## Evidence supplied

- `trace-summary.json`
- `slo-dashboard.txt`

## Completion standard

Run:

```bash
./labctl validate 011
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/011/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
