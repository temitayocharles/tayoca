# Postmortem: Incident 032

## Impact

## Detection

## Timeline

## Root cause

## Contributing factors

## Corrective actions

| Action | Owner | Priority | Verification |
|---|---|---|---|
| | | | |
