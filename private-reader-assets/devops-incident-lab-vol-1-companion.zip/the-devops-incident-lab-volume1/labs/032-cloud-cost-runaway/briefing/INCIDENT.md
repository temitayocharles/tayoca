# Incident 032: The Quiet Cloud Configuration That Became a Cost Incident

**Level:** Intermediate  
**Target time:** 50–85 minutes  
**Core skills:** FinOps, right-sizing, retention, budget controls

## Situation

Non-production runs three NAT gateways, infinite logs, oversized compute, and idle environments around the clock without budgets.

## Your mission

1. Reduce structural network cost.
2. Bound retention and idle runtime.
3. Right-size from evidence and add cost observability.

## Operational constraints

- Do not sacrifice production resilience assumptions blindly.
- Keep cost-allocation tags.
- Set measurable budget alerts.

## Start

```bash
./labctl start 032
./labctl status 032
```

Edit `.workspaces/032/` only.

## Files under your control

- `cost-controls.yaml`

## Evidence

- `cost-report.txt`

## Completion

```bash
./labctl validate 032
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
