# Incident 028: The Tag Trigger That Bypassed Production Approval

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** approval gates, protected environments, signed tags, change control

## Situation

Main-branch deploys require approval, but a release tag follows a separate job that writes directly to production.

## Your mission

1. Route every production path through one protected environment.
2. Bind approval to a signed tag, digest, and change record.
3. Audit emergency release paths.

## Operational constraints

- No conditional bypass.
- At least one required reviewer.
- Post-deploy verification remains mandatory.

## Start

```bash
./labctl start 028
./labctl status 028
```

Edit `.workspaces/028/` only.

## Files under your control

- `production-gate.yaml`

## Evidence

- `workflow-audit.txt`

## Completion

```bash
./labctl validate 028
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
