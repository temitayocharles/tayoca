# Senior Engineer Walkthrough: Incident 028

Compare your workspace with `fixed-environment/` only after completing or abandoning the investigation.

```bash
diff -ru .workspaces/028 labs/028-production-approval-bypassed/solution/fixed-environment
```

The reference is not merely a set of correct values. It demonstrates the minimum defensible production contract and the controls that prevent recurrence.
