# Incident 038: Senior Challenge: Regional Failover Replayed Every Message

**Level:** Senior  
**Target time:** 95–150 minutes  
**Core skills:** messaging, idempotency, regional failover, replay

## Situation

The secondary region starts consuming from an old checkpoint, and consumers assumed exactly-once delivery, duplicating payment side effects.

## Your mission

1. Make business operations idempotent.
2. Replicate replay checkpoints.
3. Use transactional outbox, deduplication, DLQ, and replay validation.

## Operational constraints

- Do not assume exactly once.
- Protect business side effects.
- Keep poison messages auditable.

## Start

```bash
./labctl start 038
./labctl status 038
```

Edit `.workspaces/038/` only.

## Files under your control

- `message-failover.yaml`

## Evidence

- `duplicate-events.txt`

## Completion

```bash
./labctl validate 038
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
