# Incident 013: The Backup That Existed but Could Not Restore

**Level:** Advanced  
**Target time:** 70–110 minutes  
**Core skills:** recoverability, restore testing, encryption dependencies, RTO/RPO

## Situation

Nightly backups are green, but a restore rehearsal fails because encryption-key context and secret metadata were not captured.

## Your mission

1. Make the backup set operationally complete.
2. Align the runbook to the current format.
3. Pass integrity, RTO, and RPO gates in a controlled restore test.

## Operational constraints

- Do not call a backup valid without restore evidence.
- Retain an immutable copy.
- Verify key access before restore.

## Start the incident

```bash
./labctl start 013
./labctl status 013
```

Edit the files inside:

```text
.workspaces/013/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `backup-policy.yaml`
- `restore-runbook.json`
- `restore-test.json`

## Evidence supplied

- `backup-job.log`
- `restore-failure.txt`

## Completion standard

Run:

```bash
./labctl validate 013
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/013/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
