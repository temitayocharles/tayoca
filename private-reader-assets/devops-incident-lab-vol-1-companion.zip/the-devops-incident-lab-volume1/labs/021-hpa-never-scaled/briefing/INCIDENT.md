# Incident 021: The HPA That Watched Traffic but Never Scaled

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** HPA, resource requests, stabilization, load testing

## Situation

Traffic triples, latency rises, and the HorizontalPodAutoscaler remains at two replicas because utilization cannot be calculated.

## Your mission

1. Restore meaningful utilization metrics.
2. Create a real scaling range and stable behavior.
3. Prove scaling under controlled load.

## Operational constraints

- Do not add fixed replicas as the final answer.
- Keep two minimum replicas.
- Avoid scale-down flapping.

## Start

```bash
./labctl start 021
./labctl status 021
```

Edit `.workspaces/021/` only.

## Files under your control

- `hpa.yaml`
- `deployment.yaml`

## Evidence

- `hpa-status.txt`

## Completion

```bash
./labctl validate 021
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
