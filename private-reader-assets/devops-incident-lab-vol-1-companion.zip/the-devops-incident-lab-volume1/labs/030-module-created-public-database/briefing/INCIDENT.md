# Incident 030: The Reusable Module That Created a Public Database

**Level:** Advanced  
**Target time:** 60–95 minutes  
**Core skills:** Terraform modules, RDS security, validation, secure defaults

## Situation

A default combination places production RDS in public subnets with broad CIDR ingress and no deletion protection.

## Your mission

1. Make network placement private.
2. Restrict ingress to the runtime security group.
3. Enforce encryption, backups, deletion protection, and unsafe-combination validation.

## Operational constraints

- No public CIDR.
- Fix the reusable module contract, not only one caller.
- Preserve recoverability.

## Start

```bash
./labctl start 030
./labctl status 030
```

Edit `.workspaces/030/` only.

## Files under your control

- `database-module.yaml`

## Evidence

- `plan.txt`

## Completion

```bash
./labctl validate 030
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
