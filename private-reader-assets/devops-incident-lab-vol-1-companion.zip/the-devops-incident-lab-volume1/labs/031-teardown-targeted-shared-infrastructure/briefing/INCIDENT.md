# Incident 031: The Teardown Plan That Targeted Shared Infrastructure

**Level:** Advanced  
**Target time:** 60–100 minutes  
**Core skills:** safe teardown, ownership, shared resources, orphan cleanup

## Situation

An application teardown includes the shared VPC, state bucket, and lock table because ownership boundaries were never encoded.

## Your mission

1. Delete only owned resources.
2. Preserve shared control-plane infrastructure.
3. Remove only the application state prefix and prove cleanup.

## Operational constraints

- No shared VPC deletion.
- No state bucket deletion.
- Run dependency and orphan scans.

## Start

```bash
./labctl start 031
./labctl status 031
```

Edit `.workspaces/031/` only.

## Files under your control

- `teardown-plan.json`

## Evidence

- `destroy-plan.txt`

## Completion

```bash
./labctl validate 031
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
