# Senior Engineer Walkthrough: Incident 039

Compare your workspace with `fixed-environment/` only after completing or abandoning the investigation.

```bash
diff -ru .workspaces/039 labs/039-multi-tenant-isolation-failure/solution/fixed-environment
```

The reference is not merely a set of correct values. It demonstrates the minimum defensible production contract and the controls that prevent recurrence.
