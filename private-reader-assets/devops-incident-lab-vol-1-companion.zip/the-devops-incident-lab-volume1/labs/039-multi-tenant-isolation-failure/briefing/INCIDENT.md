# Incident 039: Senior Challenge: One Tenant Could Read Another Tenant’s Data

**Level:** Senior  
**Target time:** 100–160 minutes  
**Core skills:** multi-tenancy, RLS, cache isolation, authorization

## Situation

The API trusts a tenant header, the cache key omits tenant identity, and the database has no row-level security.

## Your mission

1. Derive tenant identity from verified authentication.
2. Enforce independent database isolation.
3. Scope cache, storage, tests, audit, and logs.

## Operational constraints

- Do not trust client tenant headers.
- Add cross-tenant negative tests.
- Redact customer data in logs.

## Start

```bash
./labctl start 039
./labctl status 039
```

Edit `.workspaces/039/` only.

## Files under your control

- `tenant-isolation.yaml`

## Evidence

- `security-report.txt`

## Completion

```bash
./labctl validate 039
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
