# Incident 023: The Emergency Hotfix GitOps Tried to Undo

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** GitOps drift, emergency change, self-healing, governance

## Situation

An engineer patches production directly during an outage. The fix works, but Git still contains the broken revision and self-healing is disabled.

## Your mission

1. Represent the emergency fix in Git.
2. Converge cluster and desired SHA.
3. Restore drift detection and controlled self-healing.

## Operational constraints

- No permanent kubectl-only fix.
- Pruning needs approval.
- Keep an emergency change record.

## Start

```bash
./labctl start 023
./labctl status 023
```

Edit `.workspaces/023/` only.

## Files under your control

- `gitops-state.json`

## Evidence

- `drift.txt`

## Completion

```bash
./labctl validate 023
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
