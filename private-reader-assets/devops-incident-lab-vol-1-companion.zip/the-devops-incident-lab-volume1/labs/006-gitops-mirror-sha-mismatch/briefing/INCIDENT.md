# Incident 006: The GitOps Release That Deployed Yesterday’s Commit

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** Git mirror consistency, GitOps revision pinning, release gates, evidence

## Situation

Forgejo reports a successful release, but the GitHub mirror is behind. Argo CD follows main and reconciles a stale commit.

## Your mission

1. Make mirror synchronization an explicit release gate.
2. Compare source and mirror SHAs.
3. Pin Argo CD and release evidence to the intended commit.

## Operational constraints

- Do not add arbitrary sleep.
- Use a bounded wait.
- Fail on SHA mismatch.
- Deploy an exact commit, not a branch.

## Start the incident

```bash
./labctl start 006
./labctl status 006
```

Edit the files inside:

```text
.workspaces/006/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `mirror.json`
- `workflow.yaml`
- `argocd-application.yaml`

## Evidence supplied

- `mirror-status.txt`
- `argocd-history.txt`

## Completion standard

Run:

```bash
./labctl validate 006
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/006/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
