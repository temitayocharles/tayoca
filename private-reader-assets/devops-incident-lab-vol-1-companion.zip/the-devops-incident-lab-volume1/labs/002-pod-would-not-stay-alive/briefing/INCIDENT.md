# Incident 002: The Pod That Would Not Stay Alive

**Level:** Intermediate  
**Target time:** 50–80 minutes  
**Core skills:** CrashLoopBackOff, previous logs, liveness, security context

## Situation

A payments API enters CrashLoopBackOff after a configuration change. The first obvious fix only reveals a second restart mechanism.

## Your mission

1. Use the failure sequence to distinguish process exit from kubelet restart.
2. Repair startup and liveness contracts.
3. Preserve non-root execution, resource controls, and readiness.

## Operational constraints

- Do not remove liveness or readiness probes.
- Do not run as root.
- Do not increase restart tolerance to hide the defect.

## Start the incident

```bash
./labctl start 002
./labctl status 002
```

Edit the files inside:

```text
.workspaces/002/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `runtime-config.yaml`
- `content-config.yaml`
- `deployment.yaml`
- `service.yaml`

## Evidence supplied

- `previous-container.log`
- `pod-events.txt`

## Completion standard

Run:

```bash
./labctl validate 002
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/002/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
