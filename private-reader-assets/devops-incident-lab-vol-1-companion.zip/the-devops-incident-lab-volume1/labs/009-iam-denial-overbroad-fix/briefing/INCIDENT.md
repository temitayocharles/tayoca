# Incident 009: The IAM Denial and the Dangerous One-Line Fix

**Level:** Intermediate  
**Target time:** 50–80 minutes  
**Core skills:** IAM diagnosis, least privilege, KMS context, policy review

## Situation

The deployment role cannot read an encrypted release artifact. A proposed fix grants s3:* and kms:* on every resource.

## Your mission

1. Grant only the missing object-read and decrypt capabilities.
2. Scope S3 to the release prefix and KMS to one key.
3. Constrain decrypt with encryption context.

## Operational constraints

- No wildcard action.
- No Resource "*".
- Do not grant write permissions.
- Preserve least privilege.

## Start the incident

```bash
./labctl start 009
./labctl status 009
```

Edit the files inside:

```text
.workspaces/009/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `policy.json`

## Evidence supplied

- `access-denied.json`
- `cloudtrail-event.json`

## Completion standard

Run:

```bash
./labctl validate 009
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/009/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
