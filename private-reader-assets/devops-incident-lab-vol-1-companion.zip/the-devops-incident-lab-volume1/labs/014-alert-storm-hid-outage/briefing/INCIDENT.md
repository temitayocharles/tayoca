# Incident 014: The Alert Storm That Hid the Real Outage

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** alert design, SLO burn rates, inhibition, on-call usability

## Situation

One database outage creates eight pages from six downstream services. The on-call engineer spends the first ten minutes acknowledging symptoms.

## Your mission

1. Reduce pages to causal, actionable signals.
2. Group and deduplicate alerts.
3. Inhibit downstream symptoms.
4. Use fast and slow SLO burn routing.

## Operational constraints

- Do not silence the outage.
- Every page needs a runbook.
- Keep slow-burn risk visible without paging.

## Start the incident

```bash
./labctl start 014
./labctl status 014
```

Edit the files inside:

```text
.workspaces/014/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `alerts.yaml`

## Evidence supplied

- `pager-timeline.txt`
- `alert-sample.json`

## Completion standard

Run:

```bash
./labctl validate 014
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/014/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
