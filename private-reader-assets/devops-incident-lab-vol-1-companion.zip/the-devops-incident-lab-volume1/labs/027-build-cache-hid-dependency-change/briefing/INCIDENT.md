# Incident 027: The Build Cache That Hid a Dependency Change

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** build caching, lockfiles, deterministic builds, dependency evidence

## Situation

A branch cache restores an incompatible dependency tree, and npm install quietly rewrites resolution despite a changed lockfile.

## Your mission

1. Bind cache identity to lockfile and toolchain.
2. Use deterministic installation.
3. Record dependency evidence.

## Operational constraints

- No branch-only cache key.
- No broad cross-version restore key.
- Do not rewrite lockfiles in CI.

## Start

```bash
./labctl start 027
./labctl status 027
```

Edit `.workspaces/027/` only.

## Files under your control

- `cache-policy.yaml`

## Evidence

- `build-log.txt`

## Completion

```bash
./labctl validate 027
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
