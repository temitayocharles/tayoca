# Senior Engineer Walkthrough: Incident 027

Compare your workspace with `fixed-environment/` only after completing or abandoning the investigation.

```bash
diff -ru .workspaces/027 labs/027-build-cache-hid-dependency-change/solution/fixed-environment
```

The reference is not merely a set of correct values. It demonstrates the minimum defensible production contract and the controls that prevent recurrence.
