# Incident 001: The Deployment That Passed but Never Worked

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** readiness probes, Service routing, rollout verification, safe remediation

## Situation

A release pipeline accepted every manifest and reported success, but customers receive errors and the Deployment never becomes fully available.

## Your mission

1. Find every independent fault preventing a healthy rollout.
2. Repair the workload without deleting probes, reducing replicas, or exposing the Service publicly.
3. Prove readiness, Service routing, and the user-facing request path.

## Operational constraints

- Keep two replicas.
- Keep the Service as ClusterIP.
- Preserve the readiness probe and resource controls.
- Do not route around the Service.

## Start the incident

```bash
./labctl start 001
./labctl status 001
```

Edit the files inside:

```text
.workspaces/001/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `deployment.yaml`
- `service.yaml`

## Evidence supplied

- `pipeline-output.txt`
- `deployment-events.txt`

## Completion standard

Run:

```bash
./labctl validate 001
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/001/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
