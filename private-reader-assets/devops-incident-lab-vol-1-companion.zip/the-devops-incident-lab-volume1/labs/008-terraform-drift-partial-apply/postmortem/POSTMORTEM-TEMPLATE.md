# Postmortem: Incident 008

## Impact

## Detection

## Timeline

## Root cause

## Contributing factors

## What went well

## What failed

## Corrective actions

| Action | Owner | Priority | Verification |
|---|---|---|---|
| | | | |

## Lessons for future incidents
