# Incident 008: The Partial Apply and the Orphaned Production Resource

**Level:** Advanced  
**Target time:** 70–110 minutes  
**Core skills:** drift analysis, import/adoption, partial apply recovery, identity preservation

## Situation

A failed apply created a production instance outside state while an out-of-band security-group change opened ingress globally.

## Your mission

1. Assess actual state before changing anything.
2. Adopt the orphaned resource.
3. Reconcile drift without replacing the production instance.
4. Require an empty post-apply plan.

## Operational constraints

- No resource replacement.
- Use state locking.
- Begin with refresh-only assessment.
- Restore the approved CIDR.

## Start the incident

```bash
./labctl start 008
./labctl status 008
```

Edit the files inside:

```text
.workspaces/008/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `observed-state.json`
- `desired-state.json`
- `remediation.json`

## Evidence supplied

- `cloud-inventory.json`
- `failed-apply.log`

## Completion standard

Run:

```bash
./labctl validate 008
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/008/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
