# Incident 040: Senior Challenge: The Production Readiness Review

**Level:** Senior  
**Target time:** 120–180 minutes  
**Core skills:** production readiness, risk review, recovery, operational ownership

## Situation

A new service can deploy and pass a happy-path demo, but ownership, SLOs, rollback, restore, DR, provenance, capacity, and risk acceptance are incomplete.

## Your mission

1. Decide whether the service is actually ready for production.
2. Close reliability, recovery, security, capacity, and ownership gaps.
3. Require accountable launch approval.

## Operational constraints

- No launch with unaccepted critical risk.
- Rollback and restore must be tested.
- Readiness is broader than deployment success.

## Start

```bash
./labctl start 040
./labctl status 040
```

Edit `.workspaces/040/` only.

## Files under your control

- `production-readiness.json`

## Evidence

- `review.txt`

## Completion

```bash
./labctl validate 040
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
