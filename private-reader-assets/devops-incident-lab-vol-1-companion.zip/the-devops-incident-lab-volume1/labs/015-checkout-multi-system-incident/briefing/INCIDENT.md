# Incident 015: Senior Challenge: Checkout Failed Across App, Database, and Queue

**Level:** Senior  
**Target time:** 100–160 minutes  
**Core skills:** multi-system reasoning, safe sequencing, feature flags, data integrity

## Situation

A checkout feature was enabled before a schema migration completed. Messages back up, retries duplicate work, and rollback risks incompatible writes.

## Your mission

1. Stabilize traffic without data loss.
2. Sequence feature flags, backward-compatible migration, queue control, deployment, and smoke tests.
3. Create a rollback checkpoint before reactivation.

## Operational constraints

- Zero data loss.
- No destructive database rollback.
- Keep a dead-letter path.
- Document the exact recovery order.

## Start the incident

```bash
./labctl start 015
./labctl status 015
```

Edit the files inside:

```text
.workspaces/015/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `feature-flags.json`
- `database.json`
- `queue.yaml`
- `change-plan.json`

## Evidence supplied

- `incident-timeline.json`
- `queue-depth.txt`
- `database-errors.txt`

## Completion standard

Run:

```bash
./labctl validate 015
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/015/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
