# Incident 024: The Deployment Credential That Expired at Release Time

**Level:** Advanced  
**Target time:** 50–80 minutes  
**Core skills:** OIDC, CI identity, AWS STS, least privilege

## Situation

A production release fails because a long-lived AWS key expired. The proposed fallback stores a new administrator key in CI.

## Your mission

1. Replace static credentials with OIDC.
2. Restrict trust to one repository and branch.
3. Bound permissions and session duration.

## Operational constraints

- No static fallback.
- No write-all repository permission.
- Assume one governed role.

## Start

```bash
./labctl start 024
./labctl status 024
```

Edit `.workspaces/024/` only.

## Files under your control

- `oidc-workflow.yaml`

## Evidence

- `auth-error.txt`

## Completion

```bash
./labctl validate 024
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
