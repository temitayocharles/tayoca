# Incident 026: The CDN That Kept Serving Yesterday’s Release

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** CDN caching, invalidation, checksums, release verification

## Situation

Origin files are correct, but users receive an old index page because HTML and hashed assets share the same long cache policy.

## Your mission

1. Separate mutable entry-point and immutable asset caching.
2. Invalidate only what must change.
3. Verify content through the CDN.

## Operational constraints

- Do not invalidate every asset.
- Keep hashed assets cacheable for a year.
- Prove edge content.

## Start

```bash
./labctl start 026
./labctl status 026
```

Edit `.workspaces/026/` only.

## Files under your control

- `cdn-release.yaml`

## Evidence

- `cdn-check.txt`

## Completion

```bash
./labctl validate 026
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
