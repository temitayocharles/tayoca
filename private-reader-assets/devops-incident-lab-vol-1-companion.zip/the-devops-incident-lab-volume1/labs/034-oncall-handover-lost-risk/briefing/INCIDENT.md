# Incident 034: The On-Call Handover That Lost an Unresolved Risk

**Level:** Intermediate  
**Target time:** 40–70 minutes  
**Core skills:** on-call handover, operational communication, risk ownership, continuity

## Situation

A degraded queue remains under observation, but the next shift receives only “all quiet” and no evidence, owner, or next check.

## Your mission

1. Carry unresolved incidents and known risks across shifts.
2. Assign ownership and next verification time.
3. Link evidence, rollback state, and customer impact.

## Operational constraints

- No vague “monitoring” statement.
- Receiver must acknowledge.
- Keep evidence links.

## Start

```bash
./labctl start 034
./labctl status 034
```

Edit `.workspaces/034/` only.

## Files under your control

- `handover.json`

## Evidence

- `handover-chat.txt`

## Completion

```bash
./labctl validate 034
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
