# Incident 004: The Secret That Never Reached the Cluster

**Level:** Intermediate  
**Target time:** 50–85 minutes  
**Core skills:** External Secrets, contract mapping, secret governance, rotation

## Situation

External Secrets reports reconciliation errors, and the application cannot resolve DB_PASSWORD. A rushed engineer proposes embedding the value in the Deployment.

## Your mission

1. Repair the governed secret store reference.
2. Align the generated Secret key with the Deployment contract.
3. Keep the value outside Git and preserve secret rotation.

## Operational constraints

- No plaintext secret values.
- No manually created static Secret.
- Keep hourly refresh.
- Use the governed production store.

## Start the incident

```bash
./labctl start 004
./labctl status 004
```

Edit the files inside:

```text
.workspaces/004/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `external-secret.yaml`
- `deployment.yaml`

## Evidence supplied

- `external-secret-status.txt`
- `pod-event.txt`

## Completion standard

Run:

```bash
./labctl validate 004
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/004/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
