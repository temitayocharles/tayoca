# Incident 007: The Rollback That Could Not Roll Back

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** rollback design, artifact retention, deployment evidence, recovery timing

## Situation

A release fails. The rollback job points to stable, but stable was overwritten by the bad build and the prior digest was never retained.

## Your mission

1. Create an immutable current and previous release chain.
2. Define a bounded rollback to a known digest.
3. Require rollback smoke tests and evidence.

## Operational constraints

- Do not rebuild the previous version.
- Do not use mutable tags.
- Do not call rollback complete before smoke validation.

## Start the incident

```bash
./labctl start 007
./labctl status 007
```

Edit the files inside:

```text
.workspaces/007/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `release-history.json`
- `pipeline.yaml`
- `deployment.yaml`

## Evidence supplied

- `release-history.txt`
- `rollback-log.txt`

## Completion standard

Run:

```bash
./labctl validate 007
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/007/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
