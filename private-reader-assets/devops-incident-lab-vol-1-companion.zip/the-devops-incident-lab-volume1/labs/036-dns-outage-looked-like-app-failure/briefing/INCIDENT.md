# Incident 036: The DNS Failure That Looked Like Every Application Failed

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** DNS reliability, synthetics, caching, runbooks

## Situation

A single cluster resolver fails. Applications report dependency timeouts, but no DNS-specific synthetic or runbook exists.

## Your mission

1. Remove the resolver single point.
2. Bound query retries and add caching.
3. Monitor DNS directly and document response.

## Operational constraints

- No infinite application retries.
- Keep TTL recovery-friendly.
- Use redundant resolvers.

## Start

```bash
./labctl start 036
./labctl status 036
```

Edit `.workspaces/036/` only.

## Files under your control

- `dns-reliability.yaml`

## Evidence

- `timeout-sample.txt`

## Completion

```bash
./labctl validate 036
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
