# Incident 035: The Disk With Plenty of Space but No Performance Left

**Level:** Advanced  
**Target time:** 60–95 minutes  
**Core skills:** IOPS, storage latency, queueing, benchmarking

## Situation

Database storage is only 40% full, yet I/O latency spikes because a small gp2 volume exhausts burst credits and queues thousands of writes.

## Your mission

1. Diagnose performance rather than capacity.
2. Provision independent IOPS and throughput.
3. Bound application queues and prove a storage baseline.

## Operational constraints

- Do not solve by adding disk capacity alone.
- Keep free-space headroom.
- Add actionable latency alerts.

## Start

```bash
./labctl start 035
./labctl status 035
```

Edit `.workspaces/035/` only.

## Files under your control

- `storage-performance.yaml`

## Evidence

- `storage-metrics.txt`

## Completion

```bash
./labctl validate 035
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
