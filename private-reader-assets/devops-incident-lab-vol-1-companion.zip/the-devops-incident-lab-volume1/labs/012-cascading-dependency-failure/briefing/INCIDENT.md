# Incident 012: The Dependency Failure That Took Down Healthy Services

**Level:** Advanced  
**Target time:** 65–100 minutes  
**Core skills:** circuit breakers, bulkheads, retry control, graceful degradation

## Situation

The tax service slows down. Five retries per request exhaust upstream pools, and otherwise healthy services begin failing.

## Your mission

1. Contain dependency pressure.
2. Introduce bounded retries, jitter, bulkheads, deadlines, and a circuit breaker.
3. Provide a controlled degraded response.

## Operational constraints

- Do not remove all failure handling.
- Do not increase global thread pools.
- Keep customer responses deterministic.

## Start the incident

```bash
./labctl start 012
./labctl status 012
```

Edit the files inside:

```text
.workspaces/012/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `resilience.yaml`

## Evidence supplied

- `dependency-graph.json`
- `retry-metrics.txt`

## Completion standard

Run:

```bash
./labctl validate 012
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/012/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
