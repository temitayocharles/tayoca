# Incident 033: The SLO That Stayed Green During a Checkout Outage

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** SLIs, SLOs, error budgets, synthetic monitoring

## Situation

The service reports 99.99% availability because the SLI counts a lightweight health endpoint while payment callbacks fail.

## Your mission

1. Measure the complete critical journey.
2. Define latency and availability indicators.
3. Drive fast and slow burn response.

## Operational constraints

- Do not count health checks as customer success.
- Include asynchronous completion.
- Keep a synthetic journey.

## Start

```bash
./labctl start 033
./labctl status 033
```

Edit `.workspaces/033/` only.

## Files under your control

- `slo.yaml`

## Evidence

- `incident.txt`

## Completion

```bash
./labctl validate 033
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
