# Incident 037: Senior Challenge: The Zero-Downtime Schema Migration

**Level:** Senior  
**Target time:** 100–160 minutes  
**Core skills:** database migration, expand-contract, backfill, rollback

## Situation

A migration drops an old column in the same release that introduces a replacement, while old application instances are still serving traffic.

## Your mission

1. Design an expand-and-contract sequence.
2. Keep every phase backward compatible.
3. Throttle backfill, verify parity, preserve rollback, and delay contract.

## Operational constraints

- No same-release destructive contract.
- Lock time under 500 ms.
- Prove zero downtime.

## Start

```bash
./labctl start 037
./labctl status 037
```

Edit `.workspaces/037/` only.

## Files under your control

- `migration-plan.json`

## Evidence

- `migration-error.txt`

## Completion

```bash
./labctl validate 037
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
