# Senior Engineer Walkthrough: Incident 037

Compare your workspace with `fixed-environment/` only after completing or abandoning the investigation.

```bash
diff -ru .workspaces/037 labs/037-zero-downtime-schema-migration/solution/fixed-environment
```

The reference is not merely a set of correct values. It demonstrates the minimum defensible production contract and the controls that prevent recurrence.
