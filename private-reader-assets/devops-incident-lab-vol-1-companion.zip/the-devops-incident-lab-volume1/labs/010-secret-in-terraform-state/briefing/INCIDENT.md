# Incident 010: The Secret That Terraform Remembered Forever

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** Terraform state security, secret references, state remediation, data classification

## Situation

A database password was passed into Terraform and now exists in local state, backups, and plan artifacts despite being marked sensitive.

## Your mission

1. Remove the value from Terraform configuration and state.
2. Model only a governed external secret reference.
3. Prevent outputs or declassification from reintroducing exposure.

## Operational constraints

- Sensitive is not sufficient if the value remains in state.
- Do not replace one plaintext variable with another.
- Do not expose the value through outputs.

## Start the incident

```bash
./labctl start 010
./labctl status 010
```

Edit the files inside:

```text
.workspaces/010/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `main.tf`
- `state.json`

## Evidence supplied

- `state-audit.txt`
- `plan-redaction.txt`

## Completion standard

Run:

```bash
./labctl validate 010
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/010/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
