variable "db_password" {
  type      = string
  sensitive = true
}

resource "terraform_data" "database_config" {
  input = { password = var.db_password }
}

output "db_password" {
  value     = var.db_password
  sensitive = true
}
