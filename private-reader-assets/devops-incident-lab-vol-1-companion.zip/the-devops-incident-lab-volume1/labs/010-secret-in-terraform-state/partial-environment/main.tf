variable "secret_arn" {
  type      = string
  sensitive = true
}

resource "terraform_data" "external_secret_reference" {
  input = { secret_arn = var.secret_arn }
}

data "aws_secretsmanager_secret" "database" {
  arn = var.secret_arn
}
