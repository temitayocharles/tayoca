# Incident 005: The Pipeline Was Green but Deployed the Wrong Image

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** immutable artifacts, digest pinning, release verification, provenance

## Situation

The pipeline is green, but production still runs yesterday’s checkout service. The release uses mutable tags and never verifies the running artifact.

## Your mission

1. Connect build output to deployment through one immutable digest.
2. Eliminate mutable-tag ambiguity.
3. Add deployed-digest verification and a user-facing smoke gate.

## Operational constraints

- Do not force a random restart.
- Do not use latest or stable tags.
- Record release provenance.

## Start the incident

```bash
./labctl start 005
./labctl status 005
```

Edit the files inside:

```text
.workspaces/005/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `artifact.json`
- `workflow.yaml`
- `deployment.yaml`

## Evidence supplied

- `pipeline-log.txt`
- `registry-inspection.txt`

## Completion standard

Run:

```bash
./labctl validate 005
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/005/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
