# Incident 018: Senior Challenge: The Fifteen-Minute Disaster Recovery Capstone

**Level:** Senior  
**Target time:** 120–180 minutes  
**Core skills:** DR orchestration, RTO/RPO, fencing, failover/failback

## Situation

The primary region is unavailable. DNS TTL is 30 minutes, replication lag is 12 minutes, and the runbook can promote without fencing the former primary.

## Your mission

1. Design and prove a failover that meets RTO 15 and RPO 5.
2. Prevent split brain.
3. Validate critical journeys after promotion.
4. Capture evidence and define failback.

## Operational constraints

- Primary fencing before promotion.
- Controlled approval.
- RTO ≤15 minutes.
- RPO ≤5 minutes.
- Full exercise evidence required.

## Start the incident

```bash
./labctl start 018
./labctl status 018
```

Edit the files inside:

```text
.workspaces/018/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `dr-plan.yaml`
- `failover-runbook.json`

## Evidence supplied

- `regional-status.json`
- `replication-lag.txt`
- `exercise-log.txt`

## Completion standard

Run:

```bash
./labctl validate 018
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/018/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
