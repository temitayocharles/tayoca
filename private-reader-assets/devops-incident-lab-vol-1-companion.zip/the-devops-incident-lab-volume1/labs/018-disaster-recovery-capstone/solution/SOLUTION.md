# Senior Engineer Walkthrough: Incident 018

This directory contains a reference remediation in `fixed-environment/`.

The intended learning outcome is not memorizing the changed values. It is learning to:

1. distinguish symptoms from causal faults;
2. reject shortcuts that restore service by weakening safety;
3. preserve production identities and rollback capability;
4. prove recovery through explicit gates;
5. document the decision so another engineer can audit it.

Compare the reference files with your workspace only after completing or intentionally abandoning your own investigation:

```bash
diff -ru .workspaces/018 labs/018-disaster-recovery-capstone/solution/fixed-environment
```

The automated validator encodes the minimum acceptable production outcome. Your written incident record should still explain why the remediation is correct and what prevents recurrence.
