moved {
  from = terraform_data.database["prod"]
  to   = terraform_data.database["production"]
}

moved {
  from = terraform_data.gateway["prod"]
  to   = terraform_data.gateway["production"]
}
