Rename environment key prod to production. No infrastructure replacement is approved.
