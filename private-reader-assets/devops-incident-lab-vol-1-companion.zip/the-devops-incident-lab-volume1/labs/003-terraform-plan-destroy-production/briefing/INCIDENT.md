# Incident 003: The Terraform Plan That Wanted to Destroy Production

**Level:** Intermediate  
**Target time:** 45–70 minutes  
**Core skills:** plan review, for_each identity, moved blocks, state safety

## Situation

A harmless naming cleanup changes for_each keys. Terraform now proposes destroying and recreating two production resources.

## Your mission

1. Explain why the resource addresses changed identity.
2. Represent the refactor with declarative state moves.
3. Prove the final plan contains no create or destroy actions.

## Operational constraints

- Do not use targeted apply.
- Do not manually edit state JSON.
- Do not accept replacement.
- Preserve both resource identities.

## Start the incident

```bash
./labctl start 003
./labctl status 003
```

Edit the files inside:

```text
.workspaces/003/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `migration.tf`

## Evidence supplied

- `initial-plan.txt`
- `change-request.md`

## Completion standard

Run:

```bash
./labctl validate 003
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/003/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
