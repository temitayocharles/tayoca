moved {
  from = terraform_data.database["prod"]
  to   = terraform_data.database["production"]
}
