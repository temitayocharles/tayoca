#!/usr/bin/env python3
from __future__ import annotations

import argparse
import contextlib
import http.server
import pathlib
import socket
import socketserver
import sys
import tempfile
import threading
import urllib.error
import urllib.request
from dataclasses import dataclass
from typing import Any

import yaml


@dataclass
class SimulationResult:
    phase: str
    reason: str
    exit_code: int


def load_documents(manifest_dir: pathlib.Path) -> dict[tuple[str, str], dict[str, Any]]:
    resources: dict[tuple[str, str], dict[str, Any]] = {}
    for path in sorted(manifest_dir.glob("*.yaml")):
        with path.open("r", encoding="utf-8") as handle:
            for doc in yaml.safe_load_all(handle):
                if not doc:
                    continue
                kind = str(doc.get("kind", ""))
                name = str(doc.get("metadata", {}).get("name", ""))
                if not kind or not name:
                    raise ValueError(f"{path}: every document requires kind and metadata.name")
                resources[(kind, name)] = doc
    return resources


def required(resources: dict[tuple[str, str], dict[str, Any]], kind: str, name: str) -> dict[str, Any]:
    try:
        return resources[(kind, name)]
    except KeyError as exc:
        raise ValueError(f"missing required resource {kind}/{name}") from exc


def first_container(deployment: dict[str, Any]) -> dict[str, Any]:
    containers = deployment.get("spec", {}).get("template", {}).get("spec", {}).get("containers", [])
    if not containers:
        raise ValueError("Deployment/payments-api has no container")
    return containers[0]


def probe_path(container: dict[str, Any], probe_name: str) -> str:
    return str(container.get(probe_name, {}).get("httpGet", {}).get("path", ""))


def normalize_key(path: str) -> str:
    return path.lstrip("/") or "index.html"


def simulate(resources: dict[tuple[str, str], dict[str, Any]]) -> SimulationResult:
    runtime = required(resources, "ConfigMap", "payments-runtime").get("data", {})
    content = required(resources, "ConfigMap", "payments-content").get("data", {})
    deployment = required(resources, "Deployment", "payments-api")
    container = first_container(deployment)

    app_env = str(runtime.get("APP_ENV", ""))
    if app_env != "production":
        return SimulationResult(
            phase="CrashLoopBackOff",
            reason=f"container exited 42: APP_ENV={app_env!r} is rejected",
            exit_code=10,
        )

    live_path = probe_path(container, "livenessProbe")
    if normalize_key(live_path) not in content:
        return SimulationResult(
            phase="RunningButRestarting",
            reason=f"liveness probe {live_path or '<missing>'} returns 404 and kubelet restarts the process",
            exit_code=11,
        )

    ready_path = probe_path(container, "readinessProbe")
    if normalize_key(ready_path) not in content:
        return SimulationResult(
            phase="RunningNotReady",
            reason=f"readiness probe {ready_path or '<missing>'} returns 404",
            exit_code=12,
        )

    return SimulationResult(phase="Healthy", reason="startup and health contracts are satisfied", exit_code=0)


def validate_policy(resources: dict[tuple[str, str], dict[str, Any]]) -> list[tuple[bool, str]]:
    deployment = required(resources, "Deployment", "payments-api")
    service = required(resources, "Service", "payments-api")
    runtime = required(resources, "ConfigMap", "payments-runtime").get("data", {})
    content = required(resources, "ConfigMap", "payments-content").get("data", {})
    spec = deployment.get("spec", {})
    pod_spec = spec.get("template", {}).get("spec", {})
    container = first_container(deployment)
    security = container.get("securityContext", {})
    pod_security = pod_spec.get("securityContext", {})

    checks: list[tuple[bool, str]] = [
        (spec.get("replicas") == 2, "Deployment preserves two replicas"),
        (runtime.get("APP_ENV") == "production", "Runtime environment uses production"),
        (container.get("image") == "busybox:1.36.1", "Original application image is preserved"),
        (probe_path(container, "readinessProbe") == "/ready", "Readiness probe preserves /ready"),
        (probe_path(container, "livenessProbe") == "/healthz", "Liveness probe preserves /healthz"),
        (str(content.get("healthz", "")).strip() == "PAYMENTS_LIVE", "Liveness resource returns PAYMENTS_LIVE"),
        (pod_security.get("runAsNonRoot") is True, "Pod remains non-root"),
        (security.get("allowPrivilegeEscalation") is False, "Privilege escalation remains disabled"),
        (security.get("privileged") is not True, "Container remains non-privileged"),
        (service.get("spec", {}).get("type", "ClusterIP") == "ClusterIP", "Service remains ClusterIP"),
    ]
    return checks


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, fmt: str, *args: object) -> None:
        return


@contextlib.contextmanager
def serve_content(content: dict[str, Any]):
    with tempfile.TemporaryDirectory(prefix="incident-002-http-") as temp_dir:
        root = pathlib.Path(temp_dir)
        for key, value in content.items():
            (root / key).write_text(str(value), encoding="utf-8")

        class Handler(QuietHandler):
            def __init__(self, *args: object, **kwargs: object) -> None:
                super().__init__(*args, directory=str(root), **kwargs)

        with socketserver.TCPServer(("127.0.0.1", 0), Handler) as server:
            thread = threading.Thread(target=server.serve_forever, daemon=True)
            thread.start()
            try:
                yield server.server_address[1]
            finally:
                server.shutdown()
                thread.join(timeout=5)


def fetch(port: int, path: str) -> str:
    with urllib.request.urlopen(f"http://127.0.0.1:{port}{path}", timeout=3) as response:
        return response.read().decode("utf-8").strip()


def command_inspect(manifest_dir: pathlib.Path) -> int:
    resources = load_documents(manifest_dir)
    result = simulate(resources)
    print(f"PHASE: {result.phase}")
    print(f"REASON: {result.reason}")
    return result.exit_code


def command_validate(manifest_dir: pathlib.Path) -> int:
    resources = load_documents(manifest_dir)
    simulation = simulate(resources)
    checks = validate_policy(resources)

    if simulation.phase == "Healthy":
        checks.append((True, "Simulated restart count remains stable"))
    else:
        checks.append((False, f"Workload is not stable: {simulation.phase}"))

    content = required(resources, "ConfigMap", "payments-content").get("data", {})
    if simulation.phase == "Healthy":
        try:
            with serve_content(content) as port:
                checks.append((fetch(port, "/") == "PAYMENTS_API_OK", "User-facing endpoint returns PAYMENTS_API_OK"))
                checks.append((fetch(port, "/ready") == "PAYMENTS_READY", "Readiness endpoint returns PAYMENTS_READY"))
                checks.append((fetch(port, "/healthz") == "PAYMENTS_LIVE", "Liveness endpoint returns PAYMENTS_LIVE"))
        except (OSError, urllib.error.URLError, socket.timeout) as exc:
            checks.append((False, f"HTTP simulation failed: {exc}"))
    else:
        checks.extend([
            (False, "User-facing endpoint is reachable"),
            (False, "Readiness endpoint is reachable"),
            (False, "Liveness endpoint is reachable"),
        ])

    passed = 0
    failed = 0
    for ok, label in checks:
        if ok:
            print(f"PASS: {label}")
            passed += 1
        else:
            print(f"FAIL: {label}")
            failed += 1

    print(f"\nScore: {passed} passed, {failed} failed")
    if failed:
        return 1
    print("SIMULATED INCIDENT 002 COMPLETE")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Deterministic Incident 002 Kubernetes behavior simulator")
    parser.add_argument("command", choices=("inspect", "validate"))
    parser.add_argument("manifest_dir", type=pathlib.Path)
    args = parser.parse_args()

    try:
        if args.command == "inspect":
            return command_inspect(args.manifest_dir)
        return command_validate(args.manifest_dir)
    except (ValueError, yaml.YAMLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
