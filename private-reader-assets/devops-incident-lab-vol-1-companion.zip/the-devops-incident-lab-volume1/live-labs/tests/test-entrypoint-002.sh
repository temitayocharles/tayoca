#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DEPLOYMENT="$ROOT_DIR/labs/002-pod-would-not-stay-alive/broken-environment/deployment.yaml"
WORK_DIR="$(mktemp -d -t incident-002-entrypoint.XXXXXX)"
HTTP_PID=""
cleanup() {
  if [[ -n "$HTTP_PID" ]]; then
    kill "$HTTP_PID" >/dev/null 2>&1 || true
    wait "$HTTP_PID" 2>/dev/null || true
  fi
  rm -rf "$WORK_DIR"
}
trap cleanup EXIT

mkdir -p "$WORK_DIR/bin" "$WORK_DIR/www"
chmod 755 "$WORK_DIR" "$WORK_DIR/bin" "$WORK_DIR/www"
ln -s /usr/bin/busybox "$WORK_DIR/bin/httpd"
printf 'PAYMENTS_API_OK\n' > "$WORK_DIR/www/index.html"
printf 'PAYMENTS_READY\n' > "$WORK_DIR/www/ready"
chmod 644 "$WORK_DIR/www/"*

ENTRYPOINT="$(python3 - "$DEPLOYMENT" "$WORK_DIR/www" <<'PY'
import pathlib, sys, yaml
path = pathlib.Path(sys.argv[1])
www = sys.argv[2]
doc = yaml.safe_load(path.read_text())
script = doc["spec"]["template"]["spec"]["containers"][0]["command"][2]
print(script.replace("/www", www), end="")
PY
)"

PORT="$(python3 - <<'PY'
import socket
s = socket.socket()
s.bind(("127.0.0.1", 0))
print(s.getsockname()[1])
s.close()
PY
)"

printf '[entrypoint] Invalid APP_ENV must exit 42\n'
set +e
PATH="$WORK_DIR/bin:$PATH" APP_ENV=prod PORT="$PORT" \
  setpriv --reuid=10001 --regid=10001 --clear-groups /bin/sh -ec "$ENTRYPOINT" \
  >"$WORK_DIR/invalid.log" 2>&1
rc=$?
set -e
cat "$WORK_DIR/invalid.log"
[[ "$rc" -eq 42 ]] || { echo "TEST FAILURE: expected exit 42, got $rc"; exit 1; }

printf '\n[entrypoint] Correct APP_ENV starts the non-root HTTP process\n'
PATH="$WORK_DIR/bin:$PATH" APP_ENV=production PORT="$PORT" \
  setpriv --reuid=10001 --regid=10001 --clear-groups /bin/sh -ec "$ENTRYPOINT" \
  >"$WORK_DIR/server.log" 2>&1 &
HTTP_PID=$!

for _ in {1..30}; do
  if curl -fsS --max-time 1 "http://127.0.0.1:$PORT/" >"$WORK_DIR/root.out" 2>/dev/null; then
    break
  fi
  sleep 0.1
done

grep -Fq 'PAYMENTS_API_OK' "$WORK_DIR/root.out" || { echo "TEST FAILURE: root endpoint did not serve expected body"; exit 1; }
curl -fsS --max-time 1 "http://127.0.0.1:$PORT/ready" | grep -Fq 'PAYMENTS_READY'

printf '\n[entrypoint] Missing /healthz reproduces the liveness 404\n'
set +e
curl -fsS --max-time 1 "http://127.0.0.1:$PORT/healthz" >"$WORK_DIR/live.out" 2>/dev/null
health_rc=$?
set -e
[[ "$health_rc" -ne 0 ]] || { echo "TEST FAILURE: missing healthz unexpectedly succeeded"; exit 1; }

printf '\n[entrypoint] Adding healthz repairs the live process contract\n'
printf 'PAYMENTS_LIVE\n' > "$WORK_DIR/www/healthz"
chmod 644 "$WORK_DIR/www/healthz"
curl -fsS --max-time 1 "http://127.0.0.1:$PORT/healthz" | grep -Fq 'PAYMENTS_LIVE'

kill -0 "$HTTP_PID" >/dev/null 2>&1 || { echo "TEST FAILURE: HTTP process stopped unexpectedly"; exit 1; }

echo "ENTRYPOINT INTEGRATION: PASS"
