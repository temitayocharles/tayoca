#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LAB_DIR="$ROOT_DIR/labs/003-terraform-plan-destroy-production"
SIMULATOR="$ROOT_DIR/tests/simulate-incident-003.py"
WORK_DIR="$(mktemp -d -t incident-003-test.XXXXXX)"
LOG_FILE="${INCIDENT_003_TEST_LOG:-$LAB_DIR/evidence/sandbox-test-report.txt}"
cleanup() { rm -rf "$WORK_DIR"; }
trap cleanup EXIT
exec > >(tee "$LOG_FILE") 2>&1

STATE="$WORK_DIR/state.json"
DESIRED="$LAB_DIR/evidence/desired-model.json"
MIGRATION="$WORK_DIR/migration.tf"
cp "$LAB_DIR/evidence/state-model.json" "$STATE"
cp "$LAB_DIR/broken-environment/migration.tf" "$MIGRATION"

expect_summary() {
  local add="$1" change="$2" destroy="$3"
  local output rc
  set +e
  output="$(python3 "$SIMULATOR" plan "$STATE" "$DESIRED" "$MIGRATION" 2>&1)"
  rc=$?
  set -e
  printf '%s\n' "$output"
  grep -Fq "Plan: $add to add, $change to change, $destroy to destroy." <<<"$output"
  [[ "$rc" -eq 2 || "$rc" -eq 0 ]]
}

echo "Incident 003 sandbox lifecycle test"
echo "UTC: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo

echo "[1/7] Reproduce the dangerous refactor plan"
expect_summary 2 0 2

echo
echo "[2/7] Add only one moved block and prove the repair is incomplete"
cat >> "$MIGRATION" <<'HCL'

moved {
  from = terraform_data.database["prod"]
  to   = terraform_data.database["production"]
}
HCL
expect_summary 1 1 1
set +e
python3 "$SIMULATOR" validate "$STATE" "$DESIRED" "$MIGRATION"
partial_rc=$?
set -e
[[ "$partial_rc" -ne 0 ]] || { echo "TEST FAILURE: partial migration unexpectedly passed"; exit 1; }

echo
echo "[3/7] Add the second declarative address migration"
cat >> "$MIGRATION" <<'HCL'

moved {
  from = terraform_data.gateway["prod"]
  to   = terraform_data.gateway["production"]
}
HCL
expect_summary 0 2 0

echo
echo "[4/7] Validate all migration and safety gates"
python3 "$SIMULATOR" validate "$STATE" "$DESIRED" "$MIGRATION"

echo
echo "[5/7] Apply the simulated migration and preserve object IDs"
MIGRATED="$WORK_DIR/migrated-state.json"
python3 "$SIMULATOR" apply "$STATE" "$DESIRED" "$MIGRATION" --output "$MIGRATED"
python3 - "$STATE" "$MIGRATED" <<'PY'
import json, sys
before=json.load(open(sys.argv[1]))["resources"]
after=json.load(open(sys.argv[2]))["resources"]
assert sorted(v["id"] for v in before.values()) == sorted(v["id"] for v in after.values())
assert sorted(after) == [
    'terraform_data.database["production"]',
    'terraform_data.gateway["production"]',
]
print("PASS: migrated state preserved IDs and contains only production addresses")
PY

echo
echo "[6/7] Prove the post-migration plan is empty"
set +e
post_output="$(python3 "$SIMULATOR" plan "$MIGRATED" "$DESIRED" "$MIGRATION" 2>&1)"
post_rc=$?
set -e
printf '%s\n' "$post_output"
[[ "$post_rc" -eq 0 ]]
grep -Fq "Plan: 0 to add, 0 to change, 0 to destroy." <<<"$post_output"

echo
echo "[7/7] Reset and prove the dangerous plan is reproducible"
cp "$LAB_DIR/evidence/state-model.json" "$STATE"
cp "$LAB_DIR/broken-environment/migration.tf" "$MIGRATION"
expect_summary 2 0 2

echo
echo "Checking shell syntax..."
for script in "$ROOT_DIR/labctl" "$ROOT_DIR/scripts/"*.sh "$ROOT_DIR/labs/"*/validators/*.sh "$ROOT_DIR/tests/"*.sh; do
  bash -n "$script"
done

echo "Checking Python syntax..."
python3 -m py_compile "$SIMULATOR"

echo
echo "RESULT: PASS"
echo "The dangerous plan, partial migration, complete migration, apply, stable post-plan, and reset all behaved as designed."
