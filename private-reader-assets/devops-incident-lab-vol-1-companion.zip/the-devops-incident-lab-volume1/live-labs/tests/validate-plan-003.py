#!/usr/bin/env python3
from __future__ import annotations

import json
import pathlib
import sys
from typing import Any

EXPECTED = {
    'terraform_data.database["prod"]': 'terraform_data.database["production"]',
    'terraform_data.gateway["prod"]': 'terraform_data.gateway["production"]',
}


def load(path: pathlib.Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def main() -> int:
    if len(sys.argv) != 2:
        print("usage: validate-plan-003.py PLAN_JSON", file=sys.stderr)
        return 2
    payload = load(pathlib.Path(sys.argv[1]))
    changes = payload.get("resource_changes", [])
    relevant = {
        str(change.get("address")): change
        for change in changes
        if str(change.get("address", "")).startswith("terraform_data.")
    }

    destructive: list[str] = []
    creations: list[str] = []
    moves: dict[str, str] = {}
    for address, change in relevant.items():
        actions = list(change.get("change", {}).get("actions", []))
        if "delete" in actions:
            destructive.append(address)
        if "create" in actions:
            creations.append(address)
        previous = change.get("previous_address")
        if previous:
            moves[str(previous)] = address

    checks = [
        (not destructive, f"Plan contains no delete actions{': ' + ', '.join(destructive) if destructive else ''}"),
        (not creations, f"Plan contains no create actions{': ' + ', '.join(creations) if creations else ''}"),
        (moves == EXPECTED, "Plan recognizes both declarative address migrations"),
        (set(relevant) == set(EXPECTED.values()), "Plan manages exactly the two production addresses"),
    ]

    passed = failed = 0
    for ok, label in checks:
        if ok:
            print(f"PASS: {label}")
            passed += 1
        else:
            print(f"FAIL: {label}")
            failed += 1
    print(f"PLAN JSON GATES: {passed} passed, {failed} failed")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    raise SystemExit(main())
