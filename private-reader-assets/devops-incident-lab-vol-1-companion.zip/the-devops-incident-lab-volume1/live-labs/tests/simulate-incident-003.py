#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import pathlib
import re
import sys
from dataclasses import dataclass
from typing import Any

ADDRESS_RE = re.compile(r'terraform_data\.(?:database|gateway)\["(?:prod|production)"\]')
MOVED_RE = re.compile(
    r"moved\s*\{\s*from\s*=\s*(terraform_data\.(?:database|gateway)\[\"(?:prod|production)\"\])"
    r"\s*to\s*=\s*(terraform_data\.(?:database|gateway)\[\"(?:prod|production)\"\])\s*\}",
    re.DOTALL,
)

EXPECTED_MOVES = {
    'terraform_data.database["prod"]': 'terraform_data.database["production"]',
    'terraform_data.gateway["prod"]': 'terraform_data.gateway["production"]',
}


@dataclass(frozen=True)
class PlanAction:
    action: str
    address: str
    previous_address: str | None = None
    object_id: str | None = None


def load_json(path: pathlib.Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def parse_moves(path: pathlib.Path) -> dict[str, str]:
    text = path.read_text(encoding="utf-8")
    return {old: new for old, new in MOVED_RE.findall(text)}


def plan(state: dict[str, Any], desired: list[str], moves: dict[str, str]) -> list[PlanAction]:
    resources = state.get("resources", {})
    actions: list[PlanAction] = []
    satisfied: set[str] = set()

    for old_address, metadata in resources.items():
        target = moves.get(old_address)
        if target in desired:
            actions.append(
                PlanAction(
                    action="move_update",
                    address=target,
                    previous_address=old_address,
                    object_id=str(metadata.get("id", "")),
                )
            )
            satisfied.add(target)
        elif old_address in desired:
            actions.append(PlanAction(action="no_change", address=old_address, object_id=str(metadata.get("id", ""))))
            satisfied.add(old_address)
        else:
            actions.append(PlanAction(action="destroy", address=old_address, object_id=str(metadata.get("id", ""))))

    for address in desired:
        if address not in satisfied:
            actions.append(PlanAction(action="create", address=address))

    return sorted(actions, key=lambda item: (item.action, item.address))


def counts(actions: list[PlanAction]) -> dict[str, int]:
    return {
        "create": sum(item.action == "create" for item in actions),
        "change": sum(item.action == "move_update" for item in actions),
        "destroy": sum(item.action == "destroy" for item in actions),
        "no_change": sum(item.action == "no_change" for item in actions),
    }


def print_plan(actions: list[PlanAction]) -> None:
    for item in actions:
        if item.action == "move_update":
            print(f'MOVE: {item.previous_address} -> {item.address} id={item.object_id}')
        else:
            print(f'{item.action.upper()}: {item.address}' + (f' id={item.object_id}' if item.object_id else ""))
    summary = counts(actions)
    print(
        f'Plan: {summary["create"]} to add, {summary["change"]} to change, '
        f'{summary["destroy"]} to destroy.'
    )


def apply_actions(state: dict[str, Any], actions: list[PlanAction]) -> dict[str, Any]:
    original = state.get("resources", {})
    updated: dict[str, Any] = {}
    for item in actions:
        if item.action == "move_update" and item.previous_address:
            updated[item.address] = dict(original[item.previous_address])
        elif item.action == "no_change":
            updated[item.address] = dict(original[item.address])
        elif item.action == "create":
            updated[item.address] = {"id": f"new-{abs(hash(item.address)) % 100000:05d}"}
    return {"resources": updated}


def validate(state: dict[str, Any], desired: list[str], moves: dict[str, str]) -> tuple[int, dict[str, Any] | None]:
    actions = plan(state, desired, moves)
    summary = counts(actions)
    checks = [
        (moves == EXPECTED_MOVES, "Both address migrations are declared exactly"),
        (summary["destroy"] == 0, "Plan contains no destroy actions"),
        (summary["create"] == 0, "Plan contains no create actions"),
        (summary["change"] == 2, "Both existing objects are migrated in place"),
    ]

    old_ids = sorted(str(value.get("id")) for value in state.get("resources", {}).values())
    applied = apply_actions(state, actions) if all(ok for ok, _ in checks) else None
    if applied is not None:
        new_ids = sorted(str(value.get("id")) for value in applied.get("resources", {}).values())
        checks.extend(
            [
                (sorted(applied.get("resources", {}).keys()) == sorted(desired), "Final state contains only production addresses"),
                (old_ids == new_ids, "Object IDs are preserved"),
                (
                    all(item.action == "no_change" for item in plan(applied, desired, moves)),
                    "Post-migration plan is empty",
                ),
            ]
        )

    passed = failed = 0
    for ok, label in checks:
        if ok:
            print(f"PASS: {label}")
            passed += 1
        else:
            print(f"FAIL: {label}")
            failed += 1
    print(f"\nScore: {passed} passed, {failed} failed")
    return (0 if failed == 0 else 1), applied


def main() -> int:
    parser = argparse.ArgumentParser(description="Incident 003 deterministic Terraform address-migration simulator")
    parser.add_argument("command", choices=("plan", "validate", "apply"))
    parser.add_argument("state", type=pathlib.Path)
    parser.add_argument("desired", type=pathlib.Path)
    parser.add_argument("migration", type=pathlib.Path)
    parser.add_argument("--output", type=pathlib.Path)
    args = parser.parse_args()

    try:
        state = load_json(args.state)
        desired_payload = load_json(args.desired)
        desired = [str(item) for item in desired_payload.get("addresses", [])]
        moves = parse_moves(args.migration)
        actions = plan(state, desired, moves)

        if args.command == "plan":
            print_plan(actions)
            return 2 if any(item.action != "no_change" for item in actions) else 0

        rc, applied = validate(state, desired, moves)
        if args.command == "apply" and rc == 0 and applied is not None:
            if args.output is None:
                raise ValueError("--output is required for apply")
            args.output.write_text(json.dumps(applied, indent=2) + "\n", encoding="utf-8")
            print(f"SIMULATED STATE WRITTEN: {args.output}")
        return rc
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
