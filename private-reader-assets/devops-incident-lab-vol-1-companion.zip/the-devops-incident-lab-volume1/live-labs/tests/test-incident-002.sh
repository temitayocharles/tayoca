#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
SOURCE_DIR="$ROOT_DIR/labs/002-pod-would-not-stay-alive/broken-environment"
SIMULATOR="$ROOT_DIR/tests/simulate-incident-002.py"
WORK_DIR="$(mktemp -d -t incident-002-test.XXXXXX)"
LOG_FILE="${INCIDENT_002_TEST_LOG:-$ROOT_DIR/labs/002-pod-would-not-stay-alive/evidence/sandbox-test-report.txt}"
cleanup() { rm -rf "$WORK_DIR"; }
trap cleanup EXIT

exec > >(tee "$LOG_FILE") 2>&1

copy_broken_state() {
  rm -rf "$WORK_DIR/manifests"
  mkdir -p "$WORK_DIR/manifests"
  cp "$SOURCE_DIR"/*.yaml "$WORK_DIR/manifests/"
}

expect_inspect() {
  local expected_rc="$1"
  local expected_phase="$2"
  local output rc
  set +e
  output="$(python3 "$SIMULATOR" inspect "$WORK_DIR/manifests" 2>&1)"
  rc=$?
  set -e
  printf '%s\n' "$output"
  [[ "$rc" -eq "$expected_rc" ]] || { echo "TEST FAILURE: expected inspect exit $expected_rc, got $rc"; exit 1; }
  grep -Fq "PHASE: $expected_phase" <<<"$output" || { echo "TEST FAILURE: expected phase $expected_phase"; exit 1; }
}

echo "Incident 002 sandbox lifecycle test"
echo "UTC: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo

copy_broken_state

echo "[1/6] Verify original manifests reproduce the startup CrashLoopBackOff"
expect_inspect 10 "CrashLoopBackOff"

echo
echo "[2/6] Apply the obvious runtime configuration repair"
python3 - "$WORK_DIR/manifests/runtime-config.yaml" <<'PY'
import pathlib, sys, yaml
path = pathlib.Path(sys.argv[1])
doc = yaml.safe_load(path.read_text())
doc["data"]["APP_ENV"] = "production"
path.write_text(yaml.safe_dump(doc, sort_keys=False))
PY
expect_inspect 11 "RunningButRestarting"

echo
echo "[3/6] Confirm the first repair is insufficient"
set +e
python3 "$SIMULATOR" validate "$WORK_DIR/manifests"
first_fix_rc=$?
set -e
[[ "$first_fix_rc" -ne 0 ]] || { echo "TEST FAILURE: incomplete repair unexpectedly passed"; exit 1; }

echo
echo "[4/6] Apply the second repair by supplying the liveness resource"
python3 - "$WORK_DIR/manifests/content-config.yaml" <<'PY'
import pathlib, sys, yaml
path = pathlib.Path(sys.argv[1])
doc = yaml.safe_load(path.read_text())
doc.setdefault("data", {})["healthz"] = "PAYMENTS_LIVE\n"
path.write_text(yaml.safe_dump(doc, sort_keys=False))
PY
expect_inspect 0 "Healthy"

echo
echo "[5/6] Run all policy, stability, and HTTP-contract validation gates"
python3 "$SIMULATOR" validate "$WORK_DIR/manifests"

echo
echo "[6/6] Reset to the original broken state and prove reproducibility"
copy_broken_state
expect_inspect 10 "CrashLoopBackOff"

echo
echo
echo "Running extracted BusyBox entrypoint integration..."
"$ROOT_DIR/tests/test-entrypoint-002.sh"

echo "Checking shell syntax..."
for script in "$ROOT_DIR/labctl" "$ROOT_DIR/scripts/"*.sh "$ROOT_DIR/labs/"*/validators/*.sh "$ROOT_DIR/tests/"*.sh; do
  bash -n "$script"
done

echo "Checking Python syntax..."
python3 -m py_compile "$SIMULATOR"

echo
echo "RESULT: PASS"
echo "The broken state, partial repair, full repair, validation, and reset lifecycle all behaved as designed."
