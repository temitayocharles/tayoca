# Incident 002 Postmortem

## Summary

Describe what users experienced and how long the workload remained unavailable.

## Impact

- Affected service:
- Affected environment:
- User-visible effect:
- Detection method:

## Timeline

| Time | Event | Evidence |
|---|---|---|
| | Deployment accepted | |
| | First failure observed | |
| | First hypothesis tested | |
| | Secondary failure identified | |
| | Recovery validated | |

## Root causes

### Startup failure

State the exact configuration defect and why the process exited.

### Restart-loop failure

State the exact liveness failure and why Kubernetes restarted an otherwise running process.

## Contributing factors

Explain why CI reported success and why the first repair did not fully resolve the incident.

## Corrective actions

| Action | Type | Owner | Verification |
|---|---|---|---|
| | Prevent | | |
| | Detect | | |
| | Mitigate | | |

## Senior-engineer reflection

- What evidence separated the two failures?
- Which tempting shortcuts would have restored a green dashboard while increasing risk?
- What should the deployment pipeline validate before promotion?
