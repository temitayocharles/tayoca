# Senior Engineer Walkthrough: Incident 002

Do not read this until you have completed or intentionally abandoned the investigation.

## Failure sequence

This incident contains two independent defects.

### Root cause 1: invalid runtime environment

`payments-runtime` sets `APP_ENV` to `prod`, but the process accepts only `production`. The entrypoint exits with code 42 before starting the HTTP server. Kubernetes restarts the container, producing the first CrashLoopBackOff.

Repair:

```yaml
data:
  APP_ENV: production
  PORT: "8080"
```

### Root cause 2: missing liveness resource

After the startup value is corrected, the HTTP server starts and `/ready` succeeds. However, the liveness probe requests `/healthz`, and the mounted content ConfigMap does not provide that file. BusyBox returns 404. Kubelet then kills and restarts the healthy process.

Repair:

```yaml
data:
  index.html: |
    PAYMENTS_API_OK
  ready: |
    PAYMENTS_READY
  healthz: |
    PAYMENTS_LIVE
```

Apply both ConfigMaps and restart the Deployment so the corrected configuration is loaded immediately:

```bash
kubectl apply -f labs/002-pod-would-not-stay-alive/broken-environment/runtime-config.yaml
kubectl apply -f labs/002-pod-would-not-stay-alive/broken-environment/content-config.yaml
kubectl -n incident-002 rollout restart deployment/payments-api
kubectl -n incident-002 rollout status deployment/payments-api --timeout=120s
./labctl validate 002
```

## Why the shortcuts are unsafe

Removing the liveness probe hides a broken health contract. Raising thresholds delays detection without correcting the endpoint. Running as root, reducing replicas, or exposing the Service externally changes the risk profile and does not address either root cause.

## Pipeline prevention

A stronger pipeline would perform:

1. schema and policy checks;
2. rollout completion checks;
3. restart-count and Pod-condition checks;
4. Service endpoint verification;
5. readiness and liveness smoke tests;
6. a stability observation window before promotion.
