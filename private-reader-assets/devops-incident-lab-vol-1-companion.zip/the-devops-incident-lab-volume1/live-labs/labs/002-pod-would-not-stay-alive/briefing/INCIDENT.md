# Incident 002: The Pod That Would Not Stay Alive

## Severity

SEV-2. The payment status API is unavailable in the staging environment immediately before a production promotion window.

## What changed

A configuration cleanup was merged and deployed. CI reported success because every manifest was accepted by the Kubernetes API.

## Current symptoms

- The Deployment requests two replicas but never becomes Available.
- Pods repeatedly restart.
- The first visible error appears to point to an environment configuration problem.
- Engineers report that correcting the obvious configuration value still does not stabilize the workload.
- The Service remains internal and must not be changed to NodePort or LoadBalancer.

## Mission

Restore the workload without weakening its safety controls.

You must:

1. determine why the container exits during startup;
2. identify the second failure that appears after the startup defect is repaired;
3. preserve two replicas;
4. preserve both readiness and liveness probes;
5. preserve the non-root, least-privilege container configuration;
6. prove that restart counts stop increasing;
7. prove that the Service and both health endpoints work;
8. record the root causes and preventive actions.

## Constraints

You may edit only files in `broken-environment/`.

You may not:

- remove either health probe;
- increase probe failure thresholds merely to hide the failure;
- change the Service to NodePort or LoadBalancer;
- run the container as root or privileged;
- reduce the Deployment below two replicas;
- replace the application with a different image;
- hard-code a bypass that skips runtime validation.

## Useful commands

```bash
./labctl status 002
kubectl -n incident-002 get pods
kubectl -n incident-002 describe pod <pod-name>
kubectl -n incident-002 logs <pod-name>
kubectl -n incident-002 logs <pod-name> --previous
kubectl -n incident-002 get events --sort-by=.metadata.creationTimestamp
```

After editing the manifests, apply the changes and restart the rollout if needed:

```bash
kubectl apply -f labs/002-pod-would-not-stay-alive/broken-environment/
kubectl -n incident-002 rollout restart deployment/payments-api
kubectl -n incident-002 rollout status deployment/payments-api --timeout=120s
./labctl validate 002
```

## Completion standard

A running Pod is not enough. The incident is complete only when all automated gates pass and restart counts remain stable during the validation window.
