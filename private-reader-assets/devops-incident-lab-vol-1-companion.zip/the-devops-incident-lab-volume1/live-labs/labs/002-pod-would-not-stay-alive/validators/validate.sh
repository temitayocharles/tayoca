#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
NAMESPACE="incident-002"
source "$ROOT_DIR/scripts/common.sh"
require_commands
kubectl config use-context "kind-$CLUSTER_NAME" >/dev/null

PASS=0
FAIL=0
pass() { echo "PASS: $1"; PASS=$((PASS+1)); }
fail() { echo "FAIL: $1"; FAIL=$((FAIL+1)); }

jsonpath() {
  kubectl -n "$NAMESPACE" get "$1" "$2" -o "jsonpath=$3" 2>/dev/null || true
}

sum_restarts() {
  kubectl -n "$NAMESPACE" get pods -l app=payments-api \
    -o jsonpath='{range .items[*].status.containerStatuses[*]}{.restartCount}{"\n"}{end}' 2>/dev/null \
    | awk '{sum += $1} END {print sum+0}'
}

echo "Validating Incident 002..."

replicas="$(jsonpath deployment payments-api '{.spec.replicas}')"
[[ "$replicas" == "2" ]] && pass "Deployment preserves two replicas" || fail "Deployment must use exactly two replicas"

app_env="$(jsonpath configmap payments-runtime '{.data.APP_ENV}')"
[[ "$app_env" == "production" ]] && pass "Runtime environment uses the accepted production value" || fail "payments-runtime APP_ENV must be production"

image="$(jsonpath deployment payments-api '{.spec.template.spec.containers[0].image}')"
[[ "$image" == "busybox:1.36.1" ]] && pass "Original application image is preserved" || fail "Application image must remain busybox:1.36.1"

readiness_path="$(jsonpath deployment payments-api '{.spec.template.spec.containers[0].readinessProbe.httpGet.path}')"
[[ "$readiness_path" == "/ready" ]] && pass "Readiness probe preserves /ready" || fail "Readiness probe must exist and use /ready"

liveness_path="$(jsonpath deployment payments-api '{.spec.template.spec.containers[0].livenessProbe.httpGet.path}')"
[[ "$liveness_path" == "/healthz" ]] && pass "Liveness probe preserves /healthz" || fail "Liveness probe must exist and use /healthz"

readiness_port="$(jsonpath deployment payments-api '{.spec.template.spec.containers[0].readinessProbe.httpGet.port}')"
liveness_port="$(jsonpath deployment payments-api '{.spec.template.spec.containers[0].livenessProbe.httpGet.port}')"
if [[ "$readiness_port" == "http" && "$liveness_port" == "http" ]]; then
  pass "Both probes target the named application port"
else
  fail "Both probes must target the named http port"
fi

health_content="$(jsonpath configmap payments-content '{.data.healthz}')"
[[ "$health_content" == *"PAYMENTS_LIVE"* ]] && pass "Liveness resource is supplied by application content" || fail "payments-content must provide healthz containing PAYMENTS_LIVE"

run_as_non_root="$(jsonpath deployment payments-api '{.spec.template.spec.securityContext.runAsNonRoot}')"
privileged="$(jsonpath deployment payments-api '{.spec.template.spec.containers[0].securityContext.privileged}')"
allow_escalation="$(jsonpath deployment payments-api '{.spec.template.spec.containers[0].securityContext.allowPrivilegeEscalation}')"
if [[ "$run_as_non_root" == "true" && "$privileged" != "true" && "$allow_escalation" == "false" ]]; then
  pass "Least-privilege container controls remain enforced"
else
  fail "Container must remain non-root, non-privileged, and deny privilege escalation"
fi

service_type="$(jsonpath service payments-api '{.spec.type}')"
[[ -z "$service_type" || "$service_type" == "ClusterIP" ]] && pass "Service remains internal ClusterIP" || fail "Service must remain ClusterIP"

if kubectl -n "$NAMESPACE" rollout status deployment/payments-api --timeout=120s >/dev/null 2>&1; then
  pass "Deployment rollout completed"
else
  fail "Deployment rollout did not complete"
fi

ready_replicas="$(jsonpath deployment payments-api '{.status.readyReplicas}')"
[[ "$ready_replicas" == "2" ]] && pass "Both replicas are Ready" || fail "Expected 2 Ready replicas, found ${ready_replicas:-0}"

endpoint_count="$(kubectl -n "$NAMESPACE" get endpointslice -l kubernetes.io/service-name=payments-api -o jsonpath='{range .items[*].endpoints[*]}{.conditions.ready}{"\n"}{end}' 2>/dev/null | grep -c '^true$' || true)"
[[ "$endpoint_count" -ge 2 ]] && pass "Service has at least two ready endpoints" || fail "Service does not have two ready endpoints"

before_restarts="$(sum_restarts)"
sleep 12
after_restarts="$(sum_restarts)"
if [[ "$before_restarts" == "$after_restarts" ]]; then
  pass "Restart count remained stable during the observation window"
else
  fail "Restart count increased from $before_restarts to $after_restarts"
fi

PF_LOG="$(mktemp)"
ROOT_RESPONSE="$(mktemp)"
LIVE_RESPONSE="$(mktemp)"
kubectl -n "$NAMESPACE" port-forward service/payments-api 18082:80 >"$PF_LOG" 2>&1 &
PF_PID=$!
cleanup() {
  kill "$PF_PID" >/dev/null 2>&1 || true
  rm -f "$PF_LOG" "$ROOT_RESPONSE" "$LIVE_RESPONSE"
}
trap cleanup EXIT

for _ in {1..20}; do
  if curl -fsS --max-time 2 http://127.0.0.1:18082/ >"$ROOT_RESPONSE" 2>/dev/null; then
    break
  fi
  sleep 0.5
done
curl -fsS --max-time 2 http://127.0.0.1:18082/healthz >"$LIVE_RESPONSE" 2>/dev/null || true

root_body="$(cat "$ROOT_RESPONSE" 2>/dev/null || true)"
live_body="$(cat "$LIVE_RESPONSE" 2>/dev/null || true)"
[[ "$root_body" == *"PAYMENTS_API_OK"* ]] && pass "User-facing request succeeds through the Service" || fail "Service root response did not return PAYMENTS_API_OK"
[[ "$live_body" == *"PAYMENTS_LIVE"* ]] && pass "Liveness endpoint succeeds through the Service" || fail "Service liveness response did not return PAYMENTS_LIVE"

echo
echo "Score: $PASS passed, $FAIL failed"
if [[ "$FAIL" -gt 0 ]]; then
  exit 1
fi

echo "INCIDENT 002 COMPLETE"
