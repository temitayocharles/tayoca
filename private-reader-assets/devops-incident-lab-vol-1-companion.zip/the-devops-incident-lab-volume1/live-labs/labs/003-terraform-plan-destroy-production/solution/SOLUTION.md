# Senior Engineer Walkthrough: Incident 003

Open this only after completing or intentionally abandoning the lab.

## Root cause

A Terraform resource instance address includes its `for_each` key. Changing the key from `prod` to `production` therefore changes both addresses:

- `terraform_data.database["prod"]` becomes `terraform_data.database["production"]`
- `terraform_data.gateway["prod"]` becomes `terraform_data.gateway["production"]`

Without migration declarations, Terraform interprets the old addresses as removed and the new addresses as unrelated resources.

## Safe repair

Add these declarations to `broken-environment/migration.tf`:

```hcl
moved {
  from = terraform_data.database["prod"]
  to   = terraform_data.database["production"]
}

moved {
  from = terraform_data.gateway["prod"]
  to   = terraform_data.gateway["production"]
}
```

Then inspect the plan:

```bash
./labctl status 003
```

The plan may update the `input.environment` value in place, but it must contain no create or delete action. Run the controlled validation and apply sequence:

```bash
./labctl validate 003
```

## Why the obvious alternatives are rejected

- `prevent_destroy` blocks the plan but does not teach Terraform that the addresses represent the same objects.
- `ignore_changes` suppresses attribute differences, not address identity changes.
- manual state editing is fragile, unaudited, and unnecessary.
- `terraform state mv` can be valid during an operator-led emergency, but a checked-in `moved` block is preferable here because every environment and reviewer receives the same migration intent.
- `-target` produces a partial plan and can hide related changes.

## Production prevention controls

A production pipeline should parse the plan JSON and require explicit approval when any action contains `delete`, `create`, or `replace`. Refactors involving `count`, `for_each`, module paths, or resource names should include state-address migration review as a mandatory checklist item.
