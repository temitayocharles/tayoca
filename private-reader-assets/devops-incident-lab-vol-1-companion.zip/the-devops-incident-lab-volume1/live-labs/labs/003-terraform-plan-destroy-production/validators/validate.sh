#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
LAB_DIR="$ROOT_DIR/labs/003-terraform-plan-destroy-production"
source "$ROOT_DIR/scripts/terraform-common.sh"
TF="$(terraform_command)"
WORK_DIR="$(incident_003_work_dir "$ROOT_DIR")"
PLAN_FILE="$WORK_DIR/safe-migration.tfplan"
PLAN_JSON="$WORK_DIR/safe-migration.json"
BEFORE_JSON="$WORK_DIR/state-before.json"
AFTER_JSON="$WORK_DIR/state-after.json"

if [[ ! -d "$WORK_DIR/.terraform" || ! -f "$WORK_DIR/terraform.tfstate" ]]; then
  echo "Incident 003 has not been started. Run: ./labctl start 003" >&2
  exit 1
fi

sync_incident_003_config "$ROOT_DIR" "$WORK_DIR"

PASS=0
FAIL=0
pass() { echo "PASS: $1"; PASS=$((PASS+1)); }
fail() { echo "FAIL: $1"; FAIL=$((FAIL+1)); }

if python3 - "$LAB_DIR/broken-environment/migration.tf" <<'PYCODE'
import pathlib, re, sys
text = pathlib.Path(sys.argv[1]).read_text()
pattern = re.compile(
    r'moved\s*\{\s*from\s*=\s*(terraform_data\.(?:database|gateway)\["(?:prod|production)"\])'
    r'\s*to\s*=\s*(terraform_data\.(?:database|gateway)\["(?:prod|production)"\])\s*\}',
    re.S,
)
actual = dict(pattern.findall(text))
expected = {
    'terraform_data.database["prod"]': 'terraform_data.database["production"]',
    'terraform_data.gateway["prod"]': 'terraform_data.gateway["production"]',
}
raise SystemExit(0 if actual == expected else 1)
PYCODE
then
  pass "Both migrations are declared in source control"
else
  fail "migration.tf must declare both prod-to-production moved blocks"
fi

if grep -Eq 'prevent_destroy|ignore_changes|removed[[:space:]]*\{' "$LAB_DIR/broken-environment/"*.tf; then
  fail "Lifecycle or removal workarounds are not permitted"
else
  pass "No lifecycle or removal workaround hides the address change"
fi

(
  cd "$WORK_DIR"
  "$TF" show -json >"$BEFORE_JSON"
)

set +e
(
  cd "$WORK_DIR"
  "$TF" plan -input=false -no-color -out="$PLAN_FILE"
)
plan_rc=$?
set -e
if [[ "$plan_rc" -ne 0 ]]; then
  fail "Terraform could not produce a migration plan"
  echo
  echo "Score: $PASS passed, $FAIL failed"
  exit 1
fi
pass "Terraform produced an executable migration plan"

(
  cd "$WORK_DIR"
  "$TF" show -json "$PLAN_FILE" >"$PLAN_JSON"
)
if python3 "$ROOT_DIR/tests/validate-plan-003.py" "$PLAN_JSON"; then
  pass "Plan JSON passes destructive-action and move gates"
else
  fail "Plan JSON contains unsafe or incomplete actions"
fi

if [[ "$FAIL" -gt 0 ]]; then
  echo
  echo "Score: $PASS passed, $FAIL failed"
  echo "The plan was not applied. Repair migration.tf and validate again."
  exit 1
fi

(
  cd "$WORK_DIR"
  "$TF" apply -input=false -no-color -auto-approve "$PLAN_FILE" >/dev/null
  "$TF" show -json >"$AFTER_JSON"
)
pass "Safe migration plan applied"

if python3 - "$BEFORE_JSON" "$AFTER_JSON" <<'PYCODE'
import json, sys

def resources(payload):
    return {
        item["address"]: item.get("values", {})
        for item in payload.get("values", {}).get("root_module", {}).get("resources", [])
        if item.get("address", "").startswith("terraform_data.")
    }

before = resources(json.load(open(sys.argv[1])))
after = resources(json.load(open(sys.argv[2])))
expected = {
    'terraform_data.database["production"]',
    'terraform_data.gateway["production"]',
}
assert set(after) == expected, (set(after), expected)
assert sorted(v.get("id") for v in before.values()) == sorted(v.get("id") for v in after.values())
print("Final addresses and object IDs are correct")
PYCODE
then
  pass "Final state uses production addresses and preserves both object IDs"
else
  fail "Final state addresses or object IDs are incorrect"
fi

set +e
(
  cd "$WORK_DIR"
  "$TF" plan -input=false -no-color -detailed-exitcode >/dev/null
)
post_rc=$?
set -e
if [[ "$post_rc" -eq 0 ]]; then
  pass "Post-migration plan reports no changes"
else
  fail "Post-migration plan is not empty"
fi

echo
echo "Score: $PASS passed, $FAIL failed"
if [[ "$FAIL" -gt 0 ]]; then
  exit 1
fi

echo "INCIDENT 003 COMPLETE"
