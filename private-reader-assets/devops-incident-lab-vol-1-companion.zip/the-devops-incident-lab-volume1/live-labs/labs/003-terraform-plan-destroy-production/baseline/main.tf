terraform {
  required_version = ">= 1.4.0"
}

locals {
  environment_key = "prod"
}

resource "terraform_data" "database" {
  for_each = toset([local.environment_key])

  input = {
    name        = "orders-database"
    environment = each.key
    critical    = true
  }
}

resource "terraform_data" "gateway" {
  for_each = toset([local.environment_key])

  input = {
    name        = "public-gateway"
    environment = each.key
    critical    = true
  }
}

output "managed_resource_addresses" {
  value = concat(
    [for key in keys(terraform_data.database) : "terraform_data.database[\"${key}\"]"],
    [for key in keys(terraform_data.gateway) : "terraform_data.gateway[\"${key}\"]"]
  )
}
