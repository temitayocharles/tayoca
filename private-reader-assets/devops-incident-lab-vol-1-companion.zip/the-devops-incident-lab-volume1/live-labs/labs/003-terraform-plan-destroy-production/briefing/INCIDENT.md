# Incident 003: The Terraform Plan That Wanted to Destroy Production

## Severity

SEV-1 change risk: an approved naming refactor proposes replacing two production-critical resources.

## Situation

A pull request standardizes the environment key from `prod` to `production`. CI is green because Terraform configuration validation passed, but the generated plan proposes destroying the existing orders database and public gateway before creating resources under their new addresses.

The change window begins shortly. The application owner believes this is only a naming cleanup. You are the senior engineer reviewing the final plan.

This lab uses Terraform's built-in `terraform_data` resource and local state. It creates no cloud resources and requires no provider credentials.

## Mission

Preserve the identity of both managed objects, codify the address migration, produce a plan with no create or delete actions, apply the safe migration, and prove the resulting state is stable.

## Operational constraints

- Do not apply a plan containing a delete action.
- Do not edit the Terraform state JSON manually.
- Do not delete and re-import resources.
- Do not remove the resources from configuration.
- Do not use `prevent_destroy`, `ignore_changes`, or `-target` to conceal the address problem.
- Keep the new `production` naming standard.
- The migration must be declarative and reviewable in source control.

## Required actions

1. Start the lab and inspect the proposed plan.
2. Explain why a naming-only refactor changes resource identity when `for_each` keys change.
3. Add the required migration declarations to `broken-environment/migration.tf`.
4. Prove that the revised plan contains no create or delete actions.
5. Apply the safe migration through the validator.
6. Prove that the final state contains only the `production` addresses.
7. Prove a subsequent plan reports no changes.
8. Complete the change review in `postmortem/CHANGE-REVIEW-TEMPLATE.md`.

## Definition of done

The incident is complete only when both object IDs are preserved, the old addresses are absent, the new addresses are managed, no destructive action is proposed, and a post-migration plan is empty.
