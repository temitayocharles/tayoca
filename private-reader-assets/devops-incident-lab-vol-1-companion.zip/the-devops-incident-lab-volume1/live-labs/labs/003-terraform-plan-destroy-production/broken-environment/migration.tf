# The refactor is incomplete. Codify the state-address migration here.
#
# Requirements:
# - preserve both existing resource identities;
# - use declarative Terraform moved blocks;
# - do not edit the state file manually;
# - do not hide the proposed destruction with lifecycle workarounds.
