# Incident 003 Change Review

## Executive decision

State whether the original plan should be approved, rejected, or revised and why.

## Proposed business change

Explain the requested naming standard in plain language.

## Destructive actions detected

| Resource address | Proposed action | Business risk |
|---|---|---|
| | | |
| | | |

## Root cause

Explain how Terraform instance addresses and `for_each` keys caused the destructive plan.

## Evidence collected

1.
2.
3.

## Safe migration

Document the declarations added and why they preserve identity.

## Validation evidence

- Create actions before repair:
- Delete actions before repair:
- Create actions after repair:
- Delete actions after repair:
- Preserved object IDs:
- Final state addresses:
- Post-migration plan result:

## Unsafe alternatives rejected

Document at least two shortcuts and why they were rejected.

## Preventive controls

| Control | Pipeline stage | Owner | Proof |
|---|---|---|---|
| Parse plan JSON for destructive actions | Plan | | |
| Require migration review for address changes | Review | | |
| Archive plan and approval evidence | Release | | |
