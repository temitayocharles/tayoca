# Change request CR-1842

## Requested change

Standardize the production environment key from `prod` to `production` across the infrastructure repository.

## Business constraints

- The orders database and public gateway are production-critical.
- Their existing Terraform identities and object IDs must be preserved.
- No replacement window has been approved.
- The change must remain reviewable and reproducible through source control.
- The deployment pipeline must reject any plan containing a delete action.

## Reviewer note

The pull request author described this as “a label-only cleanup” and approved the generated plan without expanding its resource actions.
