# Incident 001 Postmortem

## Executive summary

Describe what failed, who was affected, and how service was restored.

## Timeline

| Time | Event |
|---|---|
| 14:03 | Pipeline reported success |
| 14:07 | Customer impact reported |
|  | Investigation began |
|  | Root cause confirmed |
|  | Remediation applied |
|  | Validation completed |

## Customer impact

State the observable impact without internal jargon.

## Evidence collected

1. 
2. 
3. 

## Root cause

Separate the primary technical causes from contributing process failures.

## Remediation

Document exactly what changed and why it was safe.

## Validation evidence

- Deployment status:
- Ready replicas:
- Service endpoints:
- User-facing response:
- Validator result:

## Unsafe alternatives rejected

Describe at least one tempting shortcut and why you rejected it.

## Corrective and preventive actions

| Action | Owner | Priority | Verification |
|---|---|---|---|
| Add rollout gate |  |  |  |
| Add endpoint validation |  |  |  |
| Add user-facing smoke test |  |  |  |

## What would make this incident harder in production?

Consider traffic, rollback, observability, security, dependencies, and organizational pressure.
