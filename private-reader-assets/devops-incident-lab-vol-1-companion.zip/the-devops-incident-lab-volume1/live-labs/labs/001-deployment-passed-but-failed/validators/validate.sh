#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
source "$ROOT_DIR/scripts/common.sh"
require_commands
kubectl config use-context "kind-$CLUSTER_NAME" >/dev/null

PASS=0
FAIL=0

pass() { echo "PASS: $1"; PASS=$((PASS+1)); }
fail() { echo "FAIL: $1"; FAIL=$((FAIL+1)); }

jsonpath() {
  kubectl -n "$NAMESPACE" get "$1" "$2" -o "jsonpath=$3" 2>/dev/null || true
}

echo "Validating Incident 001..."

replicas="$(jsonpath deployment storefront '{.spec.replicas}')"
[[ "$replicas" == "2" ]] && pass "Deployment preserves two replicas" || fail "Deployment must use exactly two replicas"

probe_path="$(jsonpath deployment storefront '{.spec.template.spec.containers[0].readinessProbe.httpGet.path}')"
[[ "$probe_path" == "/ready" ]] && pass "Readiness probe checks the real readiness endpoint" || fail "Readiness probe must exist and use /ready"

probe_port="$(jsonpath deployment storefront '{.spec.template.spec.containers[0].readinessProbe.httpGet.port}')"
[[ "$probe_port" == "http" || "$probe_port" == "8080" ]] && pass "Readiness probe targets the application port" || fail "Readiness probe targets an invalid port"

target_port="$(jsonpath service storefront '{.spec.ports[0].targetPort}')"
[[ "$target_port" == "http" || "$target_port" == "8080" ]] && pass "Service targets the application port" || fail "Service targetPort must be http or 8080"

service_type="$(jsonpath service storefront '{.spec.type}')"
[[ -z "$service_type" || "$service_type" == "ClusterIP" ]] && pass "Service remains internal ClusterIP" || fail "Service must remain ClusterIP"

if kubectl -n "$NAMESPACE" rollout status deployment/storefront --timeout=90s >/dev/null 2>&1; then
  pass "Deployment rollout completed"
else
  fail "Deployment rollout did not complete"
fi

ready_replicas="$(jsonpath deployment storefront '{.status.readyReplicas}')"
[[ "$ready_replicas" == "2" ]] && pass "Both replicas are Ready" || fail "Expected 2 Ready replicas, found ${ready_replicas:-0}"

endpoint_count="$(kubectl -n "$NAMESPACE" get endpointslice -l kubernetes.io/service-name=storefront -o jsonpath='{range .items[*].endpoints[*]}{.conditions.ready}{"\n"}{end}' 2>/dev/null | grep -c '^true$' || true)"
[[ "$endpoint_count" -ge 2 ]] && pass "Service has at least two ready endpoints" || fail "Service does not have two ready endpoints"

PF_LOG="$(mktemp)"
kubectl -n "$NAMESPACE" port-forward service/storefront 18080:80 >"$PF_LOG" 2>&1 &
PF_PID=$!
cleanup() { kill "$PF_PID" >/dev/null 2>&1 || true; rm -f "$PF_LOG"; }
trap cleanup EXIT

for _ in {1..20}; do
  if curl -fsS --max-time 2 http://127.0.0.1:18080/ >/tmp/incident-001-response.txt 2>/dev/null; then
    break
  fi
  sleep 0.5
done

response="$(cat /tmp/incident-001-response.txt 2>/dev/null || true)"
[[ "$response" == *"STORE_FRONT_OK"* ]] && pass "User-facing request succeeds through the Service" || fail "Service request did not return STORE_FRONT_OK"
rm -f /tmp/incident-001-response.txt

echo
echo "Score: $PASS passed, $FAIL failed"
if [[ "$FAIL" -gt 0 ]]; then
  exit 1
fi

echo "INCIDENT 001 COMPLETE"
