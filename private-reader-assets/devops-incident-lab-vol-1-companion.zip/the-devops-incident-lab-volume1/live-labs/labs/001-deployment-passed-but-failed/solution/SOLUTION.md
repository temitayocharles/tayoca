# Senior Engineer Walkthrough

Open this only after completing the lab or intentionally ending your attempt.

## Root causes

1. The readiness probe requests `/healthz`, but the application exposes `/ready`. Kubernetes therefore keeps both Pods out of the Ready state.
2. The Service sends traffic to port `8081`, while the container listens on `8080`. Even if the Pods became Ready, the Service would still route to the wrong destination port.
3. The pipeline treats successful API acceptance as successful delivery. It performs no rollout check, endpoint check, or smoke test.

## Safe repair

In `deployment.yaml`, change:

```yaml
readinessProbe:
  httpGet:
    path: /ready
    port: http
```

In `service.yaml`, change:

```yaml
ports:
  - name: http
    port: 80
    targetPort: http
```

Apply the repaired files and wait for rollout completion:

```bash
kubectl apply -f labs/001-deployment-passed-but-failed/broken-environment/deployment.yaml
kubectl apply -f labs/001-deployment-passed-but-failed/broken-environment/service.yaml
kubectl -n incident-001 rollout status deployment/storefront --timeout=90s
```

Then run:

```bash
./labctl validate 001
```

## Why obvious shortcuts are rejected

Deleting the readiness probe can make Pods appear available before the application is ready. Directly port-forwarding to a Pod proves only Pod reachability, not Service routing. Reducing replicas changes resilience rather than repairing the incident. Changing the image avoids diagnosing the deployed configuration.

## Pipeline prevention controls

A production pipeline should fail unless all of the following pass:

```bash
kubectl -n incident-001 rollout status deployment/storefront --timeout=90s
kubectl -n incident-001 get endpointslice -l kubernetes.io/service-name=storefront
# Run an authenticated, environment-appropriate smoke test through the real service path.
```

The exact smoke-test path depends on the environment, but API acceptance alone must never be treated as proof of successful delivery.
