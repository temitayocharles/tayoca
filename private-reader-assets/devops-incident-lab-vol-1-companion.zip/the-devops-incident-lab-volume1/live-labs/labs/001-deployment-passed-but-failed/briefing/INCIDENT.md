# Incident 001: The Deployment That Passed but Never Worked

## Severity

SEV-2: The deployment pipeline is green, but customers cannot reach the storefront.

## Situation

At 14:03, the release pipeline reported success after applying a routine Kubernetes change. At 14:07, support reported that customers were receiving connection failures. The application team insists the image is healthy because it runs locally.

You are the on-call DevOps engineer. The release owner is unavailable. You have access to the cluster and repository, but you may not rebuild the application image.

## Mission

Restore the storefront safely and produce evidence that the service is genuinely healthy.

## Operational constraints

- Do not delete or disable the readiness probe.
- Do not replace the application with a different image.
- Do not use `hostNetwork`, `NodePort`, or privileged containers.
- Preserve two replicas.
- Do not bypass the Service by treating direct Pod access as the final solution.
- Keep changes limited to the lab manifests.

## Required actions

1. Inspect the deployed state before changing anything.
2. Record at least two evidence items that explain why the pipeline was green while the service was unavailable.
3. Repair the deployment and service configuration.
4. Prove that both replicas become Ready.
5. Prove the Service has healthy endpoints.
6. Prove a request through the Service returns `STORE_FRONT_OK`.
7. Complete the incident record in `postmortem/POSTMORTEM-TEMPLATE.md`.
8. Run `./labctl validate 001` and pass every gate.

## Suggested evidence sources

You decide what to inspect. Useful sources may include:

- Deployment rollout state
- Pod conditions and events
- Container logs
- Service configuration
- EndpointSlice data
- In-cluster or port-forwarded requests
- Differences between declared and observed state

## Definition of done

The incident is not complete because a command returned successfully. It is complete when the application is reachable through its Service, operational safeguards remain intact, validation passes, and your reasoning is documented.
