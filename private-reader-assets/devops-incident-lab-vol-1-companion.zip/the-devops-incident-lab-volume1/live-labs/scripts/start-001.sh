#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT_DIR/scripts/common.sh"
require_commands

if ! docker info >/dev/null 2>&1; then
  echo "Docker is not available. Start the container runtime and try again." >&2
  exit 1
fi

if ! cluster_exists; then
  echo "Creating KIND cluster: $CLUSTER_NAME"
  kind create cluster --name "$CLUSTER_NAME" --wait 90s
else
  echo "Using existing KIND cluster: $CLUSTER_NAME"
fi

kubectl config use-context "kind-$CLUSTER_NAME" >/dev/null
kubectl delete namespace "$NAMESPACE" --ignore-not-found --wait=true >/dev/null

MANIFEST_DIR="$ROOT_DIR/labs/001-deployment-passed-but-failed/broken-environment"

# This intentionally simulates a weak CI/CD job: apply succeeds, therefore the job reports success.
echo "Running deployment pipeline simulation..."
kubectl apply -f "$MANIFEST_DIR/namespace.yaml"
kubectl apply -f "$MANIFEST_DIR/configmap.yaml"
kubectl apply -f "$MANIFEST_DIR/deployment.yaml"
kubectl apply -f "$MANIFEST_DIR/service.yaml"

echo
echo "PIPELINE RESULT: SUCCESS"
echo "The manifests were accepted by the Kubernetes API. No rollout or user-facing smoke test was performed."
echo
echo "Incident briefing:"
echo "  $ROOT_DIR/labs/001-deployment-passed-but-failed/briefing/INCIDENT.md"
