#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT_DIR/scripts/terraform-common.sh"
TF="$(terraform_command)"
WORK_DIR="$(incident_003_work_dir "$ROOT_DIR")"

if [[ ! -d "$WORK_DIR/.terraform" || ! -f "$WORK_DIR/terraform.tfstate" ]]; then
  echo "Incident 003 has not been started. Run: ./labctl start 003" >&2
  exit 1
fi

sync_incident_003_config "$ROOT_DIR" "$WORK_DIR"

echo "=== Current state addresses and IDs ==="
(
  cd "$WORK_DIR"
  "$TF" state list
  "$TF" show -json | python3 -c '
import json, sys
payload=json.load(sys.stdin)
for item in payload.get("values",{}).get("root_module",{}).get("resources",[]):
    print(f"{item.get(\"address\")}: id={item.get(\"values\",{}).get(\"id\")}")
'
)

echo
echo "=== Proposed plan ==="
set +e
(
  cd "$WORK_DIR"
  "$TF" plan -input=false -no-color -detailed-exitcode
)
rc=$?
set -e
[[ "$rc" -ne 1 ]] || exit 1
exit 0
