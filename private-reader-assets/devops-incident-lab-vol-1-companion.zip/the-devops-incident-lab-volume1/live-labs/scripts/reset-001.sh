#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT_DIR/scripts/common.sh"
require_commands
kubectl config use-context "kind-$CLUSTER_NAME" >/dev/null
kubectl delete namespace "$NAMESPACE" --ignore-not-found --wait=true >/dev/null
exec "$ROOT_DIR/scripts/start-001.sh"
