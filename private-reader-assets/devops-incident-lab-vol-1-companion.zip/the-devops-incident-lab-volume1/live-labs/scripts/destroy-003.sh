#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT_DIR/scripts/terraform-common.sh"
WORK_DIR="$(incident_003_work_dir "$ROOT_DIR")"
rm -rf "$WORK_DIR"
echo "Removed Incident 003 local state: $WORK_DIR"
