#!/usr/bin/env bash
set -euo pipefail

terraform_command() {
  if command -v terraform >/dev/null 2>&1; then
    printf '%s\n' terraform
    return 0
  fi
  if command -v tofu >/dev/null 2>&1; then
    printf '%s\n' tofu
    return 0
  fi
  echo "Terraform or OpenTofu is required for the live Incident 003 lab." >&2
  return 1
}

incident_003_work_dir() {
  local root_dir="$1"
  printf '%s\n' "${INCIDENT_003_WORK_DIR:-$root_dir/.work/incident-003}"
}

sync_incident_003_config() {
  local root_dir="$1"
  local work_dir="$2"
  local source_dir="$root_dir/labs/003-terraform-plan-destroy-production/broken-environment"
  cp "$source_dir/main.tf" "$work_dir/main.tf"
  cp "$source_dir/migration.tf" "$work_dir/migration.tf"
}
