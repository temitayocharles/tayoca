#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT_DIR/scripts/terraform-common.sh"
TF="$(terraform_command)"
WORK_DIR="$(incident_003_work_dir "$ROOT_DIR")"
LAB_DIR="$ROOT_DIR/labs/003-terraform-plan-destroy-production"

rm -rf "$WORK_DIR"
mkdir -p "$WORK_DIR"
cp "$LAB_DIR/baseline/main.tf" "$WORK_DIR/main.tf"

printf 'Creating the pre-refactor production state with %s...\n' "$TF"
(
  cd "$WORK_DIR"
  "$TF" init -backend=false -input=false -no-color >/dev/null
  "$TF" apply -auto-approve -input=false -no-color >/dev/null
)

sync_incident_003_config "$ROOT_DIR" "$WORK_DIR"

set +e
(
  cd "$WORK_DIR"
  "$TF" plan -input=false -no-color -detailed-exitcode
)
plan_rc=$?
set -e

if [[ "$plan_rc" -eq 1 ]]; then
  echo "Terraform could not produce the incident plan." >&2
  exit 1
fi

echo
echo "CHANGE PIPELINE RESULT: APPROVED"
echo "Configuration validation passed, but the destructive plan was not blocked."
echo
echo "Incident briefing:"
echo "  $LAB_DIR/briefing/INCIDENT.md"
echo
echo "Edit the declarative migration file:"
echo "  $LAB_DIR/broken-environment/migration.tf"
