#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NAMESPACE="incident-002"
source "$ROOT_DIR/scripts/common.sh"
require_commands
kubectl config use-context "kind-$CLUSTER_NAME" >/dev/null

echo "=== Workloads ==="
kubectl -n "$NAMESPACE" get deployment,pods -o wide || true

echo
echo "=== Service and EndpointSlices ==="
kubectl -n "$NAMESPACE" get service,endpointslices || true

echo
echo "=== Current container logs ==="
kubectl -n "$NAMESPACE" logs -l app=payments-api --all-containers=true --prefix --tail=20 2>/dev/null || true

echo
echo "=== Previous container logs ==="
for pod in $(kubectl -n "$NAMESPACE" get pods -l app=payments-api -o name 2>/dev/null); do
  kubectl -n "$NAMESPACE" logs "$pod" --previous --tail=20 2>/dev/null || true
done

echo
echo "=== Recent events ==="
kubectl -n "$NAMESPACE" get events --sort-by=.metadata.creationTimestamp | tail -n 30 || true
