#!/usr/bin/env bash
set -euo pipefail

CLUSTER_NAME="${CLUSTER_NAME:-devops-incident-lab}"
NAMESPACE="${NAMESPACE:-incident-001}"

require_commands() {
  local missing=0
  for cmd in kind kubectl docker curl; do
    if ! command -v "$cmd" >/dev/null 2>&1; then
      echo "Missing required command: $cmd" >&2
      missing=1
    fi
  done
  [[ "$missing" -eq 0 ]]
}

cluster_exists() {
  kind get clusters 2>/dev/null | grep -Fxq "$CLUSTER_NAME"
}
