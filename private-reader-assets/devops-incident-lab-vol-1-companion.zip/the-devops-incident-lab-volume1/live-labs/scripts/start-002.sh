#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NAMESPACE="incident-002"
source "$ROOT_DIR/scripts/common.sh"
require_commands

if ! docker info >/dev/null 2>&1; then
  echo "Docker is not available. Start the container runtime and try again." >&2
  exit 1
fi

if ! cluster_exists; then
  echo "Creating KIND cluster: $CLUSTER_NAME"
  kind create cluster --name "$CLUSTER_NAME" --wait 90s
else
  echo "Using existing KIND cluster: $CLUSTER_NAME"
fi

kubectl config use-context "kind-$CLUSTER_NAME" >/dev/null
kubectl delete namespace "$NAMESPACE" --ignore-not-found --wait=true >/dev/null

MANIFEST_DIR="$ROOT_DIR/labs/002-pod-would-not-stay-alive/broken-environment"

echo "Running deployment pipeline simulation..."
kubectl apply -f "$MANIFEST_DIR/namespace.yaml"
kubectl apply -f "$MANIFEST_DIR/runtime-config.yaml"
kubectl apply -f "$MANIFEST_DIR/content-config.yaml"
kubectl apply -f "$MANIFEST_DIR/deployment.yaml"
kubectl apply -f "$MANIFEST_DIR/service.yaml"

echo
echo "PIPELINE RESULT: SUCCESS"
echo "The manifests were accepted. No rollout, restart-stability, or health-contract test was performed."
echo
echo "Incident briefing:"
echo "  $ROOT_DIR/labs/002-pod-would-not-stay-alive/briefing/INCIDENT.md"
