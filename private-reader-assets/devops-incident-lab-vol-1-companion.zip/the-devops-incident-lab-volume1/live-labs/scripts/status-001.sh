#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
source "$ROOT_DIR/scripts/common.sh"
require_commands

kubectl config use-context "kind-$CLUSTER_NAME" >/dev/null

echo "=== Workloads ==="
kubectl -n "$NAMESPACE" get deployments,pods -o wide || true

echo
echo "=== Service and endpoints ==="
kubectl -n "$NAMESPACE" get svc,endpoints,endpointslices || true

echo
echo "=== Recent events ==="
kubectl -n "$NAMESPACE" get events --sort-by=.metadata.creationTimestamp | tail -n 20 || true
