#!/usr/bin/env bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NAMESPACE="incident-002"
source "$ROOT_DIR/scripts/common.sh"
require_commands
if cluster_exists; then
  kubectl config use-context "kind-$CLUSTER_NAME" >/dev/null
  kubectl delete namespace "$NAMESPACE" --ignore-not-found --wait=true
else
  echo "Cluster does not exist: $CLUSTER_NAME"
fi
