# The DevOps Incident Lab

**No Theories. Roll Up Your Sleeves, Grab Your Coffee, and Get Your Hands Dirty.**

This repository contains action-first incident simulations. Each lab requires you to investigate, change a real environment, validate the repair, and document your decisions.

## Lab standard

**Perform. Decide. Prove. Document.**

## Available incidents

| ID | Incident | Core skills |
|---|---|---|
| 001 | The Deployment That Passed but Never Worked | readiness, Service routing, rollout validation |
| 002 | The Pod That Would Not Stay Alive | CrashLoopBackOff, previous logs, liveness, restart stability |
| 003 | The Terraform Plan That Wanted to Destroy Production | plan review, `for_each` identity, moved blocks, state-safe refactoring |

## Requirements

### Kubernetes incidents 001 and 002

- Docker or another container runtime supported by KIND
- `kind`
- `kubectl`
- `bash`
- `curl`

### Terraform incident 003

- Terraform 1.4+ or a compatible OpenTofu release
- `python3`
- `bash`

Incident 003 uses Terraform's built-in `terraform_data` resource. It creates no cloud infrastructure, downloads no provider, and requires no credentials.

## Standard workflow

```bash
./labctl start <ID>
./labctl status <ID>
# Investigate and repair the lab files.
./labctl validate <ID>
```

Reset or remove an incident:

```bash
./labctl reset <ID>
./labctl destroy <ID>
```

## Incident 003 workflow

```bash
./labctl start 003
./labctl status 003
```

Read:

```text
labs/003-terraform-plan-destroy-production/briefing/INCIDENT.md
```

Repair the declarative migration file:

```text
labs/003-terraform-plan-destroy-production/broken-environment/migration.tf
```

Then inspect and validate:

```bash
./labctl status 003
./labctl validate 003
```

The validator refuses to apply any plan that contains create or delete actions. Once the migration is safe, it applies the local-state migration, verifies that both object IDs were preserved, and proves that the post-migration plan is empty.

## Automated sandbox and CI tests

Incidents 002 and 003 include deterministic package tests for restricted environments that do not have Docker, Kubernetes, or Terraform installed.

```bash
./labctl test 002
./labctl test 003
```

The live validators remain authoritative for learner execution. The deterministic tests verify the packaged failure sequence, partial fixes, complete remediation, policy gates, reset behavior, and reproducibility.

## Cleanup

Delete the shared KIND cluster used by Kubernetes incidents:

```bash
./labctl destroy-cluster
```

Do not open a lab's `solution/` directory until you have completed or intentionally abandoned your investigation.
