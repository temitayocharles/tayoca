# The DevOps Incident Lab

## No Theories. Roll Up Your Sleeves, Grab Your Coffee, and Get Your Hands Dirty.

This is a complete first-volume incident simulation system. It contains **40 executable incidents across six book parts**, a portable lab engine, partial-remediation traps, automated scoring, incident records, senior-engineer reference solutions, postmortem templates, and three live-tool extensions.

The governing cycle is:

> **Perform. Decide. Prove. Document.**

## What makes this different

You do not pass because you read a chapter or made the error disappear. You must:

1. reproduce the broken state;
2. inspect evidence and form hypotheses;
3. edit real Kubernetes, CI/CD, GitOps, Terraform, IAM, SRE, supply-chain, AI-operations, and DR configuration;
4. reject unsafe shortcuts;
5. pass technical and safety gates;
6. complete an engineering record and defend the decision;
7. prove reset reproducibility.

Every incident contains a **partial repair** that looks plausible but remains unsafe or incomplete. The regression suite verifies that the partial repair cannot pass.

## Requirements

Portable mode requires only:

- Bash;
- Python 3.10 or newer;
- a text editor.

The portable configuration files use JSON syntax with `.yaml` extensions where appropriate. JSON is valid YAML, so the same files remain compatible with YAML-aware tooling while the lab engine stays dependency-free.

Three preserved live-tool labs are available under `live-labs/`:

- Incidents 001 and 002: Docker, KIND, and kubectl;
- Incident 003: Terraform or OpenTofu.

## Start working

```bash
./labctl list
./labctl start 001
./labctl status 001
```

Read the briefing shown by `start`, inspect the supplied evidence, and edit only:

```text
.workspaces/001/
```

Then run:

```bash
./labctl validate 001
```

Reset or remove the workspace:

```bash
./labctl reset 001
./labctl destroy 001
```

## Full incident catalogue

| ID | Incident | Level | Target time |
|---|---|---|---|
| 001 | The Deployment That Passed but Never Worked | Intermediate | 45–75 minutes |
| 002 | The Pod That Would Not Stay Alive | Intermediate | 50–80 minutes |
| 003 | The Terraform Plan That Wanted to Destroy Production | Intermediate | 45–70 minutes |
| 004 | The Secret That Never Reached the Cluster | Intermediate | 50–85 minutes |
| 005 | The Pipeline Was Green but Deployed the Wrong Image | Intermediate | 45–75 minutes |
| 006 | The GitOps Release That Deployed Yesterday’s Commit | Advanced | 55–90 minutes |
| 007 | The Rollback That Could Not Roll Back | Advanced | 55–90 minutes |
| 008 | The Partial Apply and the Orphaned Production Resource | Advanced | 70–110 minutes |
| 009 | The IAM Denial and the Dangerous One-Line Fix | Intermediate | 50–80 minutes |
| 010 | The Secret That Terraform Remembered Forever | Advanced | 55–90 minutes |
| 011 | The Service Was Slow but CPU Looked Fine | Advanced | 65–100 minutes |
| 012 | The Dependency Failure That Took Down Healthy Services | Advanced | 65–100 minutes |
| 013 | The Backup That Existed but Could Not Restore | Advanced | 70–110 minutes |
| 014 | The Alert Storm That Hid the Real Outage | Advanced | 55–90 minutes |
| 015 | Senior Challenge: Checkout Failed Across App, Database, and Queue | Senior | 100–160 minutes |
| 016 | Senior Challenge: The Artifact Came From the Wrong Builder | Senior | 85–140 minutes |
| 017 | Senior Challenge: The AI Agent Proposed a Dangerous Fix | Senior | 90–145 minutes |
| 018 | Senior Challenge: The Fifteen-Minute Disaster Recovery Capstone | Senior | 120–180 minutes |
| 019 | The Helm Release That Failed Halfway | Advanced | 60–95 minutes |
| 020 | The Persistent Volume That Would Not Reattach | Advanced | 65–105 minutes |
| 021 | The HPA That Watched Traffic but Never Scaled | Intermediate | 45–75 minutes |
| 022 | The NetworkPolicy That Blocked DNS | Intermediate | 45–75 minutes |
| 023 | The Emergency Hotfix GitOps Tried to Undo | Advanced | 55–90 minutes |
| 024 | The Deployment Credential That Expired at Release Time | Advanced | 50–80 minutes |
| 025 | The Vulnerability Gate That Passed a Dangerous Image | Advanced | 50–85 minutes |
| 026 | The CDN That Kept Serving Yesterday’s Release | Intermediate | 45–75 minutes |
| 027 | The Build Cache That Hid a Dependency Change | Intermediate | 45–75 minutes |
| 028 | The Tag Trigger That Bypassed Production Approval | Advanced | 55–90 minutes |
| 029 | The Terraform State Lock Nobody Should Force-Unlock Yet | Advanced | 55–90 minutes |
| 030 | The Reusable Module That Created a Public Database | Advanced | 60–95 minutes |
| 031 | The Teardown Plan That Targeted Shared Infrastructure | Advanced | 60–100 minutes |
| 032 | The Quiet Cloud Configuration That Became a Cost Incident | Intermediate | 50–85 minutes |
| 033 | The SLO That Stayed Green During a Checkout Outage | Advanced | 55–90 minutes |
| 034 | The On-Call Handover That Lost an Unresolved Risk | Intermediate | 40–70 minutes |
| 035 | The Disk With Plenty of Space but No Performance Left | Advanced | 60–95 minutes |
| 036 | The DNS Failure That Looked Like Every Application Failed | Advanced | 55–90 minutes |
| 037 | Senior Challenge: The Zero-Downtime Schema Migration | Senior | 100–160 minutes |
| 038 | Senior Challenge: Regional Failover Replayed Every Message | Senior | 95–150 minutes |
| 039 | Senior Challenge: One Tenant Could Read Another Tenant’s Data | Senior | 100–160 minutes |
| 040 | Senior Challenge: The Production Readiness Review | Senior | 120–180 minutes |

## Book structure

- **Part I:** Enter the Incident Room
- **Part II:** Kubernetes Incidents
- **Part III:** CI/CD and GitOps Incidents
- **Part IV:** Terraform and Cloud Incidents
- **Part V:** SRE and Production Operations
- **Part VI:** Senior Engineer Challenges
- **Appendices:** setup, scoring, command reference, glossary, and facilitation

The assembled manuscript is in [`BOOK-MANUSCRIPT.md`](BOOK-MANUSCRIPT.md).

## Run the full regression

```bash
python3 tests/full_regression.py
```

The test executes all 40 incidents through:

```text
broken → partial repair → complete repair → documentation → reset
```

The authoritative sandbox evidence is stored in:

```text
reports/full-regression-report.txt
```

## Live-tool extensions

The original live implementations for Incidents 001–003 are preserved in `live-labs/`.

```bash
cd live-labs
./labctl start 001
./labctl validate 001
```

Portable mode is the universal book experience. Live mode adds real kubelet, Service, KIND, Terraform, and state behavior where the required tools are installed.

## Solution discipline

Do not open a lab's `solution/` directory until you have completed or intentionally abandoned the investigation. Reference solutions exist to compare reasoning, not to replace it.
