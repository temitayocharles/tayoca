# KDP Production Checklist

The executable content is complete for Volume 1. Before print publication:

- edit the assembled manuscript for consistent voice and terminology;
- create diagrams and evidence screenshots for each incident;
- decide trim size, typography, grayscale/color strategy, and page budget;
- move solution walkthroughs to a controlled answer section or companion download;
- add QR codes or short URLs for the repository and release archive;
- create legal, copyright, disclaimer, and edition pages;
- perform technical peer review of every lab;
- run accessibility and print legibility checks for code and tables;
- generate paperback, hardcover, and digital editions;
- proof the printed copy before enabling broad distribution.
