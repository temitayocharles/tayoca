# Appendices

## Appendix A: Command reference

```bash
./labctl list
./labctl start <ID>
./labctl status <ID>
./labctl validate <ID>
./labctl reset <ID>
./labctl destroy <ID>
```

The regression-only command below applies the reference remediation. Learners should not use it during normal work:

```bash
./labctl apply-reference <ID>
```

## Appendix B: Workspace anatomy

```text
labs/<ID>-<slug>/
├── briefing/INCIDENT.md
├── broken-environment/
├── partial-environment/
├── evidence/
├── templates/INCIDENT-NOTES.md
├── validators/validate.sh
├── solution/
│   ├── SOLUTION.md
│   ├── REFERENCE-NOTES.md
│   └── fixed-environment/
└── postmortem/POSTMORTEM-TEMPLATE.md
```

The reset source is immutable during the exercise. All learner changes belong in `.workspaces/<ID>/`.

## Appendix C: Team facilitation

For a team exercise:

1. assign incident commander, investigator, operator, and scribe roles;
2. reveal evidence incrementally;
3. require a hypothesis before each change;
4. time-box investigation but never bypass safety gates;
5. rotate the incident commander role;
6. review rejected shortcuts, not only the final fix;
7. run the reset test at the end.

## Appendix D: Interview simulation

A candidate should be able to explain:

- what they observed first;
- what evidence changed their hypothesis;
- which action they deliberately avoided;
- how they bounded blast radius;
- what they used as proof of recovery;
- how they would prevent recurrence.

Do not score candidates by matching the reference solution word for word. Score the quality, safety, and defensibility of their reasoning.

## Appendix E: Glossary

**Blast radius:** the users, systems, or data potentially affected by a change.  
**Causal signal:** evidence directly connected to the failure mechanism.  
**Circuit breaker:** a control that temporarily stops calls to an unhealthy dependency.  
**Digest:** immutable content identity for an artifact.  
**Fencing:** preventing a former primary from accepting writes before another node is promoted.  
**Partial apply:** an infrastructure operation that changed some resources before failing.  
**RPO:** maximum acceptable data-loss window.  
**RTO:** maximum acceptable recovery duration.  
**SLO burn rate:** speed at which a service consumes its error budget.  
**State identity:** the address and object identity Terraform uses to correlate configuration with infrastructure.  
**Unsafe shortcut:** a change that hides symptoms or weakens controls instead of restoring the intended contract.

## Appendix F: Production disclaimer

The portable simulator is intentionally deterministic and creates no cloud resources. The live extensions use local KIND and Terraform/OpenTofu. Do not apply lab configurations to an employer or client environment. Never place real credentials in a lab workspace.
