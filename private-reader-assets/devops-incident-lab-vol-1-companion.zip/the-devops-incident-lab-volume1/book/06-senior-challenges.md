# Part VI — Senior Engineer Challenges

The senior challenges combine systems and constraints. There is no single component to restart. You must order changes, preserve data, enforce trust, control automation, meet recovery objectives, and leave an auditable path for the next engineer.

## Part completion standard

Complete every incident, retain the engineering records, and compare your decisions across incidents. Look for recurring patterns: weak identity, incomplete contracts, missing evidence, uncontrolled amplification, and recovery paths that were never tested.

# Incident 015: Senior Challenge: Checkout Failed Across App, Database, and Queue

**Level:** Senior  
**Target time:** 100–160 minutes  
**Core skills:** multi-system reasoning, safe sequencing, feature flags, data integrity

## Situation

A checkout feature was enabled before a schema migration completed. Messages back up, retries duplicate work, and rollback risks incompatible writes.

## Your mission

1. Stabilize traffic without data loss.
2. Sequence feature flags, backward-compatible migration, queue control, deployment, and smoke tests.
3. Create a rollback checkpoint before reactivation.

## Operational constraints

- Zero data loss.
- No destructive database rollback.
- Keep a dead-letter path.
- Document the exact recovery order.

## Start the incident

```bash
./labctl start 015
./labctl status 015
```

Edit the files inside:

```text
.workspaces/015/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `feature-flags.json`
- `database.json`
- `queue.yaml`
- `change-plan.json`

## Evidence supplied

- `incident-timeline.json`
- `queue-depth.txt`
- `database-errors.txt`

## Completion standard

Run:

```bash
./labctl validate 015
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/015/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 016: Senior Challenge: The Artifact Came From the Wrong Builder

**Level:** Senior  
**Target time:** 85–140 minutes  
**Core skills:** supply-chain security, signatures, provenance, admission policy

## Situation

A correctly named image digest arrives from an untrusted workflow. The cluster admits it because signature and provenance enforcement are optional.

## Your mission

1. Verify digest, signature, issuer, subject, SBOM, and provenance.
2. Enforce the checks at admission.
3. Make verification a pre-deployment pipeline gate.

## Operational constraints

- Do not trust a tag or registry location alone.
- Trust one issuer and one repository subject.
- Reject unsigned artifacts.

## Start the incident

```bash
./labctl start 016
./labctl status 016
```

Edit the files inside:

```text
.workspaces/016/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `attestation.json`
- `admission-policy.yaml`
- `workflow.yaml`

## Evidence supplied

- `registry-event.json`
- `admission-audit.txt`

## Completion standard

Run:

```bash
./labctl validate 016
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/016/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 017: Senior Challenge: The AI Agent Proposed a Dangerous Fix

**Level:** Senior  
**Target time:** 90–145 minutes  
**Core skills:** AI operations safety, prompt injection, least privilege, human approval

## Situation

An operations agent reads a malicious instruction embedded in logs and proposes deleting a Deployment. Its tool role allows wildcard verbs and no approval.

## Your mission

1. Separate untrusted evidence from instructions.
2. Make investigation read-only by default.
3. Require independent evidence, approval, bounded patch permissions, and rollback.

## Operational constraints

- No wildcard verbs.
- No delete permission.
- Every write requires approval.
- Actions remain namespace-scoped.

## Start the incident

```bash
./labctl start 017
./labctl status 017
```

Edit the files inside:

```text
.workspaces/017/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `agent-policy.yaml`
- `tool-permissions.json`
- `proposed-action.json`

## Evidence supplied

- `agent-transcript.txt`
- `rbac-audit.json`

## Completion standard

Run:

```bash
./labctl validate 017
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/017/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 018: Senior Challenge: The Fifteen-Minute Disaster Recovery Capstone

**Level:** Senior  
**Target time:** 120–180 minutes  
**Core skills:** DR orchestration, RTO/RPO, fencing, failover/failback

## Situation

The primary region is unavailable. DNS TTL is 30 minutes, replication lag is 12 minutes, and the runbook can promote without fencing the former primary.

## Your mission

1. Design and prove a failover that meets RTO 15 and RPO 5.
2. Prevent split brain.
3. Validate critical journeys after promotion.
4. Capture evidence and define failback.

## Operational constraints

- Primary fencing before promotion.
- Controlled approval.
- RTO ≤15 minutes.
- RPO ≤5 minutes.
- Full exercise evidence required.

## Start the incident

```bash
./labctl start 018
./labctl status 018
```

Edit the files inside:

```text
.workspaces/018/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `dr-plan.yaml`
- `failover-runbook.json`

## Evidence supplied

- `regional-status.json`
- `replication-lag.txt`
- `exercise-log.txt`

## Completion standard

Run:

```bash
./labctl validate 018
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/018/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 037: Senior Challenge: The Zero-Downtime Schema Migration

**Level:** Senior  
**Target time:** 100–160 minutes  
**Core skills:** database migration, expand-contract, backfill, rollback

## Situation

A migration drops an old column in the same release that introduces a replacement, while old application instances are still serving traffic.

## Your mission

1. Design an expand-and-contract sequence.
2. Keep every phase backward compatible.
3. Throttle backfill, verify parity, preserve rollback, and delay contract.

## Operational constraints

- No same-release destructive contract.
- Lock time under 500 ms.
- Prove zero downtime.

## Start

```bash
./labctl start 037
./labctl status 037
```

Edit `.workspaces/037/` only.

## Files under your control

- `migration-plan.json`

## Evidence

- `migration-error.txt`

## Completion

```bash
./labctl validate 037
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 038: Senior Challenge: Regional Failover Replayed Every Message

**Level:** Senior  
**Target time:** 95–150 minutes  
**Core skills:** messaging, idempotency, regional failover, replay

## Situation

The secondary region starts consuming from an old checkpoint, and consumers assumed exactly-once delivery, duplicating payment side effects.

## Your mission

1. Make business operations idempotent.
2. Replicate replay checkpoints.
3. Use transactional outbox, deduplication, DLQ, and replay validation.

## Operational constraints

- Do not assume exactly once.
- Protect business side effects.
- Keep poison messages auditable.

## Start

```bash
./labctl start 038
./labctl status 038
```

Edit `.workspaces/038/` only.

## Files under your control

- `message-failover.yaml`

## Evidence

- `duplicate-events.txt`

## Completion

```bash
./labctl validate 038
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 039: Senior Challenge: One Tenant Could Read Another Tenant’s Data

**Level:** Senior  
**Target time:** 100–160 minutes  
**Core skills:** multi-tenancy, RLS, cache isolation, authorization

## Situation

The API trusts a tenant header, the cache key omits tenant identity, and the database has no row-level security.

## Your mission

1. Derive tenant identity from verified authentication.
2. Enforce independent database isolation.
3. Scope cache, storage, tests, audit, and logs.

## Operational constraints

- Do not trust client tenant headers.
- Add cross-tenant negative tests.
- Redact customer data in logs.

## Start

```bash
./labctl start 039
./labctl status 039
```

Edit `.workspaces/039/` only.

## Files under your control

- `tenant-isolation.yaml`

## Evidence

- `security-report.txt`

## Completion

```bash
./labctl validate 039
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 040: Senior Challenge: The Production Readiness Review

**Level:** Senior  
**Target time:** 120–180 minutes  
**Core skills:** production readiness, risk review, recovery, operational ownership

## Situation

A new service can deploy and pass a happy-path demo, but ownership, SLOs, rollback, restore, DR, provenance, capacity, and risk acceptance are incomplete.

## Your mission

1. Decide whether the service is actually ready for production.
2. Close reliability, recovery, security, capacity, and ownership gaps.
3. Require accountable launch approval.

## Operational constraints

- No launch with unaccepted critical risk.
- Rollback and restore must be tested.
- Readiness is broader than deployment success.

## Start

```bash
./labctl start 040
./labctl status 040
```

Edit `.workspaces/040/` only.

## Files under your control

- `production-readiness.json`

## Evidence

- `review.txt`

## Completion

```bash
./labctl validate 040
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.

