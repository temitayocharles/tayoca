# Part III — CI/CD and GitOps Incidents

Delivery systems fail when identity is ambiguous. Branches, tags, mirrors, and release jobs can all report success while different components refer to different artifacts or commits. These labs make artifact identity and release evidence explicit.

## Part completion standard

Complete every incident, retain the engineering records, and compare your decisions across incidents. Look for recurring patterns: weak identity, incomplete contracts, missing evidence, uncontrolled amplification, and recovery paths that were never tested.

# Incident 005: The Pipeline Was Green but Deployed the Wrong Image

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** immutable artifacts, digest pinning, release verification, provenance

## Situation

The pipeline is green, but production still runs yesterday’s checkout service. The release uses mutable tags and never verifies the running artifact.

## Your mission

1. Connect build output to deployment through one immutable digest.
2. Eliminate mutable-tag ambiguity.
3. Add deployed-digest verification and a user-facing smoke gate.

## Operational constraints

- Do not force a random restart.
- Do not use latest or stable tags.
- Record release provenance.

## Start the incident

```bash
./labctl start 005
./labctl status 005
```

Edit the files inside:

```text
.workspaces/005/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `artifact.json`
- `workflow.yaml`
- `deployment.yaml`

## Evidence supplied

- `pipeline-log.txt`
- `registry-inspection.txt`

## Completion standard

Run:

```bash
./labctl validate 005
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/005/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 006: The GitOps Release That Deployed Yesterday’s Commit

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** Git mirror consistency, GitOps revision pinning, release gates, evidence

## Situation

Forgejo reports a successful release, but the GitHub mirror is behind. Argo CD follows main and reconciles a stale commit.

## Your mission

1. Make mirror synchronization an explicit release gate.
2. Compare source and mirror SHAs.
3. Pin Argo CD and release evidence to the intended commit.

## Operational constraints

- Do not add arbitrary sleep.
- Use a bounded wait.
- Fail on SHA mismatch.
- Deploy an exact commit, not a branch.

## Start the incident

```bash
./labctl start 006
./labctl status 006
```

Edit the files inside:

```text
.workspaces/006/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `mirror.json`
- `workflow.yaml`
- `argocd-application.yaml`

## Evidence supplied

- `mirror-status.txt`
- `argocd-history.txt`

## Completion standard

Run:

```bash
./labctl validate 006
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/006/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 007: The Rollback That Could Not Roll Back

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** rollback design, artifact retention, deployment evidence, recovery timing

## Situation

A release fails. The rollback job points to stable, but stable was overwritten by the bad build and the prior digest was never retained.

## Your mission

1. Create an immutable current and previous release chain.
2. Define a bounded rollback to a known digest.
3. Require rollback smoke tests and evidence.

## Operational constraints

- Do not rebuild the previous version.
- Do not use mutable tags.
- Do not call rollback complete before smoke validation.

## Start the incident

```bash
./labctl start 007
./labctl status 007
```

Edit the files inside:

```text
.workspaces/007/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `release-history.json`
- `pipeline.yaml`
- `deployment.yaml`

## Evidence supplied

- `release-history.txt`
- `rollback-log.txt`

## Completion standard

Run:

```bash
./labctl validate 007
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/007/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 024: The Deployment Credential That Expired at Release Time

**Level:** Advanced  
**Target time:** 50–80 minutes  
**Core skills:** OIDC, CI identity, AWS STS, least privilege

## Situation

A production release fails because a long-lived AWS key expired. The proposed fallback stores a new administrator key in CI.

## Your mission

1. Replace static credentials with OIDC.
2. Restrict trust to one repository and branch.
3. Bound permissions and session duration.

## Operational constraints

- No static fallback.
- No write-all repository permission.
- Assume one governed role.

## Start

```bash
./labctl start 024
./labctl status 024
```

Edit `.workspaces/024/` only.

## Files under your control

- `oidc-workflow.yaml`

## Evidence

- `auth-error.txt`

## Completion

```bash
./labctl validate 024
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 025: The Vulnerability Gate That Passed a Dangerous Image

**Level:** Advanced  
**Target time:** 50–85 minutes  
**Core skills:** vulnerability gates, exception governance, digest scanning, fail closed

## Situation

The scanner reports a high-severity exploitable package, but the pipeline blocks only critical findings and exceptions never expire.

## Your mission

1. Scan the immutable digest with a fresh database.
2. Fail on high and critical risk.
3. Govern every exception with owner, ticket, and expiry.

## Operational constraints

- Do not ignore unfixed risk.
- Fail closed on scanner error.
- No permanent allowlist.

## Start

```bash
./labctl start 025
./labctl status 025
```

Edit `.workspaces/025/` only.

## Files under your control

- `vulnerability-policy.yaml`

## Evidence

- `scan.txt`

## Completion

```bash
./labctl validate 025
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 026: The CDN That Kept Serving Yesterday’s Release

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** CDN caching, invalidation, checksums, release verification

## Situation

Origin files are correct, but users receive an old index page because HTML and hashed assets share the same long cache policy.

## Your mission

1. Separate mutable entry-point and immutable asset caching.
2. Invalidate only what must change.
3. Verify content through the CDN.

## Operational constraints

- Do not invalidate every asset.
- Keep hashed assets cacheable for a year.
- Prove edge content.

## Start

```bash
./labctl start 026
./labctl status 026
```

Edit `.workspaces/026/` only.

## Files under your control

- `cdn-release.yaml`

## Evidence

- `cdn-check.txt`

## Completion

```bash
./labctl validate 026
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 027: The Build Cache That Hid a Dependency Change

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** build caching, lockfiles, deterministic builds, dependency evidence

## Situation

A branch cache restores an incompatible dependency tree, and npm install quietly rewrites resolution despite a changed lockfile.

## Your mission

1. Bind cache identity to lockfile and toolchain.
2. Use deterministic installation.
3. Record dependency evidence.

## Operational constraints

- No branch-only cache key.
- No broad cross-version restore key.
- Do not rewrite lockfiles in CI.

## Start

```bash
./labctl start 027
./labctl status 027
```

Edit `.workspaces/027/` only.

## Files under your control

- `cache-policy.yaml`

## Evidence

- `build-log.txt`

## Completion

```bash
./labctl validate 027
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 028: The Tag Trigger That Bypassed Production Approval

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** approval gates, protected environments, signed tags, change control

## Situation

Main-branch deploys require approval, but a release tag follows a separate job that writes directly to production.

## Your mission

1. Route every production path through one protected environment.
2. Bind approval to a signed tag, digest, and change record.
3. Audit emergency release paths.

## Operational constraints

- No conditional bypass.
- At least one required reviewer.
- Post-deploy verification remains mandatory.

## Start

```bash
./labctl start 028
./labctl status 028
```

Edit `.workspaces/028/` only.

## Files under your control

- `production-gate.yaml`

## Evidence

- `workflow-audit.txt`

## Completion

```bash
./labctl validate 028
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.

