# Part IV — Terraform and Cloud Incidents

Infrastructure incidents are often identity and state incidents. The safest action may be to move an address, adopt an object, constrain one permission, or remove a value from state. Replacement and broad access are deliberately treated as last resorts.

## Part completion standard

Complete every incident, retain the engineering records, and compare your decisions across incidents. Look for recurring patterns: weak identity, incomplete contracts, missing evidence, uncontrolled amplification, and recovery paths that were never tested.

# Incident 003: The Terraform Plan That Wanted to Destroy Production

**Level:** Intermediate  
**Target time:** 45–70 minutes  
**Core skills:** plan review, for_each identity, moved blocks, state safety

## Situation

A harmless naming cleanup changes for_each keys. Terraform now proposes destroying and recreating two production resources.

## Your mission

1. Explain why the resource addresses changed identity.
2. Represent the refactor with declarative state moves.
3. Prove the final plan contains no create or destroy actions.

## Operational constraints

- Do not use targeted apply.
- Do not manually edit state JSON.
- Do not accept replacement.
- Preserve both resource identities.

## Start the incident

```bash
./labctl start 003
./labctl status 003
```

Edit the files inside:

```text
.workspaces/003/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `migration.tf`

## Evidence supplied

- `initial-plan.txt`
- `change-request.md`

## Completion standard

Run:

```bash
./labctl validate 003
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/003/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 008: The Partial Apply and the Orphaned Production Resource

**Level:** Advanced  
**Target time:** 70–110 minutes  
**Core skills:** drift analysis, import/adoption, partial apply recovery, identity preservation

## Situation

A failed apply created a production instance outside state while an out-of-band security-group change opened ingress globally.

## Your mission

1. Assess actual state before changing anything.
2. Adopt the orphaned resource.
3. Reconcile drift without replacing the production instance.
4. Require an empty post-apply plan.

## Operational constraints

- No resource replacement.
- Use state locking.
- Begin with refresh-only assessment.
- Restore the approved CIDR.

## Start the incident

```bash
./labctl start 008
./labctl status 008
```

Edit the files inside:

```text
.workspaces/008/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `observed-state.json`
- `desired-state.json`
- `remediation.json`

## Evidence supplied

- `cloud-inventory.json`
- `failed-apply.log`

## Completion standard

Run:

```bash
./labctl validate 008
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/008/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 009: The IAM Denial and the Dangerous One-Line Fix

**Level:** Intermediate  
**Target time:** 50–80 minutes  
**Core skills:** IAM diagnosis, least privilege, KMS context, policy review

## Situation

The deployment role cannot read an encrypted release artifact. A proposed fix grants s3:* and kms:* on every resource.

## Your mission

1. Grant only the missing object-read and decrypt capabilities.
2. Scope S3 to the release prefix and KMS to one key.
3. Constrain decrypt with encryption context.

## Operational constraints

- No wildcard action.
- No Resource "*".
- Do not grant write permissions.
- Preserve least privilege.

## Start the incident

```bash
./labctl start 009
./labctl status 009
```

Edit the files inside:

```text
.workspaces/009/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `policy.json`

## Evidence supplied

- `access-denied.json`
- `cloudtrail-event.json`

## Completion standard

Run:

```bash
./labctl validate 009
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/009/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 010: The Secret That Terraform Remembered Forever

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** Terraform state security, secret references, state remediation, data classification

## Situation

A database password was passed into Terraform and now exists in local state, backups, and plan artifacts despite being marked sensitive.

## Your mission

1. Remove the value from Terraform configuration and state.
2. Model only a governed external secret reference.
3. Prevent outputs or declassification from reintroducing exposure.

## Operational constraints

- Sensitive is not sufficient if the value remains in state.
- Do not replace one plaintext variable with another.
- Do not expose the value through outputs.

## Start the incident

```bash
./labctl start 010
./labctl status 010
```

Edit the files inside:

```text
.workspaces/010/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `main.tf`
- `state.json`

## Evidence supplied

- `state-audit.txt`
- `plan-redaction.txt`

## Completion standard

Run:

```bash
./labctl validate 010
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/010/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 029: The Terraform State Lock Nobody Should Force-Unlock Yet

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** state locking, concurrency, force unlock, state recovery

## Situation

Terraform reports a lock. The operation began three minutes ago, and nobody has confirmed whether the runner is still alive.

## Your mission

1. Identify the lock owner and operation.
2. Distinguish active from stale lock.
3. Back up state and perform controlled recovery only when safe.

## Operational constraints

- No blind force-unlock.
- Target the exact lock ID.
- Run refresh-only assessment afterward.

## Start

```bash
./labctl start 029
./labctl status 029
```

Edit `.workspaces/029/` only.

## Files under your control

- `state-lock-recovery.json`

## Evidence

- `lock-info.txt`

## Completion

```bash
./labctl validate 029
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 030: The Reusable Module That Created a Public Database

**Level:** Advanced  
**Target time:** 60–95 minutes  
**Core skills:** Terraform modules, RDS security, validation, secure defaults

## Situation

A default combination places production RDS in public subnets with broad CIDR ingress and no deletion protection.

## Your mission

1. Make network placement private.
2. Restrict ingress to the runtime security group.
3. Enforce encryption, backups, deletion protection, and unsafe-combination validation.

## Operational constraints

- No public CIDR.
- Fix the reusable module contract, not only one caller.
- Preserve recoverability.

## Start

```bash
./labctl start 030
./labctl status 030
```

Edit `.workspaces/030/` only.

## Files under your control

- `database-module.yaml`

## Evidence

- `plan.txt`

## Completion

```bash
./labctl validate 030
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 031: The Teardown Plan That Targeted Shared Infrastructure

**Level:** Advanced  
**Target time:** 60–100 minutes  
**Core skills:** safe teardown, ownership, shared resources, orphan cleanup

## Situation

An application teardown includes the shared VPC, state bucket, and lock table because ownership boundaries were never encoded.

## Your mission

1. Delete only owned resources.
2. Preserve shared control-plane infrastructure.
3. Remove only the application state prefix and prove cleanup.

## Operational constraints

- No shared VPC deletion.
- No state bucket deletion.
- Run dependency and orphan scans.

## Start

```bash
./labctl start 031
./labctl status 031
```

Edit `.workspaces/031/` only.

## Files under your control

- `teardown-plan.json`

## Evidence

- `destroy-plan.txt`

## Completion

```bash
./labctl validate 031
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 032: The Quiet Cloud Configuration That Became a Cost Incident

**Level:** Intermediate  
**Target time:** 50–85 minutes  
**Core skills:** FinOps, right-sizing, retention, budget controls

## Situation

Non-production runs three NAT gateways, infinite logs, oversized compute, and idle environments around the clock without budgets.

## Your mission

1. Reduce structural network cost.
2. Bound retention and idle runtime.
3. Right-size from evidence and add cost observability.

## Operational constraints

- Do not sacrifice production resilience assumptions blindly.
- Keep cost-allocation tags.
- Set measurable budget alerts.

## Start

```bash
./labctl start 032
./labctl status 032
```

Edit `.workspaces/032/` only.

## Files under your control

- `cost-controls.yaml`

## Evidence

- `cost-report.txt`

## Completion

```bash
./labctl validate 032
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.

