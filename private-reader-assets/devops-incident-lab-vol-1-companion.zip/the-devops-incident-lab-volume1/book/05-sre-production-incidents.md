# Part V — SRE and Production Operations

SRE work begins where component health stops explaining user experience. These incidents focus on latency, amplification, recoverability, alert usability, and measurable operational objectives.

## Part completion standard

Complete every incident, retain the engineering records, and compare your decisions across incidents. Look for recurring patterns: weak identity, incomplete contracts, missing evidence, uncontrolled amplification, and recovery paths that were never tested.

# Incident 011: The Service Was Slow but CPU Looked Fine

**Level:** Advanced  
**Target time:** 65–100 minutes  
**Core skills:** latency decomposition, queueing, retry amplification, SLO validation

## Situation

Checkout p95 exceeds two seconds while CPU remains below 35%. Traces show queueing at the database pool and retries extending request lifetimes.

## Your mission

1. Use latency evidence instead of CPU assumptions.
2. Bound queues, retries, and deadlines.
3. Resize the connection pool from measured concurrency.
4. Prove the SLO through simulation.

## Operational constraints

- Do not simply add CPU.
- Keep tracing enabled.
- Database timeout must remain below the request deadline.

## Start the incident

```bash
./labctl start 011
./labctl status 011
```

Edit the files inside:

```text
.workspaces/011/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `service-config.yaml`

## Evidence supplied

- `trace-summary.json`
- `slo-dashboard.txt`

## Completion standard

Run:

```bash
./labctl validate 011
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/011/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 012: The Dependency Failure That Took Down Healthy Services

**Level:** Advanced  
**Target time:** 65–100 minutes  
**Core skills:** circuit breakers, bulkheads, retry control, graceful degradation

## Situation

The tax service slows down. Five retries per request exhaust upstream pools, and otherwise healthy services begin failing.

## Your mission

1. Contain dependency pressure.
2. Introduce bounded retries, jitter, bulkheads, deadlines, and a circuit breaker.
3. Provide a controlled degraded response.

## Operational constraints

- Do not remove all failure handling.
- Do not increase global thread pools.
- Keep customer responses deterministic.

## Start the incident

```bash
./labctl start 012
./labctl status 012
```

Edit the files inside:

```text
.workspaces/012/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `resilience.yaml`

## Evidence supplied

- `dependency-graph.json`
- `retry-metrics.txt`

## Completion standard

Run:

```bash
./labctl validate 012
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/012/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 013: The Backup That Existed but Could Not Restore

**Level:** Advanced  
**Target time:** 70–110 minutes  
**Core skills:** recoverability, restore testing, encryption dependencies, RTO/RPO

## Situation

Nightly backups are green, but a restore rehearsal fails because encryption-key context and secret metadata were not captured.

## Your mission

1. Make the backup set operationally complete.
2. Align the runbook to the current format.
3. Pass integrity, RTO, and RPO gates in a controlled restore test.

## Operational constraints

- Do not call a backup valid without restore evidence.
- Retain an immutable copy.
- Verify key access before restore.

## Start the incident

```bash
./labctl start 013
./labctl status 013
```

Edit the files inside:

```text
.workspaces/013/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `backup-policy.yaml`
- `restore-runbook.json`
- `restore-test.json`

## Evidence supplied

- `backup-job.log`
- `restore-failure.txt`

## Completion standard

Run:

```bash
./labctl validate 013
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/013/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 014: The Alert Storm That Hid the Real Outage

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** alert design, SLO burn rates, inhibition, on-call usability

## Situation

One database outage creates eight pages from six downstream services. The on-call engineer spends the first ten minutes acknowledging symptoms.

## Your mission

1. Reduce pages to causal, actionable signals.
2. Group and deduplicate alerts.
3. Inhibit downstream symptoms.
4. Use fast and slow SLO burn routing.

## Operational constraints

- Do not silence the outage.
- Every page needs a runbook.
- Keep slow-burn risk visible without paging.

## Start the incident

```bash
./labctl start 014
./labctl status 014
```

Edit the files inside:

```text
.workspaces/014/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `alerts.yaml`

## Evidence supplied

- `pager-timeline.txt`
- `alert-sample.json`

## Completion standard

Run:

```bash
./labctl validate 014
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/014/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 033: The SLO That Stayed Green During a Checkout Outage

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** SLIs, SLOs, error budgets, synthetic monitoring

## Situation

The service reports 99.99% availability because the SLI counts a lightweight health endpoint while payment callbacks fail.

## Your mission

1. Measure the complete critical journey.
2. Define latency and availability indicators.
3. Drive fast and slow burn response.

## Operational constraints

- Do not count health checks as customer success.
- Include asynchronous completion.
- Keep a synthetic journey.

## Start

```bash
./labctl start 033
./labctl status 033
```

Edit `.workspaces/033/` only.

## Files under your control

- `slo.yaml`

## Evidence

- `incident.txt`

## Completion

```bash
./labctl validate 033
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 034: The On-Call Handover That Lost an Unresolved Risk

**Level:** Intermediate  
**Target time:** 40–70 minutes  
**Core skills:** on-call handover, operational communication, risk ownership, continuity

## Situation

A degraded queue remains under observation, but the next shift receives only “all quiet” and no evidence, owner, or next check.

## Your mission

1. Carry unresolved incidents and known risks across shifts.
2. Assign ownership and next verification time.
3. Link evidence, rollback state, and customer impact.

## Operational constraints

- No vague “monitoring” statement.
- Receiver must acknowledge.
- Keep evidence links.

## Start

```bash
./labctl start 034
./labctl status 034
```

Edit `.workspaces/034/` only.

## Files under your control

- `handover.json`

## Evidence

- `handover-chat.txt`

## Completion

```bash
./labctl validate 034
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 035: The Disk With Plenty of Space but No Performance Left

**Level:** Advanced  
**Target time:** 60–95 minutes  
**Core skills:** IOPS, storage latency, queueing, benchmarking

## Situation

Database storage is only 40% full, yet I/O latency spikes because a small gp2 volume exhausts burst credits and queues thousands of writes.

## Your mission

1. Diagnose performance rather than capacity.
2. Provision independent IOPS and throughput.
3. Bound application queues and prove a storage baseline.

## Operational constraints

- Do not solve by adding disk capacity alone.
- Keep free-space headroom.
- Add actionable latency alerts.

## Start

```bash
./labctl start 035
./labctl status 035
```

Edit `.workspaces/035/` only.

## Files under your control

- `storage-performance.yaml`

## Evidence

- `storage-metrics.txt`

## Completion

```bash
./labctl validate 035
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 036: The DNS Failure That Looked Like Every Application Failed

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** DNS reliability, synthetics, caching, runbooks

## Situation

A single cluster resolver fails. Applications report dependency timeouts, but no DNS-specific synthetic or runbook exists.

## Your mission

1. Remove the resolver single point.
2. Bound query retries and add caching.
3. Monitor DNS directly and document response.

## Operational constraints

- No infinite application retries.
- Keep TTL recovery-friendly.
- Use redundant resolvers.

## Start

```bash
./labctl start 036
./labctl status 036
```

Edit `.workspaces/036/` only.

## Files under your control

- `dns-reliability.yaml`

## Evidence

- `timeout-sample.txt`

## Completion

```bash
./labctl validate 036
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.

