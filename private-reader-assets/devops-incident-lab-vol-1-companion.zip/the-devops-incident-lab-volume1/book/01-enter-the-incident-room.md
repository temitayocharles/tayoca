# Part I: Enter the Incident Room

## Chapter 1: Success signals can lie

A manifest being accepted does not prove a rollout succeeded. A green build does not prove the correct artifact reached production. A backup job completing does not prove recovery. A permission error disappearing does not prove the new policy is safe.

Treat every success signal as evidence with a defined scope. Ask what it proves and what it does not prove.

## Chapter 2: Evidence before action

Before changing production, capture the current state. At minimum, record:

1. user-visible impact;
2. the earliest known failure time;
3. recent changes;
4. workload, dependency, and infrastructure evidence;
5. the hypothesis your next action is testing;
6. the rollback path.

Do not collect logs without a question. Do not change configuration without a falsifiable hypothesis.

## Chapter 3: Symptoms, mechanisms, and root causes

A pod restarting is a symptom. The mechanism may be process exit, failed liveness, eviction, or node disruption. The root cause may be invalid configuration, a missing resource, or a dependency contract.

Use three layers in your notes:

- **Symptom:** what operators or users observe;
- **Mechanism:** how the system produces that symptom;
- **Cause:** why the mechanism exists.

## Chapter 4: The unsafe-shortcut test

Before accepting a remediation, ask:

- Did we remove a control instead of fixing the system?
- Did we broaden permissions beyond the failing operation?
- Did we introduce a mutable identity?
- Did we hide queueing by adding capacity?
- Did we preserve rollback?
- Did we expose a secret?
- Did we replace a production identity unnecessarily?
- Did we validate the user journey?

The validators intentionally reject common shortcuts.

## Chapter 5: Validation as an engineering artifact

Validation should be explicit, repeatable, and tied to the production contract. A strong validation set covers:

- intended functionality;
- safety and least privilege;
- identity and version correctness;
- rollout or migration completion;
- user-facing behavior;
- rollback or recovery capability;
- empty-plan or steady-state evidence;
- documentation.

## Chapter 6: Scoring

Each incident is scored through automated gates. For coaching or team use, apply this 100-point rubric:

| Dimension | Weight | Evidence |
|---|---:|---|
| Diagnosis | 25 | Correct causal explanation supported by evidence |
| Remediation | 25 | Complete technical repair |
| Safety | 20 | Constraints preserved; shortcuts rejected |
| Validation | 20 | Repeatable proof of recovery |
| Communication | 10 | Clear incident record and defense |

A technically working but unsafe fix cannot score above 60. A response without validation cannot score above 70. A response without documentation cannot be marked complete.

## Chapter 7: How to run a lab

```bash
./labctl start <ID>
./labctl status <ID>
```

Open the briefing and evidence. Work only in `.workspaces/<ID>/`. Record the timeline as you investigate.

Use `status` to observe the current simulated production phase. Use `validate` only when you believe the incident is repaired and documented.

```bash
./labctl validate <ID>
```

When finished, reset and reproduce the failure:

```bash
./labctl reset <ID>
./labctl status <ID>
```

Reproducibility matters. A lab that cannot reliably return to its broken state cannot reliably teach or test the incident.
