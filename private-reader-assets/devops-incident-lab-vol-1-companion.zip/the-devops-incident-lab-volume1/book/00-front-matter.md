# The DevOps Incident Lab

## No Theories. Roll Up Your Sleeves, Grab Your Coffee, and Get Your Hands Dirty.

### The promise

Most engineers are taught what working systems look like. Senior engineers are shaped by the moments when systems stop behaving as expected, evidence conflicts, time matters, and an easy fix creates a more dangerous failure.

This book compresses those moments into controlled, repeatable incident laboratories.

You will inherit broken systems, misleading success signals, incomplete operational context, unsafe suggestions, and business constraints. You will investigate, change configuration, validate recovery, and produce evidence another engineer can audit.

This is not a command cookbook. The commands are the easy part.

The difficult work is deciding:

- what evidence is trustworthy;
- which symptom is causal;
- what must not be changed;
- how much risk a fix introduces;
- how to prove users recovered;
- how to preserve rollback and auditability;
- what prevents recurrence.

### Who this is for

The labs are designed for intermediate DevOps engineers, platform engineers, cloud engineers, SREs, security-minded infrastructure engineers, and senior candidates who already understand basic tools but need production judgment.

A beginner can complete the early incidents with careful research. An experienced engineer should still find the later incidents demanding because they combine identity, safety, sequencing, reliability, and business constraints.

### The operating contract

Every incident follows one cycle:

> **Perform. Decide. Prove. Document.**

**Perform:** reproduce the failure and change the environment.  
**Decide:** choose among plausible remediations and reject unsafe shortcuts.  
**Prove:** pass technical, security, recovery, and user-facing gates.  
**Document:** leave an engineering record another operator can use.

A lab is not complete because a process starts, a command exits zero, or a pipeline turns green. It is complete only when the intended production contract is restored and the evidence proves it.
