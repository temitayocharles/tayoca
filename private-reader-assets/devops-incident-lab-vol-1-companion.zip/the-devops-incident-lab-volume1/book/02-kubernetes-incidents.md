# Part II — Kubernetes Incidents

Kubernetes incidents punish shallow interpretation. A workload can be Running but not Ready, Ready but unreachable, or correctly configured while a controller contract is broken. These labs require you to trace behavior across process, probe, pod, Service, controller, and secret boundaries.

## Part completion standard

Complete every incident, retain the engineering records, and compare your decisions across incidents. Look for recurring patterns: weak identity, incomplete contracts, missing evidence, uncontrolled amplification, and recovery paths that were never tested.

# Incident 001: The Deployment That Passed but Never Worked

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** readiness probes, Service routing, rollout verification, safe remediation

## Situation

A release pipeline accepted every manifest and reported success, but customers receive errors and the Deployment never becomes fully available.

## Your mission

1. Find every independent fault preventing a healthy rollout.
2. Repair the workload without deleting probes, reducing replicas, or exposing the Service publicly.
3. Prove readiness, Service routing, and the user-facing request path.

## Operational constraints

- Keep two replicas.
- Keep the Service as ClusterIP.
- Preserve the readiness probe and resource controls.
- Do not route around the Service.

## Start the incident

```bash
./labctl start 001
./labctl status 001
```

Edit the files inside:

```text
.workspaces/001/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `deployment.yaml`
- `service.yaml`

## Evidence supplied

- `pipeline-output.txt`
- `deployment-events.txt`

## Completion standard

Run:

```bash
./labctl validate 001
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/001/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 002: The Pod That Would Not Stay Alive

**Level:** Intermediate  
**Target time:** 50–80 minutes  
**Core skills:** CrashLoopBackOff, previous logs, liveness, security context

## Situation

A payments API enters CrashLoopBackOff after a configuration change. The first obvious fix only reveals a second restart mechanism.

## Your mission

1. Use the failure sequence to distinguish process exit from kubelet restart.
2. Repair startup and liveness contracts.
3. Preserve non-root execution, resource controls, and readiness.

## Operational constraints

- Do not remove liveness or readiness probes.
- Do not run as root.
- Do not increase restart tolerance to hide the defect.

## Start the incident

```bash
./labctl start 002
./labctl status 002
```

Edit the files inside:

```text
.workspaces/002/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `runtime-config.yaml`
- `content-config.yaml`
- `deployment.yaml`
- `service.yaml`

## Evidence supplied

- `previous-container.log`
- `pod-events.txt`

## Completion standard

Run:

```bash
./labctl validate 002
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/002/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 004: The Secret That Never Reached the Cluster

**Level:** Intermediate  
**Target time:** 50–85 minutes  
**Core skills:** External Secrets, contract mapping, secret governance, rotation

## Situation

External Secrets reports reconciliation errors, and the application cannot resolve DB_PASSWORD. A rushed engineer proposes embedding the value in the Deployment.

## Your mission

1. Repair the governed secret store reference.
2. Align the generated Secret key with the Deployment contract.
3. Keep the value outside Git and preserve secret rotation.

## Operational constraints

- No plaintext secret values.
- No manually created static Secret.
- Keep hourly refresh.
- Use the governed production store.

## Start the incident

```bash
./labctl start 004
./labctl status 004
```

Edit the files inside:

```text
.workspaces/004/
```

Do not edit `broken-environment/`; it is the reset source.

## Files under your control

- `external-secret.yaml`
- `deployment.yaml`

## Evidence supplied

- `external-secret-status.txt`
- `pod-event.txt`

## Completion standard

Run:

```bash
./labctl validate 004
```

You pass only when every technical, safety, verification, and evidence gate succeeds. A service appearing to work is not sufficient.

## Required written evidence

Complete `.workspaces/004/INCIDENT-NOTES.md` with:

- observed symptoms;
- evidence and hypotheses;
- rejected unsafe shortcuts;
- exact remediation;
- validation evidence;
- prevention action.
# Incident 019: The Helm Release That Failed Halfway

**Level:** Advanced  
**Target time:** 60–95 minutes  
**Core skills:** Helm, atomic upgrades, hooks, rollback

## Situation

A pre-upgrade hook fails after several resources have changed, leaving a mixed release and no reliable rollback point.

## Your mission

1. Make the release atomic and readiness-gated.
2. Protect stateful data before upgrade.
3. Use immutable artifacts and deterministic hook cleanup.

## Operational constraints

- No manual deletion of failed resources.
- No mutable image tags.
- Rollback must preserve data.

## Start

```bash
./labctl start 019
./labctl status 019
```

Edit `.workspaces/019/` only.

## Files under your control

- `helm-values.yaml`
- `release.json`

## Evidence

- `helm-error.txt`

## Completion

```bash
./labctl validate 019
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 020: The Persistent Volume That Would Not Reattach

**Level:** Advanced  
**Target time:** 65–105 minutes  
**Core skills:** persistent volumes, fencing, attachment recovery, data integrity

## Situation

A stateful pod moves after node failure, but its ReadWriteOnce volume remains attached to the former node.

## Your mission

1. Prove the old writer is fenced.
2. Recover attachment without force-detach corruption risk.
3. Validate filesystem and application data.

## Operational constraints

- Do not switch to ReadWriteMany.
- Do not force detach before fencing.
- Verify backup first.

## Start

```bash
./labctl start 020
./labctl status 020
```

Edit `.workspaces/020/` only.

## Files under your control

- `storage-recovery.json`

## Evidence

- `volume-events.txt`

## Completion

```bash
./labctl validate 020
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 021: The HPA That Watched Traffic but Never Scaled

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** HPA, resource requests, stabilization, load testing

## Situation

Traffic triples, latency rises, and the HorizontalPodAutoscaler remains at two replicas because utilization cannot be calculated.

## Your mission

1. Restore meaningful utilization metrics.
2. Create a real scaling range and stable behavior.
3. Prove scaling under controlled load.

## Operational constraints

- Do not add fixed replicas as the final answer.
- Keep two minimum replicas.
- Avoid scale-down flapping.

## Start

```bash
./labctl start 021
./labctl status 021
```

Edit `.workspaces/021/` only.

## Files under your control

- `hpa.yaml`
- `deployment.yaml`

## Evidence

- `hpa-status.txt`

## Completion

```bash
./labctl validate 021
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 022: The NetworkPolicy That Blocked DNS

**Level:** Intermediate  
**Target time:** 45–75 minutes  
**Core skills:** NetworkPolicy, DNS, egress controls, connectivity testing

## Situation

A default-deny egress policy protects the namespace but silently blocks cluster DNS, making every dependency appear unavailable.

## Your mission

1. Allow only required DNS traffic.
2. Preserve default deny.
3. Prove DNS and HTTPS dependency access.

## Operational constraints

- No allow-all egress.
- Scope DNS to kube-system and DNS pods.
- Keep dependency port restricted.

## Start

```bash
./labctl start 022
./labctl status 022
```

Edit `.workspaces/022/` only.

## Files under your control

- `network-policy.yaml`

## Evidence

- `connection-test.txt`

## Completion

```bash
./labctl validate 022
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.
# Incident 023: The Emergency Hotfix GitOps Tried to Undo

**Level:** Advanced  
**Target time:** 55–90 minutes  
**Core skills:** GitOps drift, emergency change, self-healing, governance

## Situation

An engineer patches production directly during an outage. The fix works, but Git still contains the broken revision and self-healing is disabled.

## Your mission

1. Represent the emergency fix in Git.
2. Converge cluster and desired SHA.
3. Restore drift detection and controlled self-healing.

## Operational constraints

- No permanent kubectl-only fix.
- Pruning needs approval.
- Keep an emergency change record.

## Start

```bash
./labctl start 023
./labctl status 023
```

Edit `.workspaces/023/` only.

## Files under your control

- `gitops-state.json`

## Evidence

- `drift.txt`

## Completion

```bash
./labctl validate 023
```

Complete the engineering record. You pass only when technical, safety, validation, and documentation gates all succeed.

