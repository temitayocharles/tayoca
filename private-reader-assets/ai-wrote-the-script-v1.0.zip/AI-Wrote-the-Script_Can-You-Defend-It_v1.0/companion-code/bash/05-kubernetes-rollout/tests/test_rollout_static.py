"""Static validation for Lab Bash 05 -- the unbounded Kubernetes rollout.

This sandbox has no kubectl/kind/Docker, so runtime cluster behavior is
NOT executed here (see validation/VALIDATION.md for the honest boundary).
What IS proven locally:

* both shell scripts pass `bash -n` (syntax) and ShellCheck
* both manifests parse as YAML and carry the required apps/v1 shape
* the broken script has no rollout time bound; the solution does
* the broken script collects no failure evidence; the solution does

If kubectl + kind exist on your machine, run labs/validate_kubernetes.sh
for real-cluster validation.
"""
from __future__ import annotations

import re
import subprocess
from pathlib import Path

import yaml

LAB = Path(__file__).resolve().parent.parent
BROKEN = LAB / "broken" / "deploy.sh"
SOLUTION = LAB / "solution" / "deploy.sh"
MANIFEST = LAB / "manifests" / "deployment.yaml"
MANIFEST_BROKEN = LAB / "manifests" / "deployment-broken.yaml"


def bash_n(path: Path) -> None:
    subprocess.run(["bash", "-n", str(path)], check=True)


def code_of(path: Path) -> str:
    """Script source with comment lines stripped (assertions belong on code)."""
    return "\n".join(
        line for line in path.read_text(encoding="utf-8").splitlines()
        if not line.lstrip().startswith("#"))


class TestShellSyntax:
    def test_broken_parses(self):
        bash_n(BROKEN)

    def test_solution_parses(self):
        bash_n(SOLUTION)


class TestSemantics:
    def test_broken_rollout_has_no_timeout(self):
        source = code_of(BROKEN)
        assert "rollout status" in source
        assert "--timeout" not in source          # defect intact
        assert "describe" not in source           # collects nothing
        assert "get events" not in source

    def test_solution_bounds_the_wait(self):
        source = SOLUTION.read_text(encoding="utf-8")
        assert re.search(r'rollout status .*--timeout=', source, re.S)
        assert "180s" in source                   # default bound documented

    def test_solution_preserves_evidence_on_failure(self):
        source = SOLUTION.read_text(encoding="utf-8")
        for probe in ("get pods", "describe", "get events"):
            assert probe in source, f"missing evidence probe: {probe}"
        # Evidence collection must not itself kill the script's exit path.
        assert "|| true" in source
        assert re.search(r"exit 1", source)

    def test_strict_mode_present(self):
        assert "set -euo pipefail" in SOLUTION.read_text(encoding="utf-8")


class TestManifests:
    def check(self, path: Path) -> dict:
        docs = list(yaml.safe_load_all(path.read_text(encoding="utf-8")))
        assert docs and docs[0]["kind"] == "Deployment"
        assert docs[0]["apiVersion"] == "apps/v1"
        spec = docs[0]["spec"]
        assert spec["selector"]["matchLabels"] == \
            spec["template"]["metadata"]["labels"]
        containers = spec["template"]["spec"]["containers"]
        assert containers and containers[0]["image"]
        return docs[0]

    def test_healthy_manifest_shape(self):
        doc = self.check(MANIFEST)
        assert "pause" in doc["spec"]["template"]["spec"]["containers"][0]["image"]

    def test_broken_manifest_uses_bad_tag_on_purpose(self):
        doc = self.check(MANIFEST_BROKEN)
        image = doc["spec"]["template"]["spec"]["containers"][0]["image"]
        assert "does-not-exist" in image  # triggers ImagePullBackOff live
