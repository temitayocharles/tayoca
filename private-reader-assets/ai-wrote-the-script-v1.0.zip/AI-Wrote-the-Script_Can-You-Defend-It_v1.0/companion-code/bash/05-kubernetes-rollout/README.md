# Bash 05 — The Kubernetes rollout with no bound

**Difficulty:** Intermediate · **Target time:** 25 minutes

`kubectl rollout status` without `--timeout` waits forever. A bad image tag
turns your deploy job into a zombie that holds a CI runner until the
platform's global timeout (often an hour) finally kills it — with zero
diagnostics captured.

## Layout

- `broken/deploy.sh` — the AI-generated script (defects intact)
- `solution/deploy.sh` — the reference solution
- `manifests/deployment.yaml` — healthy baseline (pause container)
- `manifests/deployment-broken.yaml` — nonexistent image tag
  (ImagePullBackOff on purpose)
- `tests/test_rollout_static.py` — static prove-out, always runnable
- `../../validate_kubernetes.sh` — optional real-cluster validation

## Environment boundary (honest)

This pack validates what can be validated without pretending: shell
syntax (`bash -n`), ShellCheck, manifest YAML shape, and the presence of
the bound, the evidence probes, and the failure exit path. In the build
environment for this edition, **no Docker/kind/kubectl was available**, so
live rollout behavior was not executed there. Kubernetes flags used
(`rollout status --timeout`, `get events --sort-by='.lastTimestamp'`,
`wait` semantics) follow the current official kubectl documentation as of
this edition; verify against your cluster's `kubectl version` output.

## Run it (local, no cluster)

```bash
cd labs
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest bash/05-kubernetes-rollout/tests -v
```

## Run it (with Docker + kind + kubectl)

```bash
bash labs/validate_kubernetes.sh
```

It creates a disposable `kind` cluster, demonstrates the broken script's
unbounded hang (externally time-boxed at 30s), rolls out the healthy
manifest, then proves the solution bounds the failing rollout and captures
evidence before exiting 1. The cluster is deleted afterwards.

Equivalent manual steps if you prefer:

```bash
kind create cluster --name pack-lab
cd labs/bash/05-kubernetes-rollout
MANIFEST=manifests/deployment.yaml bash solution/deploy.sh
MANIFEST=manifests/deployment-broken.yaml ROLLOUT_TIMEOUT=60s bash solution/deploy.sh
kind delete cluster --name pack-lab
```

## What to look for

1. What is the default wait when `--timeout` is omitted, and who pays for it?
2. Why collect `get pods`, `describe`, and events *before* exiting — what
   happens to that evidence after a retry or a `rollout undo`?
3. State the failure signature you expect from `deployment-broken.yaml`:
   which pod statuses, which events?
4. When is `kubectl rollout undo` NOT a safe response? (Think schema
   migrations and data written during a partial rollout.)

**Stretch:** replace the polling loop with `kubectl wait` conditions, add a
`--field-selector` to the events probe for the failing deployment only, and
write the rollback policy for a migration-carrying release: what must be
true before an automatic rollback is allowed?
