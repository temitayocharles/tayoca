#!/usr/bin/env bash
# Deploy the API and report when done.
set -e

kubectl apply -f deployment.yaml
kubectl rollout status deployment/api

echo "Deployment successful"
