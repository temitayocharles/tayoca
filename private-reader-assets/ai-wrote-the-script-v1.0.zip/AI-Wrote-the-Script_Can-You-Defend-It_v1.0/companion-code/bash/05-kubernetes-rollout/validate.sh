#!/usr/bin/env bash
# Validate Lab Bash 05: syntax, lint, static semantics (+ real cluster when
# kind/kubectl are available -- see ../../validate_kubernetes.sh).
set -euo pipefail
cd "$(dirname "$0")"

bash -n broken/deploy.sh solution/deploy.sh
echo "bash -n: OK"

if command -v shellcheck >/dev/null; then
  shellcheck -x solution/deploy.sh
  echo "shellcheck (solution): OK"
  echo "shellcheck (broken, findings expected as teaching material):"
  shellcheck -x broken/deploy.sh || true
else
  echo "shellcheck: not installed, skipping"
fi

python3 -m pytest tests -v

if command -v kubectl >/dev/null && command -v kind >/dev/null; then
  bash ../../validate_kubernetes.sh
else
  echo "kubectl/kind not found: skipping live-cluster validation (see README)"
fi
