#!/usr/bin/env bash
# Reference: bounded rollout with evidence preservation.
set -euo pipefail

namespace=${NAMESPACE:-default}
deployment=${DEPLOYMENT:-api}
timeout=${ROLLOUT_TIMEOUT:-180s}
manifest=${MANIFEST:-deployment.yaml}

kubectl -n "$namespace" apply -f "$manifest"

# Every wait needs a bound. --timeout caps the rollout observation; the
# failure branch preserves diagnostic evidence before anything retries,
# scales, or cleans up.
if ! kubectl -n "$namespace" rollout status "deployment/$deployment" \
    --timeout="$timeout"; then
  echo "Rollout failed; collecting evidence" >&2
  kubectl -n "$namespace" get pods -o wide >&2 || true
  kubectl -n "$namespace" describe "deployment/$deployment" >&2 || true
  kubectl -n "$namespace" get events --sort-by='.lastTimestamp' >&2 | tail -n 40 >&2 || true
  exit 1
fi

echo "Deployment successful"
