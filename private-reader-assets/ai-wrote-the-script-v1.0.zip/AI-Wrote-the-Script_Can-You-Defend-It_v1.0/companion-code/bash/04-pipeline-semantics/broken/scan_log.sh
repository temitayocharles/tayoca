#!/usr/bin/env bash
# Count ERROR lines in the application log for the nightly report.
# Lab adapter: LOG_FILE overrides the default /var/log/myapp/app.log.

log=${LOG_FILE:-/var/log/myapp/app.log}

grep "ERROR" "$log" | wc -l
echo "Scan complete"
