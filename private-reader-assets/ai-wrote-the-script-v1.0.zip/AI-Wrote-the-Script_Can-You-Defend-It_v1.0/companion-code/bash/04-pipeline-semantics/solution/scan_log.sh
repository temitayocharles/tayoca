#!/usr/bin/env bash
# Reference: log scan with honest grep semantics.
set -euo pipefail

log=${LOG_FILE:-/var/log/myapp/app.log}
[[ -r "$log" ]] || { echo "Cannot read $log" >&2; exit 66; }

# grep's exit contract: 0 = match found, 1 = no match (NOT an error),
# >1 = execution error (unreadable file, bad pattern, ...). Capturing the
# status around command substitution keeps that contract legible where
# set -e plus a naive pipeline would have collapsed it.
set +e
count=$(grep -c 'ERROR' "$log")
grep_status=$?
set -e

case "$grep_status" in
  0|1)
    printf 'error_count=%s source=%s\n' "$count" "$log"
    ;;
  *)
    echo "grep failed with status $grep_status on $log" >&2
    exit "$grep_status"
    ;;
esac
