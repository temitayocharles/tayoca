"""Validation for Lab Bash 04 -- the pipeline that hides meaning."""
from __future__ import annotations

from pathlib import Path

from _shared.runner import run_bash

LAB = Path(__file__).resolve().parent.parent
BROKEN = LAB / "broken" / "scan_log.sh"
SOLUTION = LAB / "solution" / "scan_log.sh"
APP_LOG = LAB / "fixtures" / "app.log"     # contains 3 ERROR lines
CLEAN_LOG = LAB / "fixtures" / "clean.log"  # contains none


class TestBroken:
    def test_missing_log_still_scans_clean(self, tmp_path):
        """The defect: grep fails >1, wc prints 0, and the run exits 0."""
        missing = tmp_path / "nope.log"
        result = run_bash(BROKEN, env={"LOG_FILE": str(missing)})
        assert result.returncode == 0
        assert "Scan complete" in result.stdout
        assert "No such file" in result.stderr  # visible, but unactionable
        assert result.stdout.strip().splitlines()[0] == "0"

    def test_real_errors_are_uncounted_semantics(self):
        """The broken script's bare '3' is neither labeled nor actionable."""
        result = run_bash(BROKEN, env={"LOG_FILE": str(APP_LOG)})
        assert result.returncode == 0
        assert result.stdout.strip().splitlines()[0] == "3"
        assert "error_count" not in result.stdout


class TestSolution:
    def test_errors_are_counted_and_labeled(self):
        result = run_bash(SOLUTION, env={"LOG_FILE": str(APP_LOG)})
        assert result.returncode == 0
        assert f"error_count=3 source={APP_LOG}" in result.stdout

    def test_no_matches_is_success_with_zero(self):
        """grep status 1 (no match) must not be treated as an error."""
        result = run_bash(SOLUTION, env={"LOG_FILE": str(CLEAN_LOG)})
        assert result.returncode == 0
        assert "error_count=0" in result.stdout

    def test_missing_file_is_rejected_before_grep(self, tmp_path):
        result = run_bash(SOLUTION, env={"LOG_FILE": str(tmp_path / "no.log")})
        assert result.returncode == 66
        assert "Cannot read" in result.stderr

    def test_grep_error_status_is_propagated(self, tmp_path):
        """grep >1 means a real error: a directory is readable but not a log."""
        result = run_bash(SOLUTION, env={"LOG_FILE": str(tmp_path)})
        assert result.returncode == 2
        assert "grep failed with status 2" in result.stderr
