# Bash 04 — The pipeline that hides meaning

**Difficulty:** Intermediate · **Target time:** 20 minutes

`grep "ERROR" app.log | wc -l` prints a number and the script says
"Scan complete" — even when the log file does not exist. The pipeline's
exit status is `wc`'s status, and `wc` almost always succeeds.

## Layout

- `broken/scan_log.sh` — the AI-generated script (defects intact)
- `solution/scan_log.sh` — the reference solution
- `fixtures/app.log` — contains exactly 3 `ERROR` lines
- `fixtures/clean.log` — contains none
- `tests/test_pipeline.py` — prove-out

## Lab adapter

`LOG_FILE` overrides the book's `/var/log/myapp/app.log`.

## Run it

```bash
cd labs
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest bash/04-pipeline-semantics/tests -v
```

By hand:

```bash
LOG_FILE=/definitely/missing.log bash broken/scan_log.sh; echo "rc=$?"
LOG_FILE=fixtures/app.log   bash solution/scan_log.sh; echo "rc=$?"
LOG_FILE=fixtures/clean.log bash solution/scan_log.sh; echo "rc=$?"
```

## What to look for

1. Without `pipefail`, which command's status becomes the pipeline's status?
2. grep's contract: `0` = match, `1` = no match, `>1` = error. Which of
   those should page a human? Which should feed a metric?
3. Why does adding `set -o pipefail` to the *broken* script NOT fix it?
   (Trace grep = 1 through the pipeline. Now "no errors tonight" fails the
   job. That is the opposite bug.)
4. Why capture `grep -c` output and status in two steps under `set +e`
   instead of restructuring around `pipefail`?

**Stretch:** emit the count as a StatsD/Prometheus-friendly metric line with
a timestamp and host label, and sketch the alert rule: which threshold, for
how long, and who gets paged versus who gets a dashboard?
