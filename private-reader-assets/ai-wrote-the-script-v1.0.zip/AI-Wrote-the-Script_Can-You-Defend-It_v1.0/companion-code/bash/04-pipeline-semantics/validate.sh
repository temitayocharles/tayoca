#!/usr/bin/env bash
# Validate Lab Bash 04: syntax, lint, behavior.
set -euo pipefail
cd "$(dirname "$0")"

bash -n broken/scan_log.sh solution/scan_log.sh
echo "bash -n: OK"

if command -v shellcheck >/dev/null; then
  shellcheck -x solution/scan_log.sh
  echo "shellcheck (solution): OK"
  echo "shellcheck (broken, findings expected as teaching material):"
  shellcheck -x broken/scan_log.sh || true
else
  echo "shellcheck: not installed, skipping"
fi

python3 -m pytest tests -v
