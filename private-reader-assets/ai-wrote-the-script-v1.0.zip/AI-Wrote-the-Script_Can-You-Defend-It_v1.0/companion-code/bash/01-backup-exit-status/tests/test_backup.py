"""Validation for Lab Bash 01 -- the backup that reports success after
failure.

Bash labs are validated through pytest subprocess runs so every shell
behavior is asserted exactly like the Python labs.
"""
from __future__ import annotations

import subprocess
import time
from pathlib import Path

from _shared.runner import run_bash

LAB = Path(__file__).resolve().parent.parent
BROKEN = LAB / "broken" / "backup.sh"
SOLUTION = LAB / "solution" / "backup.sh"
FIXTURE_DATA = LAB / "fixtures" / "app-data"


class TestBroken:
    def test_failed_tar_still_reports_success(self, tmp_path):
        """The core defect: tar fails, the script exits 0 anyway.

        Worse than "no backup": tar creates the archive file *before* it
        discovers the source is missing, so the run "uploads" an artifact
        containing zero application files. Depending on timing it may even
        be a structurally valid (empty) gzip -- nothing looks wrong from
        the outside, which is exactly why the pack exists.
        """
        Path("/tmp/app-backup.tgz").unlink(missing_ok=True)  # stale artifact
        dest = tmp_path / "backups"
        result = run_bash(BROKEN, env={
            "SOURCE_DIR": str(tmp_path / "does-not-exist"),
            "BACKUP_DIR": str(dest),
        }, cwd=tmp_path)
        assert "Backup completed" in result.stdout
        assert result.returncode == 0  # the scheduler sees green

        artifact = dest / "app-backup.tgz"
        assert artifact.exists()       # a FABRICATED backup, not none
        listing = subprocess.run(["tar", "-tzf", str(artifact)],
                                 capture_output=True, text=True, check=False)
        assert listing.stdout.strip() == ""  # zero files were backed up


class TestSolution:
    def test_failure_reaches_the_scheduler(self, tmp_path):
        result = run_bash(SOLUTION, env={
            "SOURCE_DIR": str(tmp_path / "does-not-exist"),
            "BACKUP_DIR": str(tmp_path / "backups"),
        }, cwd=tmp_path)
        assert result.returncode != 0
        assert "Backup uploaded" not in result.stdout

    def test_happy_path_produces_a_real_archive(self, tmp_path):
        dest = tmp_path / "backups"
        result = run_bash(SOLUTION, env={
            "SOURCE_DIR": str(FIXTURE_DATA),
            "BACKUP_DIR": str(dest),
        }, cwd=tmp_path)
        assert result.returncode == 0
        artifacts = list(dest.glob("app-backup-*.tgz"))
        assert len(artifacts) == 1
        assert artifacts[0].stat().st_size > 0
        assert "Backup uploaded" in result.stdout

    def test_two_runs_do_not_overwrite(self, tmp_path):
        dest = tmp_path / "backups"
        env = {"SOURCE_DIR": str(FIXTURE_DATA), "BACKUP_DIR": str(dest)}
        first = run_bash(SOLUTION, env=env, cwd=tmp_path)
        time.sleep(1.1)  # timestamp resolution is one second
        second = run_bash(SOLUTION, env=env, cwd=tmp_path)
        assert first.returncode == 0 and second.returncode == 0
        assert len(list(dest.glob("app-backup-*.tgz"))) == 2

    def test_temp_dir_is_cleaned_after_run(self, tmp_path, monkeypatch):
        tmp_parent = tmp_path / "tmp-parent"
        tmp_parent.mkdir()
        monkeypatch.setenv("TMPDIR", str(tmp_parent))
        result = run_bash(SOLUTION, env={
            "SOURCE_DIR": str(FIXTURE_DATA),
            "BACKUP_DIR": str(tmp_path / "backups"),
            "TMPDIR": str(tmp_parent),
        }, cwd=tmp_path)
        assert result.returncode == 0
        # The trap removed the mktemp directory.
        assert [p for p in tmp_parent.iterdir()] == []
