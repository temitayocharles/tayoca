# Bash 01 — The backup that reports success after failure

**Difficulty:** Foundation · **Target time:** 15 minutes

An AI-generated nightly backup prints "Backup completed" and exits 0 no
matter what happened. The scheduler sees green. There may be no backup.

## Layout

- `broken/backup.sh` — the AI-generated script (defects intact)
- `solution/backup.sh` — the reference solution
- `fixtures/app-data/` — pretend application state to back up
- `tests/test_backup.py` — prove-out, run through pytest

## Lab adapter

The book version writes to `s3://company-backups` with the AWS CLI. The lab
keeps everything local: `BACKUP_DIR` (default `./backups`) stands in for
the bucket and `SOURCE_DIR` (default `/srv/app-data`) for the data. No
AWS account or credentials are needed — the exit-status lesson is identical.

## Run it

```bash
cd labs
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest bash/01-backup-exit-status/tests -v
```

Watch the defect by hand:

```bash
cd bash/01-backup-exit-status
SOURCE_DIR=/path/that/does/not/exist BACKUP_DIR=/tmp/demo-backups bash broken/backup.sh
echo "exit code: $?"   # 0 -- the scheduler would page nobody
ls -la /tmp/demo-backups/          # an "uploaded" artifact EXISTS
tar -tzf /tmp/demo-backups/app-backup.tgz | wc -l   # ...containing 0 files
```

That last detail is the real trap: tar creates the archive file before it
discovers the source is missing, so the run uploads a valid, *empty*
archive. Even a lazy `tar -tzf` smoke test exits 0. Empty-archive checks
(`test -s`, member counts) are part of what the fix adds.

## Reset

```bash
rm -rf ./backups /tmp/app-backup.tgz /tmp/demo-backups
```

## Portability note

`stat -c %s` (GNU) and `stat -f %z` (BSD/macOS) differ; the solution uses
`wc -c`, which is identical on both. `date -u +%Y%m%dT%H%M%SZ` is portable;
`date +%N` is GNU-only. Second-resolution timestamps mean two runs in the
same second collide — acceptable for nightly jobs, wrong for high-frequency
ones. Say which kind yours is.

## What to look for

1. Which command's failure is *allowed* to stop this script today? (None.)
2. Who consumes the exit status — cron, systemd, a CI job, a human alias?
3. What proves a backup exists: the echo, the exit code, the object in the
   bucket, or a successful restore? Rank them.
4. Why does the solution stage into `mktemp -d` and trap `EXIT`?

**Stretch:** add a same-day restore test (`tar -tzf`, then extract one file
to a scratch dir and diff it), and decide how retention should work. A
backup nobody restores is a rumor.
