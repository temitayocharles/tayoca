#!/usr/bin/env bash
# Nightly backup. Lab adapters: SOURCE_DIR / BACKUP_DIR stand in for the
# production paths (/srv/app-data and s3://company-backups).

source_dir=${SOURCE_DIR:-/srv/app-data}
backup_dir=${BACKUP_DIR:-./backups}
mkdir -p "$backup_dir"

tar -czf /tmp/app-backup.tgz -C "$source_dir" .
cp /tmp/app-backup.tgz "$backup_dir/app-backup.tgz"

echo "Backup completed"
exit 0
