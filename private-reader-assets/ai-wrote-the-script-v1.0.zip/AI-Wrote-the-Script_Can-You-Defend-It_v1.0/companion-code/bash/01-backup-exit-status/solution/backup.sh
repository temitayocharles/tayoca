#!/usr/bin/env bash
# Reference: nightly backup with honest exit status.
#
# Lab adapters: SOURCE_DIR / BACKUP_DIR replace the book's /srv/app-data and
# s3://company-backups. Swapping the final "cp" for "aws s3 cp" (or your
# object-store CLI) is the only production delta.
set -euo pipefail

source_dir=${SOURCE_DIR:-/srv/app-data}
backup_dir=${BACKUP_DIR:-./backups}
mkdir -p "$backup_dir"

# Unique object name per run: no silent nightly overwrite.
timestamp=$(date -u +%Y%m%dT%H%M%SZ)
work=$(mktemp -d)
backup="$work/app-backup-$timestamp.tgz"
destination="$backup_dir/app-backup-$timestamp.tgz"

# Temp files are removed on every exit path, success or failure.
trap 'rm -rf "$work"' EXIT

tar -czf "$backup" -C "$source_dir" .
test -s "$backup"                       # empty archives are failures
cp "$backup" "$destination"

# wc -c works on GNU and BSD; "stat -c %s" is GNU-only on macOS.
bytes=$(wc -c < "$destination" | tr -d ' ')
printf 'Backup uploaded: %s (%s bytes)\n' "$destination" "$bytes"
