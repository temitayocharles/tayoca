#!/usr/bin/env bash
# Sweep stale .tmp files out of the given directory.

DIR=$1

for file in $(find $DIR -type f -name "*.tmp"); do
  rm $file
done
