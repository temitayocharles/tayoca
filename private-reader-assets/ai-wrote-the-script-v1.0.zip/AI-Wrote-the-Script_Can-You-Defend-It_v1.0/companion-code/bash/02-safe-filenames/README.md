# Bash 02 — The unquoted filename

**Difficulty:** Foundation · **Target time:** 20 minutes

An AI-generated sweeper deletes `*.tmp` files. Shell word splitting turns
the path `reports/scan backup.tmp` into two arguments, the second of which
— `backup.tmp` — is resolved in *whatever directory you ran the script
from*. The lab fixture proves this by deleting an unrelated file that sits
outside the target tree entirely.

## Layout

- `broken/clean_tmp.sh` — the AI-generated script (defects intact)
- `solution/clean_tmp.sh` — the reference solution
- `fixtures/make_fixtures.sh` — builds a hostile-filename tree on demand
- `tests/test_filenames.py` — prove-out

## Run it

Always build the fixture in a throwaway directory:

```bash
cd labs
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest bash/02-safe-filenames/tests -v
```

By hand:

```bash
scratch=$(mktemp -d)
bash fixtures/make_fixtures.sh "$scratch"
( cd "$scratch/run" && bash "$OLDPWD/broken/clean_tmp.sh" "$scratch/cleanup" )   # watch the damage
ls "$scratch/run/backup.tmp" 2>/dev/null || echo "COLLATERAL: run/backup.tmp was deleted"
find "$scratch/cleanup" -name '*.tmp'             # real targets, still there
bash fixtures/make_fixtures.sh "$scratch" >/dev/null   # rebuild
bash solution/clean_tmp.sh "$scratch/cleanup"     # only .tmp files disappear
```

## Reset

```bash
rm -rf "$scratch"
```

## What to look for

1. Trace `report.tmp backup` through the broken script word by word. Which
   expansion splits it? Which then *glob-expands* the pieces?
2. Why `find ... -print0 | while IFS= read -r -d ''` — what byte can a
   POSIX filename never contain?
3. What does `rm -- "$file"` defend against that `rm "$file"` does not?
4. Why does the solution validate `$#` and `-d` *before* calling `find`?

**Portability:** `find -print0` is a GNU/BSD extension (fine on Linux and
macOS), not POSIX. `xargs -0` matching notes apply. Check your targets.

**Stretch:** make the sweeper print a per-directory summary and a dry-run
mode (`DRY_RUN=1`). Replace the `while` loop with `find -delete` and explain
exactly which problems that solves and which it does not.
