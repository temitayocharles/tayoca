#!/usr/bin/env bash
# Build the hostile-filename fixture tree for Lab Bash 02.
# Usage: make_fixtures.sh <target-dir>
#
# Creates:
#   <target-dir>/cleanup/            sweep targets + protected files
#   <target-dir>/run/backup.tmp      unrelated file OUTSIDE the target tree,
#                                    standing in the directory you run from.
#
# The broken script's word splitting is what reaches out of the tree:
# "reports/scan backup.tmp" fragments into ".../reports/scan" + "backup.tmp",
# and the second fragment is resolved in the caller's current directory.
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 <target-dir>" >&2
  exit 64
fi

root=$1
mkdir -p "$root/cleanup/nested/deep" "$root/cleanup/reports" "$root/run"
cd "$root/cleanup"

# Legitimate sweep targets: each a hard mode for naive word splitting.
: > "normal.tmp"
: > "with space.tmp"
: > "$(printf 'with\nnewline.tmp')"
: > "-dash.tmp"
: > "config -rf.tmp"                 # fragment parses as rm options
: > "nested/deep/deep.tmp"
: > "reports/scan backup.tmp"        # fragment escapes into the caller's cwd

# Protected bystanders (must survive):
printf 'keep\n' > "keep me.txt"
printf 'keep\n' > "nested/notes.txt"

readonly_marker="WEEKLY REPORT DATA - not in the target tree"
printf '%s\n' "$readonly_marker" > "$root/run/backup.tmp"

echo "Fixture tree created at: $root (targets in cleanup/, runner dir run/)"
