#!/usr/bin/env bash
# Reference: filename-safe .tmp sweeper.
set -euo pipefail

if [[ $# -ne 1 ]]; then
  echo "Usage: $0 <directory>" >&2
  exit 64  # EX_USAGE
fi

dir=$1
[[ -d "$dir" ]] || { echo "Not a directory: $dir" >&2; exit 66; }

# Filenames are data, not code. -print0 + read -d '' preserves every byte
# except NUL, which POSIX paths cannot contain. Quotes stop splitting and
# globbing; "--" stops option injection.
find "$dir" -type f -name '*.tmp' -print0 |
while IFS= read -r -d '' file; do
  printf 'Removing %q\n' "$file"
  rm -- "$file"
done
