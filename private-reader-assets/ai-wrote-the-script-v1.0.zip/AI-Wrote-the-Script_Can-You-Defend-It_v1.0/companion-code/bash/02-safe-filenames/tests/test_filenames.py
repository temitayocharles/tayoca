"""Validation for Lab Bash 02 -- the unquoted filename.

Fixture (built by fixtures/make_fixtures.sh into a throwaway directory)::

    cleanup/                        the directory being swept
      normal.tmp                    plain target
      with space.tmp                space in name
      with<newline>newline.tmp      newline in name
      -dash.tmp                     leading dash basename
      config -rf.tmp                splits; second fragment parses as rm options
      nested/deep/deep.tmp          nested target
      reports/scan backup.tmp       splits; fragment escapes into caller's cwd
      keep me.txt                   protected (not .tmp)
      nested/notes.txt              protected (not .tmp)
    run/
      backup.tmp                    OUTSIDE the tree; stands in the cwd

The broken script, run from run/, fragments "reports/scan backup.tmp" into
".../reports/scan" and "backup.tmp", and rm's the *current directory's*
backup.tmp -- collateral damage outside the target tree.

Portability note: GNU find accepts an omitted path and defaults to the current
directory when the first remaining token is an expression such as ``-type``.
BSD find (macOS) requires an explicit path. Therefore the no-argument defect
manifests differently: GNU systems can sweep the caller's cwd, while macOS
prints a find error but the surrounding shell script can still finish with a
misleading zero exit status. Both are defects in the generated script because
it never validates its required directory argument.
"""
from __future__ import annotations

import platform
import subprocess
from pathlib import Path

from _shared.runner import run_bash

LAB = Path(__file__).resolve().parent.parent
BROKEN = LAB / "broken" / "clean_tmp.sh"
SOLUTION = LAB / "solution" / "clean_tmp.sh"
BUILDER = LAB / "fixtures" / "make_fixtures.sh"

TARGET_COUNT = 7


def build(tmp_path: Path) -> tuple[Path, Path]:
    subprocess.run(["bash", str(BUILDER), str(tmp_path)],
                   check=True, capture_output=True)
    return tmp_path / "cleanup", tmp_path / "run"


def remaining_tmp(root: Path) -> set[str]:
    return {str(p.relative_to(root)) for p in root.rglob("*.tmp")}


class TestBroken:
    def test_partial_deletion_looks_successful_but_isnt(self, tmp_path):
        """The worst failure mode: it half-works, so nobody suspects it."""
        tree, run = build(tmp_path)
        result = run_bash(BROKEN, args=[str(tree)], cwd=run)
        remaining = remaining_tmp(tree)

        # Simple filenames vanish -- "it works on my machine".
        assert "normal.tmp" not in remaining
        assert "nested/deep/deep.tmp" not in remaining
        # Anything with whitespace survives silently-in-effect...
        assert "with space.tmp" in remaining
        assert "with\nnewline.tmp" in remaining
        assert "reports/scan backup.tmp" in remaining
        assert "config -rf.tmp" in remaining
        # ...and rm complained the whole time. Exact wording differs between
        # GNU coreutils and BSD/macOS rm, so validate the signal, not prose.
        assert result.stderr.strip()

    def test_word_splitting_deletes_a_file_outside_the_tree(self, tmp_path):
        """THE headline defect: run/backup.tmp is not ours to delete."""
        tree, run = build(tmp_path)
        run_bash(BROKEN, args=[str(tree)], cwd=run)
        assert not (run / "backup.tmp").exists()  # unrelated file, deleted
        assert (tree / "reports" / "scan backup.tmp").exists()  # target stayed

    def test_missing_argument_is_not_validated(self, tmp_path):
        """Missing DIR is unsafe on GNU find and misleading on BSD find."""
        tree, _ = build(tmp_path)
        result = run_bash(BROKEN, cwd=tree)
        remaining = remaining_tmp(tree)

        if platform.system() == "Darwin":
            # BSD find requires an explicit path. The command substitution
            # errors, the loop executes zero times, and the script itself can
            # still reach EOF with status 0. Nothing is deleted, but CI can
            # falsely read the run as successful.
            assert "normal.tmp" in remaining
            assert len(remaining) == TARGET_COUNT
            assert result.stderr.strip()
            assert result.returncode == 0
        else:
            # GNU find treats a leading expression as "find . <expr>". The
            # broken script therefore sweeps the caller's current directory.
            assert "normal.tmp" not in remaining
            assert "with space.tmp" in remaining
            assert result.stderr.strip()
            # Exit status is accidental, not designed. On the validated GNU
            # fixture the final rm failure makes it 1.
            assert result.returncode == 1


class TestSolution:
    def test_exactly_the_targets_are_removed(self, tmp_path):
        tree, run = build(tmp_path)
        result = run_bash(SOLUTION, args=[str(tree)], cwd=run)
        assert result.returncode == 0
        assert remaining_tmp(tree) == set()
        assert (tree / "keep me.txt").exists()
        assert (tree / "nested" / "notes.txt").exists()
        # The unrelated file outside the tree survives: cwd stays irrelevant.
        assert (run / "backup.tmp").read_text().startswith("WEEKLY REPORT DATA")
        assert result.stdout.count("Removing") == TARGET_COUNT

    def test_requires_exactly_one_argument(self, tmp_path):
        result = run_bash(SOLUTION, cwd=tmp_path)
        assert result.returncode == 64
        assert "Usage:" in result.stderr

    def test_rejects_non_directory(self, tmp_path):
        result = run_bash(SOLUTION, args=[str(tmp_path / "nope")])
        assert result.returncode == 66
        assert "Not a directory" in result.stderr

    def test_idempotent_second_run(self, tmp_path):
        tree, _ = build(tmp_path)
        first = run_bash(SOLUTION, args=[str(tree)])
        second = run_bash(SOLUTION, args=[str(tree)])
        assert first.returncode == 0 and second.returncode == 0
        assert second.stdout.count("Removing") == 0
