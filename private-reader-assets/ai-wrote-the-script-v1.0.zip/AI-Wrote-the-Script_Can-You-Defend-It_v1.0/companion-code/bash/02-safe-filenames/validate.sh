#!/usr/bin/env bash
# Validate Lab Bash 02: syntax, lint, behavior.
set -euo pipefail
cd "$(dirname "$0")"

bash -n broken/clean_tmp.sh solution/clean_tmp.sh fixtures/make_fixtures.sh
echo "bash -n: OK"

if command -v shellcheck >/dev/null; then
  shellcheck -x solution/clean_tmp.sh fixtures/make_fixtures.sh
  echo "shellcheck (solution + fixtures): OK"
  echo "shellcheck (broken, findings expected as teaching material):"
  shellcheck -x broken/clean_tmp.sh || true
else
  echo "shellcheck: not installed, skipping"
fi

python3 -m pytest tests -v
