"""Validation for Lab Bash 03 -- the secret leaking into CI logs."""
from __future__ import annotations

from pathlib import Path

from _shared.mock_service import BehaviorServer
from _shared.runner import run_bash

LAB = Path(__file__).resolve().parent.parent
BROKEN = LAB / "broken" / "deploy.sh"
SOLUTION = LAB / "solution" / "deploy.sh"

CANARY = "tok-CANARY-9f3b21-must-never-appear"


class TestBroken:
    def test_xtrace_leaks_the_token(self):
        """The defect: set -x echoes the expanded Authorization header."""
        with BehaviorServer("ok") as server:
            result = run_bash(BROKEN, env={
                "DEPLOY_TOKEN": CANARY,
                "DEPLOY_URL": f"{server.base_url}/release",
            })
        assert result.returncode == 0
        assert CANARY in result.combined  # CI log just captured the secret

    def test_http_500_still_exits_zero(self):
        """curl without --fail exits 0 even when the server says 500."""
        with BehaviorServer("fail500") as server:
            result = run_bash(BROKEN, env={
                "DEPLOY_TOKEN": CANARY,
                "DEPLOY_URL": f"{server.base_url}/release",
            })
        assert result.returncode == 0  # a failed release "succeeded"


class TestSolution:
    def test_token_is_not_printed(self):
        with BehaviorServer("ok") as server:
            result = run_bash(SOLUTION, env={
                "DEPLOY_TOKEN": CANARY,
                "DEPLOY_URL": f"{server.base_url}/release",
            })
        assert result.returncode == 0
        assert CANARY not in result.combined
        assert "Authorization" not in result.combined
        assert "Triggering release at" in result.stdout

    def test_missing_token_fails_clearly_before_curl_runs(self):
        with BehaviorServer("ok") as server:
            result = run_bash(SOLUTION, env={
                "DEPLOY_TOKEN": None,  # remove from environment entirely
                "DEPLOY_URL": f"{server.base_url}/release",
            })
        assert result.returncode == 1
        assert "DEPLOY_TOKEN is required" in result.stderr

    def test_http_failures_fail_the_script_with_body(self):
        with BehaviorServer("fail500") as server:
            result = run_bash(SOLUTION, env={
                "DEPLOY_TOKEN": CANARY,
                "DEPLOY_URL": f"{server.base_url}/release",
            })
        assert result.returncode != 0
        assert "Internal Server Error" in result.combined  # --fail-with-body
        assert CANARY not in result.combined
