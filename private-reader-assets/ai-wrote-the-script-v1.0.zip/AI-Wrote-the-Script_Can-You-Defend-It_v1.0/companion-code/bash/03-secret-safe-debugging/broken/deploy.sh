#!/usr/bin/env bash
# Trigger a release with verbose diagnostics (debugging a flaky deploy).
# Lab adapter: DEPLOY_URL points at the local mock; production posts to
# https://deploy.example.com/release
set -x

TOKEN="$DEPLOY_TOKEN"
curl -H "Authorization: Bearer $TOKEN" \
  -X POST "${DEPLOY_URL:-https://deploy.example.com/release}"

set +x
