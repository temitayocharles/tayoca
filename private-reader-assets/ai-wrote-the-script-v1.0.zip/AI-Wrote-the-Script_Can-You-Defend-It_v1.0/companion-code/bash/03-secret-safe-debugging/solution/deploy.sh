#!/usr/bin/env bash
# Reference: secret-safe release trigger.
set -euo pipefail

# Fail fast and clearly when the credential is absent. The ?-expansion
# prints this message to stderr and exits 1 before curl ever runs.
: "${DEPLOY_TOKEN:?DEPLOY_TOKEN is required}"

url=${DEPLOY_URL:-https://deploy.example.com/release}

# No xtrace anywhere near the secret. The diagnostics that remain --
# target URL, method, HTTP outcome -- are enough to triage without
# exposing the credential value.
echo "Triggering release at ${url}"

# --fail-with-body requires curl >= 7.76.0 (check: curl --version).
# On older curl, use --fail (drops the response body from the log).
curl --fail-with-body --silent --show-error \
  -H "Authorization: Bearer ${DEPLOY_TOKEN}" \
  -X POST "$url"

echo
echo "Release request accepted"
