#!/usr/bin/env bash
# Validate Lab Bash 03: syntax, lint, behavior.
set -euo pipefail
cd "$(dirname "$0")"

bash -n broken/deploy.sh solution/deploy.sh
echo "bash -n: OK"

if command -v shellcheck >/dev/null; then
  shellcheck -x solution/deploy.sh
  echo "shellcheck (solution): OK"
  echo "shellcheck (broken, findings expected as teaching material):"
  shellcheck -x broken/deploy.sh || true
else
  echo "shellcheck: not installed, skipping"
fi

python3 -m pytest tests -v
