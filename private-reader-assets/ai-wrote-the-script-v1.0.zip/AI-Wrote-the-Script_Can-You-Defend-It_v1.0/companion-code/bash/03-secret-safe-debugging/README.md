# Bash 03 — The secret leaking into CI logs

**Difficulty:** Foundation / Security · **Target time:** 15 minutes

The AI-generated script enables `set -x` for debugging and then builds the
`Authorization` header inside the traced region. Every CI run archives the
credential in its logs. "The CI masks it" is luck, not a control.

## Layout

- `broken/deploy.sh` — the AI-generated script (defects intact)
- `solution/deploy.sh` — the reference solution
- `tests/test_secret_safety.py` — prove-out, including a canary token

## Lab adapter

`DEPLOY_URL` (default `https://deploy.example.com/release`) lets the lab
POST to the local mock service instead of the internet.

## Run it

```bash
cd labs
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest bash/03-secret-safe-debugging/tests -v
```

Watch the leak by hand:

```bash
python3 - <<'PY' &
import http.server, threading
h = http.server.ThreadingHTTPServer(("127.0.0.1", 8787),
    type("H", (http.server.BaseHTTPRequestHandler,), {
        "do_POST": lambda s: (s.send_response(200), s.end_headers()),
        "log_message": lambda *a: None}))
threading.Thread(target=h.serve_forever, daemon=True).start()
import time; time.sleep(30)
PY
sleep 0.5
DEPLOY_TOKEN=tok-DEMO-123 DEPLOY_URL=http://127.0.0.1:8787/release \
  bash broken/deploy.sh 2>&1 | grep -c tok-DEMO-123   # secret, in the log
kill %1
```

## Reset

Nothing persists. Kill any leftover mock server.

## Version note

`--fail-with-body` needs curl ≥ 7.76.0 (`curl --version`). On older curl —
including some macOS-shipped versions — use `--fail` and log the status
line yourself. Validate the flag on your actual CI image, not your laptop.

## What to look for

1. In the broken script, does the *assignment* `TOKEN="$DEPLOY_TOKEN"`
   leak under `set -x`, or only the curl line? (Both print — why?)
2. CI secret masking usually replaces exact literal matches. What happens
   to the masked value after base64, URL-encoding, or a quoting change?
3. Why is `${DEPLOY_TOKEN:?...}` better than `if [[ -z ... ]]` here —
   what does `set -u` alone give you?
4. What diagnostics remain in the solution, and are they enough to triage
   a failed release without the token?

**Stretch:** read the token from a file descriptor or a mounted secret file
instead of the environment. Which process-listing attacks does that close?
