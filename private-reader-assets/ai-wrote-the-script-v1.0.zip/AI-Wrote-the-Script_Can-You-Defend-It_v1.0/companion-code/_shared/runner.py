"""Helpers for running lab scripts as subprocesses in tests."""
from __future__ import annotations

import os
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path


@dataclass
class Run:
    returncode: int
    stdout: str
    stderr: str
    elapsed: float

    @property
    def combined(self) -> str:
        return self.stdout + "\n" + self.stderr


def _merge_env(env: dict | None) -> dict:
    """Merge env overrides; a None value REMOVES the variable entirely."""
    full_env = dict(os.environ)
    for key, value in (env or {}).items():
        if value is None:
            full_env.pop(key, None)
        else:
            full_env[key] = value
    return full_env


def run_python(script: Path, env: dict | None = None, cwd: Path | None = None,
               timeout: float = 30.0, args: list[str] | None = None) -> Run:
    full_env = _merge_env(env)
    start = time.monotonic()
    proc = subprocess.run(
        [sys.executable, str(script), *(args or [])],
        capture_output=True, text=True, cwd=str(cwd) if cwd else None,
        env=full_env, timeout=timeout,
    )
    return Run(proc.returncode, proc.stdout, proc.stderr,
               time.monotonic() - start)


def run_bash(script: Path, env: dict | None = None, cwd: Path | None = None,
             timeout: float = 30.0, args: list[str] | None = None) -> Run:
    full_env = _merge_env(env)
    start = time.monotonic()
    proc = subprocess.run(
        ["bash", str(script), *(args or [])],
        capture_output=True, text=True, cwd=str(cwd) if cwd else None,
        env=full_env, timeout=timeout,
    )
    return Run(proc.returncode, proc.stdout, proc.stderr,
               time.monotonic() - start)
