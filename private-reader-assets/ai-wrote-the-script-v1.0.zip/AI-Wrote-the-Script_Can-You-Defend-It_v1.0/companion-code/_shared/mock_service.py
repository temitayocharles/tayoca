"""Local mock services for the practice-pack labs.

Every lab that touches the network in the printed manuscript can run fully
offline against these servers. They are deliberately simple stdlib
"http.server" implementations so learners can read them end to end.

Provided services:

* :class:`BehaviorServer` -- one behavior per bound port. Used by the
  health-checker and bounded-concurrency labs, where "many hosts" means
  many loopback ports.
* :class:`InventoryServer` -- a paginated JSON API with authentication,
  a one-shot 503 page, a rate-limited page, a cursor loop, a schema
  violation, and a cross-origin "next" URL, so every pagination failure
  mode is exercisable locally.
"""
from __future__ import annotations

import json
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class _BehaviorHandler(BaseHTTPRequestHandler):
    """Responds to every request according to the server's configured role."""

    role = "ok"
    slow_seconds = 10.0

    server_version = "PackMock/1.0"

    def _respond(self) -> None:
        if self.role == "ok":
            body = json.dumps({"status": "ok"}).encode()
            self.send_response(200)
        elif self.role == "degraded":
            # HTTP says 200; the body contract says otherwise.
            body = json.dumps({"status": "degraded", "database": "down"}).encode()
            self.send_response(200)
        elif self.role == "fail500":
            body = b"Internal Server Error"
            self.send_response(500)
        elif self.role == "fail503":
            body = b"Service Unavailable"
            self.send_response(503)
        elif self.role == "slow":
            time.sleep(self.slow_seconds)
            body = json.dumps({"status": "ok", "note": "very slow"}).encode()
            self.send_response(200)
        else:  # pragma: no cover - configuration error
            body = b"unknown role"
            self.send_response(500)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802 (stdlib naming)
        self._respond()

    def do_POST(self) -> None:  # noqa: N802 (stdlib naming)
        # Read any request body so the connection stays well behaved, then
        # answer like a deploy endpoint accepting a release request.
        length = int(self.headers.get("Content-Length") or 0)
        if length:
            self.rfile.read(length)
        self._respond()

    def log_message(self, format: str, *args: object) -> None:  # noqa: A002
        pass  # keep test output clean


class BehaviorServer:
    """Context manager binding one loopback port to one behavior role."""

    def __init__(self, role: str = "ok", slow_seconds: float = 10.0) -> None:
        handler = type(
            "RoleHandler",
            (_BehaviorHandler,),
            {"role": role, "slow_seconds": slow_seconds},
        )
        self._httpd = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self.address = f"127.0.0.1:{self._httpd.server_address[1]}"
        self.base_url = f"http://{self.address}"
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)

    def __enter__(self) -> "BehaviorServer":
        self._thread.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self._httpd.shutdown()
        self._httpd.server_close()
        self._thread.join(timeout=5)


def refused_address() -> str:
    """A loopback address where nothing is listening (connection refused).

    Port 1 is conventionally closed; using it avoids port-allocation races.
    """
    return "127.0.0.1:1"


# --------------------------------------------------------------------------
# Paginated inventory API
# --------------------------------------------------------------------------

ITEMS = [
    {"id": "i-001", "name": "api-1"},
    {"id": "i-002", "name": "api-2"},
    {"id": "i-003", "name": "worker-1"},
    {"id": "i-004", "name": "worker-2"},
    {"id": "i-005", "name": "queue-1"},
    {"id": "i-006", "name": "cache-1"},
    {"id": "i-007", "name": "db-1"},
]
PAGE_SIZE = 3
VALID_TOKEN = "lab-token"


class _InventoryHandler(BaseHTTPRequestHandler):
    server_version = "PackMockInventory/1.0"

    def _json(self, code: int, payload: dict, extra_headers: dict | None = None) -> None:
        body = json.dumps(payload).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        for key, value in (extra_headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:  # noqa: N802 (stdlib naming)
        self.server.request_count += 1
        if not self.path.startswith("/api/v1/instances"):
            self._json(404, {"error": "not found", "path": self.path})
            return

        auth = self.headers.get("Authorization", "")
        if auth != f"Bearer {self.server.token}":
            self._json(401, {"error": "unauthorized"})
            return

        base = f"http://127.0.0.1:{self.server.server_address[1]}"
        path, _, query = self.path.partition("?")
        params = dict(
            pair.split("=", 1) for pair in query.split("&") if "=" in pair
        )
        cursor = params.get("cursor", "")

        if cursor == "":
            self._json(200, {
                "items": ITEMS[0:PAGE_SIZE],
                "next": f"{base}{path}?cursor=p2",
            })
        elif cursor == "p2":
            # First attempt at page 2 fails with a retryable 503, once.
            if not self.server.page2_failed:
                self.server.page2_failed = True
                self._json(503, {"error": "backend restarting, try again"})
            else:
                self._json(200, {
                    "items": ITEMS[PAGE_SIZE:2 * PAGE_SIZE],
                    "next": f"{base}{path}?cursor=p3",
                })
        elif cursor == "p3":
            self._json(200, {"items": ITEMS[2 * PAGE_SIZE:], "next": None})
        elif cursor == "rl":
            # Rate-limited once, honoring Retry-After unlocks the page.
            if not self.server.rate_limited:
                self.server.rate_limited = True
                self._json(429, {"error": "slow down"}, {"Retry-After": "1"})
            else:
                self._json(200, {"items": ITEMS[2 * PAGE_SIZE:], "next": None})
        elif cursor == "loop":
            payload = {"items": [ITEMS[0]], "next": f"{base}{path}?cursor=loop"}
            self._json(200, payload)
        elif cursor == "badschema":
            self._json(200, {"data": ITEMS[0:PAGE_SIZE]})  # missing "items"
        elif cursor == "weirdnext":
            self._json(200, {
                "items": [ITEMS[0]],
                "next": "https://attacker.example.com/api/v1/instances",
            })
        elif cursor == "loop-kicker":
            self._json(200, {"items": [ITEMS[0]], "next": f"{base}{path}?cursor=loop"})
        else:
            self._json(404, {"error": "unknown cursor", "cursor": cursor})

    def log_message(self, format: str, *args: object) -> None:  # noqa: A002
        pass


class InventoryServer:
    """Context manager for the paginated inventory API."""

    def __init__(self, token: str = VALID_TOKEN) -> None:
        self.token = token
        handler = _InventoryHandler
        self._httpd = ThreadingHTTPServer(("127.0.0.1", 0), handler)
        self._httpd.page2_failed = False
        self._httpd.rate_limited = False
        self._httpd.request_count = 0
        self._httpd.token = token
        self.address = f"127.0.0.1:{self._httpd.server_address[1]}"
        self.base_url = f"http://{self.address}"
        self.start_url = f"{self.base_url}/api/v1/instances"
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)

    @property
    def request_count(self) -> int:
        return self._httpd.request_count

    def __enter__(self) -> "InventoryServer":
        self._thread.start()
        return self

    def __exit__(self, *exc: object) -> None:
        self._httpd.shutdown()
        self._httpd.server_close()
        self._thread.join(timeout=5)
