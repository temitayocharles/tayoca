#!/usr/bin/env bash
# Optional real-cluster validation for Lab Bash 05.
#
# Runs ONLY when kind and kubectl are installed and Docker is available.
# Otherwise it explains what it would have done and exits 0, so
# labs/validate_all.sh can include it unconditionally.
set -euo pipefail
cd "$(dirname "$0")/bash/05-kubernetes-rollout"

if ! command -v kubectl >/dev/null 2>&1; then
  echo "SKIP: kubectl not installed -- real-cluster rollout validation not possible."
  echo "      Static validation (bash -n, shellcheck, YAML shape) is always run."
  exit 0
fi

if ! command -v kind >/dev/null 2>&1; then
  echo "SKIP: kind not installed -- see lab README for manual cluster steps."
  exit 0
fi

if ! docker info >/dev/null 2>&1; then
  echo "ERROR: Docker daemon is not reachable. Start Docker/Colima first." >&2
  exit 1
fi

run_with_timeout() {
  local seconds=$1
  shift
  if command -v timeout >/dev/null 2>&1; then
    timeout "$seconds" "$@"
    return $?
  fi
  if command -v gtimeout >/dev/null 2>&1; then
    gtimeout "$seconds" "$@"
    return $?
  fi
  python3 - "$seconds" "$@" <<'PY'
import subprocess, sys
seconds = int(sys.argv[1])
cmd = sys.argv[2:]
try:
    cp = subprocess.run(cmd, timeout=seconds)
    raise SystemExit(cp.returncode)
except subprocess.TimeoutExpired:
    raise SystemExit(124)
PY
}

cluster="pack-rollout-lab"
echo "==> creating disposable kind cluster: $cluster"
# Remove a stale cluster from an interrupted prior run, then create a fresh one.
kind delete cluster --name "$cluster" >/dev/null 2>&1 || true
kind create cluster --name "$cluster"
trap 'kind delete cluster --name "$cluster" >/dev/null 2>&1 || true' EXIT

echo "==> broken script against failing manifest (observe: no internal bound)"
# The broken script hardcodes deployment.yaml, so stage it in a scratch dir.
# We time-box externally: hanging forever IS the defect being demonstrated.
scratch=$(mktemp -d)
cp manifests/deployment-broken.yaml "$scratch/deployment.yaml"
cp broken/deploy.sh "$scratch/"
rc=0
(cd "$scratch" && run_with_timeout 30 bash deploy.sh) || rc=$?
rm -rf "$scratch"
if [[ $rc -eq 124 ]]; then
  echo "ok (defect demonstrated): broken script hung past 30s; killed externally"
else
  echo "note: broken script exited with rc=$rc (cluster timing may surface failure sooner)"
fi

echo "==> solution against healthy manifest (expect success)"
NAMESPACE=default DEPLOYMENT=api MANIFEST=manifests/deployment.yaml \
  ROLLOUT_TIMEOUT=180s bash solution/deploy.sh

echo "==> solution against broken manifest (expect bounded failure + evidence)"
if NAMESPACE=default DEPLOYMENT=api MANIFEST=manifests/deployment-broken.yaml \
   ROLLOUT_TIMEOUT=60s bash solution/deploy.sh; then
  echo "UNEXPECTED: broken manifest rolled out successfully"
  exit 1
else
  echo "OK: rollout failed within its bound and evidence was collected"
fi

kubectl delete deployment api >/dev/null 2>&1 || true
echo "Kubernetes lab validation complete"
