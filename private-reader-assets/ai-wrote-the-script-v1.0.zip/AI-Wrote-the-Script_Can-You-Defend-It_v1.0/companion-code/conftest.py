"""Pytest configuration for the practice-pack labs."""
from __future__ import annotations

import sys
from pathlib import Path

LABS_ROOT = Path(__file__).resolve().parent
SHARED = LABS_ROOT / "_shared"

for path in (str(LABS_ROOT), str(SHARED)):
    if path not in sys.path:
        sys.path.insert(0, path)
