#!/usr/bin/env bash
# Run every lab validation end to end.
# Usage: bash labs/validate_all.sh [log-dir]
set -uo pipefail

here=$(cd "$(dirname "$0")" && pwd)
log_dir=${1:-"$here/../validation/logs"}
mkdir -p "$log_dir"

py="${PY:-python3}"

echo "Lab validation started: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "Host: $(uname -srm)"
"$py" --version
bash --version | head -1
if command -v shellcheck >/dev/null; then shellcheck --version | grep version; else
  echo "shellcheck: NOT INSTALLED (lint steps will be skipped)"; fi

overall_rc=0
for lab in "$here"/python/0* "$here"/bash/0*; do
  name=$(basename "$(dirname "$lab")")/$(basename "$lab")
  log="$log_dir/$(basename "$(dirname "$lab")")-$(basename "$lab").log"
  echo
  echo "=== $name"
  if ( cd "$lab" && bash validate.sh ) >"$log" 2>&1; then
    echo "PASS $name (log: $log)"
  else
    echo "FAIL $name (log: $log)"
    overall_rc=1
  fi
done

echo
echo "=== kubernetes live-cluster probe"
if ( cd "$here" && bash validate_kubernetes.sh ) >"$log_dir/kubernetes-live.log" 2>&1; then
  echo "PASS/SKIP kubernetes-live (log: $log_dir/kubernetes-live.log)"
else
  echo "FAIL kubernetes-live (log: $log_dir/kubernetes-live.log)"
  overall_rc=1
fi

echo
echo "Lab validation finished: $(date -u +%Y-%m-%dT%H:%M:%SZ)  rc=$overall_rc"
exit "$overall_rc"
