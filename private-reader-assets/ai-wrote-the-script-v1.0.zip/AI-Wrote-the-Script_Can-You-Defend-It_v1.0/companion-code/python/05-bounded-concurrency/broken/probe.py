#!/usr/bin/env python3
# Lab adapters: HOSTS_FILE / PROBE_SCHEME point the probe at local mocks.
import os
from concurrent.futures import ThreadPoolExecutor

import requests

hosts_file = os.environ.get("HOSTS_FILE", "hosts.txt")
scheme = os.environ.get("PROBE_SCHEME", "https")
hosts = [line.strip() for line in open(hosts_file, encoding="utf-8")
         if line.strip()]


def check(host):
    return requests.get(f"{scheme}://{host}/health", timeout=5).status_code


with ThreadPoolExecutor(max_workers=len(hosts)) as pool:
    results = list(pool.map(check, hosts))

print(results)
