# Python 05 — The concurrent probe that overwhelms the target

**Difficulty:** Intermediate · **Target time:** 25 minutes

An AI "speedup" sets `max_workers=len(hosts)`. Against a 5,000-host
inventory that is 5,000 simultaneous sockets against your file-descriptor
limit, your egress bandwidth, and the target's rate limiter. "Make it
parallel" is not the same as "make it reliable."

## Layout

- `broken/probe.py` — the AI-generated script (defects intact)
- `solution/probe.py` — the reference solution
- `fixtures/hosts.txt` — an example fleet inventory
- `tests/test_probe.py` — prove-out against local mock "hosts"

## Lab adapter

"Hosts" in the lab are loopback ports: each mock server binds one port and
plays one role (`ok`, `fail500`, slow, or connection-refused via a closed
port). `HOSTS_FILE` points at the inventory and `PROBE_SCHEME=http` keeps
everything offline. The manuscript version probes `https://{host}/health`.

## Run it

```bash
cd labs
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest python/05-bounded-concurrency/tests -v
```

## Reset

Nothing persists. Delete `.venv` to remove the environment.

## What to look for

1. Who sets the upper bound when concurrency is derived from input size?
2. What happens to the 4,999 good results when host #17 raises inside
   `pool.map`?
3. File descriptors are finite (check `ulimit -n`): every in-flight socket
   costs one. What else in your process needs descriptors?
4. A health sweep is also a load test. Whose rate limiter do you hit, and
   what does it do to real customers when you find it?

**Stretch:** add per-host deadlines and a token-bucket rate limiter
(e.g. max N requests/second across the pool). Explain which limit — worker
count or request rate — protects the *target*, and which protects the
*caller*.
