"""Validation for Lab Python 05 -- the concurrent probe that overwhelms
the target.

"Hosts" are bound mock ports on loopback, so nothing external is touched.
"""
from __future__ import annotations

from pathlib import Path
from contextlib import ExitStack

from _shared.mock_service import BehaviorServer, refused_address
from _shared.runner import run_python

LAB = Path(__file__).resolve().parent.parent
BROKEN = LAB / "broken" / "probe.py"
SOLUTION = LAB / "solution" / "probe.py"

OK_HOSTS = 6


def fleet(stack: ExitStack) -> list[str]:
    """Six healthy mock hosts, one HTTP 500 host, one refused host."""
    hosts = [stack.enter_context(BehaviorServer("ok")).address
             for _ in range(OK_HOSTS)]
    hosts.append(stack.enter_context(BehaviorServer("fail500")).address)
    hosts.append(refused_address())
    return hosts


def run_against(tmp_path: Path, script: Path, hosts: list[str]):
    hosts_file = tmp_path / "hosts.txt"
    hosts_file.write_text("\n".join(hosts) + "\n", encoding="utf-8")
    env = {"HOSTS_FILE": str(hosts_file), "PROBE_SCHEME": "http"}
    return run_python(script, env=env)


class TestBroken:
    def test_one_dead_host_kills_the_batch(self, tmp_path):
        hosts = [h for h in []]  # placeholder, fleet built below
        with ExitStack() as stack:
            hosts = fleet(stack)
            result = run_against(tmp_path, BROKEN, hosts)
        assert result.returncode != 0
        assert "ConnectionError" in result.stderr
        # No summary, no per-host evidence for the healthy majority.
        assert "checked=" not in result.stdout

    def test_workers_scale_with_inventory(self):
        """The defect is structural: workers == len(hosts)."""
        source = BROKEN.read_text(encoding="utf-8")
        assert "max_workers=len(hosts)" in source


class TestSolution:
    def test_failures_are_isolated_and_counted(self, tmp_path):
        with ExitStack() as stack:
            hosts = fleet(stack)
            result = run_against(tmp_path, SOLUTION, hosts)
        assert result.returncode == 1
        assert "checked=8 failed=2" in result.stdout  # 500 + refused
        # Both failure kinds carry per-host evidence.
        assert "HTTP 500" in result.stdout
        assert f"{refused_address()}" in result.stdout

    def test_healthy_fleet_exits_zero(self, tmp_path):
        with ExitStack() as stack:
            hosts = [stack.enter_context(BehaviorServer("ok")).address
                     for _ in range(3)]
            result = run_against(tmp_path, SOLUTION, hosts)
        assert result.returncode == 0
        assert "checked=3 failed=0" in result.stdout

    def test_worker_count_is_capped(self):
        source = SOLUTION.read_text(encoding="utf-8")
        assert "MAX_WORKERS = 20" in source
        assert "max_workers=len(hosts)" not in source
