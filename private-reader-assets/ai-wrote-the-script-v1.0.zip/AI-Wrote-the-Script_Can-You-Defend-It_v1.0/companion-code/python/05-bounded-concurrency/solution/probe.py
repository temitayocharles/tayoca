#!/usr/bin/env python3
"""Reference: bounded-concurrency health probe.

Worker count is a capacity decision, not the inventory size. Per-host
failure detail is preserved as data instead of killing the batch.

Lab adapters: HOSTS_FILE and PROBE_SCHEME let the probe run against the
local mock service (http) instead of real https fleet endpoints.
"""
from __future__ import annotations

import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests

MAX_WORKERS = 20               # choose from evidence + target rate limits
PROBE_TIMEOUT = (2, 5)         # (connect, read) seconds
SCHEME = os.environ.get("PROBE_SCHEME", "https")
HOSTS_FILE = os.environ.get("HOSTS_FILE", "hosts.txt")


def check(host: str) -> tuple[str, int | None, str | None]:
    """Return (host, status, error). Failure is data, not an exception."""
    try:
        response = requests.get(f"{SCHEME}://{host}/health",
                                timeout=PROBE_TIMEOUT)
        return host, response.status_code, None
    except requests.RequestException as exc:
        return host, None, str(exc)


def main() -> int:
    with open(HOSTS_FILE, encoding="utf-8") as f:
        hosts = [line.strip() for line in f if line.strip()]

    workers = min(MAX_WORKERS, max(1, len(hosts)))
    print(f"Probing {len(hosts)} hosts with {workers} workers")

    results: list[tuple[str, int | None, str | None]] = []
    with ThreadPoolExecutor(max_workers=workers) as pool:
        futures = {pool.submit(check, host): host for host in hosts}
        for future in as_completed(futures):
            results.append(future.result())

    failed = [r for r in results
              if r[1] is None or not (200 <= r[1] < 300)]
    for host, status, error in failed:
        detail = error if error else f"HTTP {status}"
        print(f"FAILED: {host} ({detail})")
    print(f"checked={len(results)} failed={len(failed)}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
