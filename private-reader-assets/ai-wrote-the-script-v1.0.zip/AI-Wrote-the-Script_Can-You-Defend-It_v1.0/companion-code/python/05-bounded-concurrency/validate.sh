#!/usr/bin/env bash
# Validate Lab Python 05: compile checks + behavioral tests.
set -euo pipefail
cd "$(dirname "$0")"

python3 -m py_compile broken/probe.py solution/probe.py
echo "py_compile: OK"

python3 -m pytest tests -v
