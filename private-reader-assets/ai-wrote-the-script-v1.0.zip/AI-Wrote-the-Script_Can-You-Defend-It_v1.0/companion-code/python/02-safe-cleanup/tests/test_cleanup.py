"""Validation for Lab Python 02 -- the cleanup that can delete the wrong thing.

Runs both versions against throwaway directories under pytest's tmp_path.
Nothing outside tmp_path is ever deleted by these tests.
"""
from __future__ import annotations

from pathlib import Path

from _shared.runner import run_python

LAB = Path(__file__).resolve().parent.parent
BROKEN = LAB / "broken" / "cleanup.py"
SOLUTION = LAB / "solution" / "cleanup.py"


def make_workspace(root: Path, name: str = "job-42") -> Path:
    """Build root/name with a build/ tree plus a file that must survive."""
    workspace = root / name
    (workspace / "build" / "nested").mkdir(parents=True)
    (workspace / "build" / "nested" / "artifact.o").write_text("obj")
    (workspace / "src.py").write_text("# keep me\n")
    return workspace


class TestBroken:
    def test_missing_workspace_crashes(self):
        """WORKSPACE absent -> os.path.join(None, ...) raises TypeError."""
        result = run_python(BROKEN, env={"WORKSPACE": None})
        assert result.returncode != 0
        assert "TypeError" in result.stderr  # joined None -- loud, not clean

    def test_empty_workspace_targets_relative_path(self, tmp_path):
        """WORKSPACE="" silently becomes ./build in the current directory."""
        (tmp_path / "build").mkdir()
        (tmp_path / "build" / "cache.bin").write_text("data")
        result = run_python(BROKEN, env={"WORKSPACE": ""}, cwd=tmp_path)
        assert result.returncode == 0
        assert not (tmp_path / "build").exists()  # deleted the CWD's build/

    def test_no_trusted_root_boundary(self, tmp_path):
        """The defect: an absolute WORKSPACE outside any root is trusted."""
        outside = tmp_path / "elsewhere"
        (outside / "build").mkdir(parents=True)
        (outside / "build" / "cache.bin").write_text("data")
        result = run_python(BROKEN, env={"WORKSPACE": str(outside)})
        assert result.returncode == 0
        assert not (outside / "build").exists()  # deleted with no boundary


class TestSolution:
    def env(self, root: Path, **extra: str) -> dict:
        return {"CLEANUP_ALLOWED_ROOT": str(root),
                "WORKSPACE": extra.pop("WORKSPACE", ""),
                **extra}

    def test_missing_workspace_is_clean_refusal(self, tmp_path):
        env = {"CLEANUP_ALLOWED_ROOT": str(tmp_path)}
        env.pop("WORKSPACE", None)
        result = run_python(SOLUTION, env=env)
        assert result.returncode == 64
        assert "WORKSPACE is required" in result.stderr

    def test_workspace_outside_root_is_refused(self, tmp_path):
        allowed = tmp_path / "allowed"
        allowed.mkdir()
        outside = tmp_path / "elsewhere"
        (outside / "build").mkdir(parents=True)
        result = run_python(
            SOLUTION,
            env={"CLEANUP_ALLOWED_ROOT": str(allowed),
                 "WORKSPACE": str(outside)})
        assert result.returncode == 77
        assert "outside allowed root" in result.stderr
        assert (outside / "build").exists()  # untouched

    def test_workspace_equal_to_root_is_refused(self, tmp_path):
        allowed = tmp_path / "allowed"
        (allowed / "build").mkdir(parents=True)
        result = run_python(
            SOLUTION,
            env={"CLEANUP_ALLOWED_ROOT": str(allowed),
                 "WORKSPACE": str(allowed)})
        assert result.returncode == 77
        assert (allowed / "build").exists()

    def test_root_slash_cannot_make_slash_build_acceptable(self, tmp_path):
        """The manuscript's core trap: WORKSPACE=/ must not legitimise /build."""
        allowed = tmp_path / "allowed"
        allowed.mkdir()
        result = run_python(
            SOLUTION,
            env={"CLEANUP_ALLOWED_ROOT": str(allowed), "WORKSPACE": "/"})
        assert result.returncode == 77

    def test_dry_run_is_the_default(self, tmp_path):
        workspace = make_workspace(tmp_path)
        result = run_python(
            SOLUTION,
            env={"CLEANUP_ALLOWED_ROOT": str(tmp_path),
                 "WORKSPACE": str(workspace)})
        assert result.returncode == 0
        assert "DRY RUN" in result.stdout
        assert (workspace / "build" / "nested" / "artifact.o").exists()

    def test_explicit_clear_deletes_only_the_target(self, tmp_path):
        workspace = make_workspace(tmp_path)
        result = run_python(
            SOLUTION,
            env={"CLEANUP_ALLOWED_ROOT": str(tmp_path),
                 "WORKSPACE": str(workspace), "DRY_RUN": "false"})
        assert result.returncode == 0
        assert "Removed" in result.stdout
        assert not (workspace / "build").exists()
        assert (workspace / "src.py").read_text() == "# keep me\n"

    def test_symlinked_target_is_refused(self, tmp_path):
        allowed = tmp_path / "allowed"
        workspace = allowed / "job-7"
        workspace.mkdir(parents=True)
        decoy = tmp_path / "decoy"
        decoy.mkdir()
        (decoy / "important.txt").write_text("do not delete")
        (workspace / "build").symlink_to(decoy, target_is_directory=True)
        result = run_python(
            SOLUTION,
            env={"CLEANUP_ALLOWED_ROOT": str(allowed),
                 "WORKSPACE": str(workspace),
                 "DRY_RUN": "false"})
        assert result.returncode == 77
        assert (decoy / "important.txt").read_text() == "do not delete"

    def test_missing_target_is_a_noop(self, tmp_path):
        workspace = tmp_path / "job-9"
        workspace.mkdir()
        result = run_python(
            SOLUTION,
            env={"CLEANUP_ALLOWED_ROOT": str(tmp_path),
                 "WORKSPACE": str(workspace)})
        assert result.returncode == 0
        assert "Nothing to remove" in result.stdout
