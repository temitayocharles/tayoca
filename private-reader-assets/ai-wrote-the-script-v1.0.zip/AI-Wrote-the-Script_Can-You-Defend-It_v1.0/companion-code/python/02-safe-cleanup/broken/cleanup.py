#!/usr/bin/env python3
# Generated workspace cleanup: remove the build dir under $WORKSPACE.
import os
import shutil

workspace = os.getenv("WORKSPACE")
target = os.path.join(workspace, "build")

if os.path.exists(target):
    shutil.rmtree(target)

print("Cleanup complete")
