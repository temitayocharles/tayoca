# Python 02 — The cleanup script that can delete the wrong thing

**Difficulty:** Foundation / Safety · **Target time:** 20 minutes

An AI-generated cleanup script deletes a `build` directory derived from the
`WORKSPACE` environment variable. There is no trusted boundary, so an
unexpected value — including `/` — can make a dangerous path look fine.

## Layout

- `broken/cleanup.py` — the AI-generated script (defects intact)
- `solution/cleanup.py` — the reference solution
- `tests/test_cleanup.py` — prove-out, including a symlink attack

## Lab adapter

The solution takes its trust boundary from `CLEANUP_ALLOWED_ROOT`
(default `/srv/ci-workspaces`) so the tests can point it at a disposable
directory. In production, pin the root in code or configuration owned by
the platform team — an attacker who can set the deletion variable can often
set other variables too.

## Run it

```bash
cd labs
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest python/02-safe-cleanup/tests -v
```

Everything happens under pytest-managed temporary directories; nothing on
your real filesystem is touched.

## Reset

Nothing persists. Delete `.venv` to remove the environment.

## What to look for

1. What happens with `WORKSPACE` unset? Empty? Set to `/`?
2. Does checking `target.name == "build"` prove the target is safe?
3. What does `Path.resolve()` buy you that string joining does not?
4. Why is dry-run the *default* instead of an opt-in flag?

**Stretch:** implement the marker-file extension — provisioning creates
`.ci-workspace` at the workspace root and the cleanup refuses to run
without it. Which attack or accident does that defend against that the
allowed root does not?
