#!/usr/bin/env python3
"""Reference: fail-closed workspace cleanup with dry-run default.

The trusted allowed root is the safety boundary. ``WORKSPACE=/`` or a
symlink pointing outside the root is refused. Deletion requires an
explicit ``DRY_RUN=false``.
"""
from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

# Trust boundary: cleanup may only operate beneath this root. Override via
# environment so tests and labs can use a disposable directory; production
# deployments should pin this value in code, not in the environment.
ALLOWED_ROOT = Path(os.environ.get(
    "CLEANUP_ALLOWED_ROOT", "/srv/ci-workspaces")).resolve()

TARGET_DIRNAME = "build"

# Extension idea from the pack: have workspace provisioning create a marker
# file such as ".ci-workspace" and refuse to delete without it.
MARKER_NAME = ".ci-workspace"


def refuse(message: str) -> int:
    print(f"ERROR: {message}", file=sys.stderr)
    return 77  # refused: like EX_NOPERM, "permission/boundary problem"


def main() -> int:
    workspace_value = os.environ.get("WORKSPACE", "").strip()
    if not workspace_value:
        print("ERROR: WORKSPACE is required", file=sys.stderr)
        return 64  # EX_USAGE

    # resolve() collapses "..", ".", and symlinks before any decision.
    workspace = Path(workspace_value).resolve()

    if workspace == ALLOWED_ROOT or ALLOWED_ROOT not in workspace.parents:
        return refuse(
            f"workspace outside allowed root {ALLOWED_ROOT}: {workspace}")

    target = (workspace / TARGET_DIRNAME).resolve()
    if target.parent != workspace or target.name != TARGET_DIRNAME:
        # A symlinked workspace/build resolving elsewhere lands here.
        return refuse(f"unsafe deletion target: {target}")

    dry_run = os.environ.get("DRY_RUN", "true").strip().lower() != "false"

    if not target.exists():
        print(f"Nothing to remove: {target}")
        return 0
    if dry_run:
        print(f"DRY RUN: would remove {target}")
        return 0

    shutil.rmtree(target)
    print(f"Removed {target}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
