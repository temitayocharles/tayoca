#!/usr/bin/env bash
# Validate Lab Python 02: compile checks + behavioral tests.
set -euo pipefail
cd "$(dirname "$0")"

python3 -m py_compile broken/cleanup.py solution/cleanup.py
echo "py_compile: OK"

python3 -m pytest tests -v
