# Python 04 — The fragile log parser

**Difficulty:** Intermediate · **Target time:** 20 minutes

A JSONL deploy-log counter works on clean lab data and dies on the first
line a real log shipper truncated. Worse, the original leaves no evidence:
the process just crashes with a traceback.

## Layout

- `broken/count_errors.py` — the AI-generated script (defects intact)
- `solution/count_errors.py` — the reference solution
- `fixtures/deploy.log` — 12 lines covering every failure class
- `fixtures/clean.log` — a well-formed log for the happy path
- `tests/test_log_parser.py` — prove-out

## Fixture accounting

| Lines | Content | Expected bucket |
|---|---|---|
| 3 | valid `ERROR` events | counted |
| 3 | valid non-ERROR events | ignored |
| 2 | blank / whitespace-only | skipped |
| 2 | unparseable JSON | `malformed` |
| 1 | JSON object missing `level` | `invalid` |
| 1 | JSON array, not an object | `invalid` |

## Run it

```bash
cd labs/python/04-log-parser
python3 broken/count_errors.py            # run from fixtures/ to hit the sample
cd ../../../..
python3 -m pytest python/04-log-parser/tests -v
```

The broken version opens `deploy.log` from the current directory, so run it
with `fixtures/` as the working directory.

## Reset

Nothing persists.

## What to look for

1. What does `json.loads` do to the first corrupted line — and to every
   valid line *after* it?
2. `event["level"]` vs `event.get("level")`: which assumption is safer,
   and when does a `.get()` silently hide schema drift?
3. When is tolerant parsing the right call, and when does "keep going"
   become silent data loss? Who should decide — the script or a policy?
4. Why does the solution exit `2` when `malformed` or `invalid` is
   non-zero? What monitoring would you attach to that?

**Stretch:** make invalid-record previews length-bounded and redaction-aware
(log lines can contain PII). Handle a UTF-8 BOM via `encoding="utf-8-sig"`.
When would you process a log that cannot fit in memory — this solution
never loads it whole; verify that claim by reading the code.
