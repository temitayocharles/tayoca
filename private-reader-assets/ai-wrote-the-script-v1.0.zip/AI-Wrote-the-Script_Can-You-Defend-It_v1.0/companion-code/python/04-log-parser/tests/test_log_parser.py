"""Validation for Lab Python 04 -- the fragile log parser.

Fixture accounting (fixtures/deploy.log, 12 physical lines):
  3  valid ERROR events
  3  valid non-ERROR events
  2  blank / whitespace-only lines
  2  unparseable JSON lines          -> malformed
  1  JSON object missing "level"     -> invalid
  1  JSON array (not an object)      -> invalid
"""
from __future__ import annotations

from pathlib import Path

from _shared.runner import run_python

LAB = Path(__file__).resolve().parent.parent
BROKEN = LAB / "broken" / "count_errors.py"
SOLUTION = LAB / "solution" / "count_errors.py"
FIXTURES = LAB / "fixtures"


class TestBroken:
    def test_crashes_on_first_malformed_line(self):
        result = run_python(BROKEN, cwd=FIXTURES)
        assert result.returncode != 0
        assert "JSONDecodeError" in result.stderr
        # The count of errors seen so far is never even printed.
        assert result.stdout.strip() == ""


class TestSolution:
    def test_counts_and_reports_every_category(self):
        result = run_python(SOLUTION, cwd=FIXTURES)
        assert "errors=3 malformed=2 invalid=2" in result.stdout
        assert result.returncode == 2  # policy: corrupted input fails the job
        # Evidence includes line numbers, not just totals.
        assert "line 5" in result.stdout
        assert "line 12" in result.stdout
        assert "line 7" in result.stdout
        assert "line 8" in result.stdout

    def test_clean_log_exits_zero(self):
        result = run_python(SOLUTION, cwd=FIXTURES,
                            args=[str(FIXTURES / "clean.log")])
        assert result.returncode == 0
        assert "errors=1 malformed=0 invalid=0" in result.stdout

    def test_missing_file_fails_cleanly(self):
        result = run_python(SOLUTION, cwd=FIXTURES,
                            args=["/nonexistent/deploy.log"])
        assert result.returncode == 66
        assert "cannot read" in result.stderr
