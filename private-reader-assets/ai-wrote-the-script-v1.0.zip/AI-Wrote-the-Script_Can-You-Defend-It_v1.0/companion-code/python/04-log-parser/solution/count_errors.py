#!/usr/bin/env python3
"""Reference: tolerant-but-loud JSONL deploy-log scanner.

Valid error events are counted. Unparseable lines and schema violations
are counted *and* reported with line numbers, and their presence makes
the run exit non-zero -- tolerance must never mean silence.
"""
from __future__ import annotations

import json
import sys

DEFAULT_LOG = "deploy.log"


def scan(path: str) -> tuple[int, int, int]:
    """Return (errors, malformed, invalid) for a JSONL log file."""
    errors = malformed = invalid = 0

    with open(path, encoding="utf-8") as f:
        for line_number, line in enumerate(f, start=1):
            if not line.strip():
                continue

            try:
                event = json.loads(line)
            except json.JSONDecodeError as exc:
                malformed += 1
                print(f"Malformed JSON at line {line_number}: {exc}")
                continue

            if not isinstance(event, dict) or "level" not in event:
                invalid += 1
                preview = line.strip()[:120]
                print(f"Invalid record at line {line_number}: {preview}")
                continue

            if event["level"] == "ERROR":
                errors += 1

    return errors, malformed, invalid


def main(argv: list[str]) -> int:
    path = argv[1] if len(argv) > 1 else DEFAULT_LOG
    try:
        errors, malformed, invalid = scan(path)
    except OSError as exc:
        print(f"ERROR: cannot read {path}: {exc}", file=sys.stderr)
        return 66  # EX_NOINPUT

    print(f"errors={errors} malformed={malformed} invalid={invalid}")
    # Decide consciously: corrupted input fails this job (auditability),
    # rather than silently producing a plausible-looking count.
    return 2 if malformed or invalid else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
