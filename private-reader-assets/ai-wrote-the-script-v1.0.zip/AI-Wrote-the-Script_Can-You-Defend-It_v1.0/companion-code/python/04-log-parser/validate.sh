#!/usr/bin/env bash
# Validate Lab Python 04: compile checks + behavioral tests.
set -euo pipefail
cd "$(dirname "$0")"

python3 -m py_compile broken/count_errors.py solution/count_errors.py
echo "py_compile: OK"

python3 -m pytest tests -v
