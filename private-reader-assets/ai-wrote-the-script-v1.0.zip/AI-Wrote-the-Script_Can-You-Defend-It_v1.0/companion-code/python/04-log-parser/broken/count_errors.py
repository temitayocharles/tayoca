#!/usr/bin/env python3
"""Count ERROR events in deploy.log (JSONL)."""
import json

errors = 0

with open("deploy.log") as f:
    for line in f:
        event = json.loads(line)
        if event["level"] == "ERROR":
            errors += 1

print(errors)
