#!/usr/bin/env python3
"""Reference: paginated inventory fetch.

Bounded retries with backoff, explicit pagination, response-shape
validation, a pagination-loop guard, a same-origin check on "next" URLs,
and a credential that is never printed.

Lab adapters: INVENTORY_BASE_URL / INVENTORY_URL point the client at the
local mock API; the book hits https://inventory.example.com.
"""
from __future__ import annotations

import os
import sys
import time
from urllib.parse import urlparse

import requests

MAX_ATTEMPTS = 3
MAX_PAGES = 100                # a buggy or hostile cursor cannot spin forever
PAGE_TIMEOUT = (3, 10)         # (connect, read) seconds
RETRYABLE_STATUSES = {429, 500, 502, 503, 504}


def backoff_seconds(attempt: int, retry_after: str | None) -> float:
    """Honor Retry-After when parseable; otherwise exponential backoff."""
    if retry_after is not None:
        try:
            return min(float(retry_after), 30.0)
        except ValueError:
            pass
    return min(2.0 ** attempt, 30.0)


def get_json(session: requests.Session, url: str) -> dict:
    """GET one page, retrying transient failures with a hard bound."""
    last_error: Exception | None = None
    for attempt in range(MAX_ATTEMPTS):
        retry_after = None
        try:
            response = session.get(url, timeout=PAGE_TIMEOUT)
        except requests.RequestException as exc:
            last_error = exc                      # connection-level failure
        else:
            if response.status_code not in RETRYABLE_STATUSES:
                response.raise_for_status()       # fail fast on 4xx/5xx others
                return response.json()
            retry_after = response.headers.get("Retry-After")
            last_error = RuntimeError(f"retryable HTTP {response.status_code}")
        if attempt < MAX_ATTEMPTS - 1:
            time.sleep(backoff_seconds(attempt, retry_after))
    raise RuntimeError(
        f"GET {url} failed after {MAX_ATTEMPTS} attempts") from last_error


def same_origin(first: str, second: str) -> bool:
    a, b = urlparse(first), urlparse(second)
    return (a.scheme, a.netloc) == (b.scheme, b.netloc)


def fetch_all(session: requests.Session, start_url: str) -> list[dict]:
    items: list[dict] = []
    seen: set[str] = set()
    url: str | None = start_url
    pages = 0

    while url:
        if url in seen:
            raise RuntimeError(f"pagination loop detected at {url}")
        seen.add(url)
        if pages >= MAX_PAGES:
            raise RuntimeError(f"aborting after {MAX_PAGES} pages")
        if not same_origin(start_url, url):
            # A next URL you cannot trust is an exfiltration vector: the
            # session carries your Authorization header.
            raise RuntimeError(f"refusing cross-origin next URL: {url}")

        payload = get_json(session, url)
        page_items = payload.get("items")
        if not isinstance(page_items, list):
            raise RuntimeError("API response is missing list field 'items'")
        items.extend(page_items)
        url = payload.get("next")
        pages += 1

    return items


def main() -> int:
    token = os.environ.get("API_TOKEN", "")
    if not token:
        print("ERROR: API_TOKEN is required", file=sys.stderr)
        return 64

    base = os.environ.get("INVENTORY_BASE_URL", "https://inventory.example.com")
    start_url = os.environ.get(
        "INVENTORY_URL", f"{base}/api/v1/instances")

    # The token lives in session headers and is never logged.
    with requests.Session() as session:
        session.headers["Authorization"] = f"Bearer {token}"
        try:
            items = fetch_all(session, start_url)
        except (requests.RequestException, RuntimeError) as exc:
            print(f"ERROR: {exc}", file=sys.stderr)
            return 1

    print(f"Found {len(items)} instances")
    return 0


if __name__ == "__main__":
    sys.exit(main())
