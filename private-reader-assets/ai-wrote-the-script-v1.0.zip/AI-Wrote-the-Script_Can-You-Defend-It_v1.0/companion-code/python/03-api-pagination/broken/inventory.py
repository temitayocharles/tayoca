#!/usr/bin/env python3
# Lab adapter: INVENTORY_URL points this at the local mock API.
import os

import requests

url = os.environ.get(
    "INVENTORY_URL",
    "https://inventory.example.com/api/v1/instances",
)

response = requests.get(
    url,
    headers={"Authorization": "Bearer " + os.environ["API_TOKEN"]},
    timeout=10,
)
response.raise_for_status()
instances = response.json()["items"]
print(f"Found {len(instances)} instances")
