# Python 03 — The API pagination bug

**Difficulty:** Intermediate · **Target time:** 25 minutes

An inventory report works in a lab account but production contains more
than one response page. The AI-generated client reads page 1 and reports
success with a silently incomplete dataset.

## Layout

- `broken/inventory.py` — the AI-generated script (defects intact)
- `solution/inventory.py` — the reference solution
- `tests/test_pagination.py` — prove-out against the local mock API

## Lab adapter

The book hardcodes `https://inventory.example.com`. The lab client honours
`INVENTORY_BASE_URL` (or a full `INVENTORY_URL`) so it can run against the
local mock in `labs/_shared/mock_service.py`. The mock implements:

| Route | Behavior |
|---|---|
| `/api/v1/instances` | page 1 of 3 (requires a valid bearer token) |
| `?cursor=p2` | fails once with 503, then succeeds |
| `?cursor=p3` | final page (`next: null`) |
| `?cursor=rl` | returns 429 with `Retry-After: 1` once |
| `?cursor=loop` | `next` points at itself forever |
| `?cursor=badschema` | returns `{"data": [...]}` — no `items` list |
| `?cursor=weirdnext` | `next` points to a different origin |

## Run it

```bash
cd labs
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python -m pytest python/03-api-pagination/tests -v
```

## Reset

Nothing persists. Delete `.venv` to remove the environment.

## What to look for

1. A successful HTTP request does not prove you received the full dataset.
2. Which failures deserve a retry and which must fail fast (4xx vs 429/5xx)?
3. Why does the client check that every `next` URL shares the original
   origin before following it? (Hint: what header does the session attach
   to every request?)
4. Why is `while url:` with no page cap and no seen-set dangerous?

**Stretch:** add jitter to the backoff, cap total elapsed time instead of
attempt count, and emit one structured log line per page (page number,
count, elapsed) without ever logging `Authorization`.
