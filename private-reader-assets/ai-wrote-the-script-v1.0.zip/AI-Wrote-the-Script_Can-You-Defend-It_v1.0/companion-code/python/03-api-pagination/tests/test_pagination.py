"""Validation for Lab Python 03 -- the API pagination bug.

Every scenario runs against the local mock inventory API. No external
network is involved.
"""
from __future__ import annotations

import time
from pathlib import Path

from _shared.mock_service import InventoryServer
from _shared.runner import run_python

LAB = Path(__file__).resolve().parent.parent
BROKEN = LAB / "broken" / "inventory.py"
SOLUTION = LAB / "solution" / "inventory.py"


def env_for(server: InventoryServer, start: str | None = None) -> dict:
    env = {"API_TOKEN": server.token}
    if start:
        env["INVENTORY_URL"] = start
    else:
        env["INVENTORY_BASE_URL"] = server.base_url
    return env


class TestBroken:
    def test_only_first_page_is_reported(self):
        """The defect: 7 instances exist, but page 1 holds only 3."""
        with InventoryServer() as api:
            result = run_python(BROKEN, env=env_for(api, start=api.start_url))
        assert result.returncode == 0
        assert "Found 3 instances" in result.stdout  # silently incomplete
        assert api.request_count == 1


class TestSolution:
    def test_all_pages_are_collected_despite_one_503(self):
        with InventoryServer() as api:
            result = run_python(SOLUTION, env=env_for(api))
        assert result.returncode == 0
        assert "Found 7 instances" in result.stdout
        # page1 + page2(503) + page2(retry) + page3 = 4 requests
        assert api.request_count == 4

    def test_retry_after_header_is_honored(self):
        with InventoryServer() as api:
            start = time.monotonic()
            result = run_python(SOLUTION, env=env_for(
                api, start=f"{api.start_url}?cursor=rl"))
            elapsed = time.monotonic() - start
        assert result.returncode == 0
        assert "Found 1 instances" in result.stdout
        assert api.request_count == 2
        assert elapsed >= 1.0  # waited out the server's Retry-After: 1

    def test_pagination_loop_is_detected(self):
        with InventoryServer() as api:
            result = run_python(SOLUTION, env=env_for(
                api, start=f"{api.start_url}?cursor=loop"))
        assert result.returncode == 1
        assert "pagination loop detected" in result.stderr

    def test_bad_schema_fails_clearly(self):
        with InventoryServer() as api:
            result = run_python(SOLUTION, env=env_for(
                api, start=f"{api.start_url}?cursor=badschema"))
        assert result.returncode == 1
        assert "missing list field 'items'" in result.stderr

    def test_cross_origin_next_is_refused(self):
        with InventoryServer() as api:
            result = run_python(SOLUTION, env=env_for(
                api, start=f"{api.start_url}?cursor=weirdnext"))
        assert result.returncode == 1
        assert "cross-origin" in result.stderr

    def test_wrong_token_fails_without_retry_storm(self):
        with InventoryServer() as api:
            result = run_python(
                SOLUTION, env={"API_TOKEN": "wrong-token",
                               "INVENTORY_BASE_URL": api.base_url})
        assert result.returncode == 1
        assert "401" in result.stderr
        assert api.request_count == 1  # fail fast: 401 is not retried

    def test_token_never_appears_in_output(self):
        secret = "tok-PA55W0RD-should-not-leak"
        with InventoryServer(token=secret) as api:
            result = run_python(SOLUTION, env=env_for(api))
        assert result.returncode == 0
        assert secret not in result.combined

    def test_missing_token_is_clean_refusal(self):
        result = run_python(SOLUTION, env={"API_TOKEN": ""})
        assert result.returncode == 64
        assert "API_TOKEN is required" in result.stderr
