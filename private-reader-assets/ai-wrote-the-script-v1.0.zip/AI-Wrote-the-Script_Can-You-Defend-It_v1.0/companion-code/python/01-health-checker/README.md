# Python 01 — The health checker that lies

**Difficulty:** Foundation · **Target time:** 15–20 minutes

A CI health-check script checks three services and should fail the job if
any service is unhealthy. The AI-generated version prints errors but CI can
still pass.

## Layout

- `broken/health_check.py` — the AI-generated script (defects intact)
- `solution/health_check.py` — the reference solution
- `tests/test_health_check.py` — automated proof of both behaviors

## Lab adapter

The printed manuscript hardcodes three `https://*.example.com/health` URLs.
The lab files read endpoints from the `HEALTHCHECK_URLS` environment
variable (comma-separated) so the whole exercise runs against the local
mock service in `labs/_shared/mock_service.py` — no internet needed. The
defects are unchanged.

## Run it

```bash
cd labs
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# Watch the broken script let CI pass while a service is down:
python -m pytest python/01-health-checker/tests -v

# Or run by hand:
python - <<'PY'
import sys
sys.path.insert(0, "_shared")
from mock_service import BehaviorServer, refused_address
import subprocess, os
with BehaviorServer("ok") as good:
    env = dict(os.environ, HEALTHCHECK_URLS=f"{good.base_url}/health,http://{refused_address()}/health")
    p = subprocess.run([sys.executable, "python/01-health-checker/broken/health_check.py"], env=env)
    print("broken exit code:", p.returncode)
    p = subprocess.run([sys.executable, "python/01-health-checker/solution/health_check.py"], env=env)
    print("solution exit code:", p.returncode)
PY
```

## Reset

Nothing here writes state. Delete `.venv` to remove the environment.

## The three defects to find

Try to spot them before reading the solutions section of the pack:

1. What happens to the failure count when `requests.get` raises?
2. What bounds the wait if a service accepts the connection and never answers?
3. What does the process exit code communicate to the CI job?

**Stretch:** point `HEALTHCHECK_URLS` at a `BehaviorServer("degraded")`
mock. It returns HTTP 200 with `{"status": "degraded"}` in the body.
Decide what your real endpoint contract requires, then extend the check to
validate the body — that gap is exactly why one of the mock behaviors exists.
