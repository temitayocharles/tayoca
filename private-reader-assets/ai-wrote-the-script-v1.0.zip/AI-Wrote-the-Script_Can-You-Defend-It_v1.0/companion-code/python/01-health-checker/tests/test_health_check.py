"""Validation for Lab Python 01 -- the health checker that lies.

These tests prove two things, with real subprocess runs against the local
mock service (no external network):

* the BROKEN script really does let CI pass while a service is unreachable
* the SOLUTION reports failure through its exit status and bounds waits
"""
from __future__ import annotations

from pathlib import Path

from _shared.mock_service import BehaviorServer, refused_address
from _shared.runner import run_python

LAB = Path(__file__).resolve().parent.parent
BROKEN = LAB / "broken" / "health_check.py"
SOLUTION = LAB / "solution" / "health_check.py"


class TestBroken:
    def test_unreachable_service_still_exits_zero(self):
        """The core defect: a refused connection never reaches 'failed'."""
        with BehaviorServer("ok") as good:
            env = {"HEALTHCHECK_URLS":
                   f"{good.base_url}/health,http://{refused_address()}/health"}
            result = run_python(BROKEN, env=env)
        assert "ERROR" in result.stdout          # the error was *seen* ...
        assert "Failed services: 0" in result.stdout  # ... but not counted
        assert result.returncode == 0            # CI would go green

    def test_no_timeout_is_requested(self):
        """The defect is structural: no call ever passes a timeout= argument."""
        source = BROKEN.read_text(encoding="utf-8")
        assert "timeout=" not in source


class TestSolution:
    def test_all_healthy_exits_zero(self):
        with BehaviorServer("ok") as a, BehaviorServer("ok") as b:
            env = {"HEALTHCHECK_URLS": f"{a.base_url}/health,{b.base_url}/health"}
            result = run_python(SOLUTION, env=env)
        assert result.returncode == 0
        assert "Failed services: 0" in result.stdout

    def test_unreachable_service_fails_the_job(self):
        with BehaviorServer("ok") as good:
            env = {"HEALTHCHECK_URLS":
                   f"{good.base_url}/health,http://{refused_address()}/health"}
            result = run_python(SOLUTION, env=env)
        assert result.returncode == 1
        assert "Failed services: 1" in result.stdout

    def test_http_500_fails_the_job(self):
        env = {"HEALTHCHECK_URLS": ""}
        with BehaviorServer("fail500") as bad:
            env["HEALTHCHECK_URLS"] = f"{bad.base_url}/health"
            result = run_python(SOLUTION, env=env)
        assert result.returncode == 1
        assert "HTTP 500" in result.stdout

    def test_slow_endpoint_is_bounded(self):
        """An endpoint that sleeps 10s must be cut off near the 5s read timeout."""
        with BehaviorServer("slow", slow_seconds=10.0) as slow:
            env = {"HEALTHCHECK_URLS": f"{slow.base_url}/health"}
            result = run_python(SOLUTION, env=env, timeout=20)
        assert result.returncode == 1
        assert result.elapsed < 9.0, (
            f"read timeout was not enforced (took {result.elapsed:.1f}s)")
