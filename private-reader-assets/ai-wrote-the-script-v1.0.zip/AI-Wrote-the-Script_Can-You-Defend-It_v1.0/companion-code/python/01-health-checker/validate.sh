#!/usr/bin/env bash
# Validate Lab Python 01: compile checks + behavioral tests.
set -euo pipefail
cd "$(dirname "$0")"

python3 -m py_compile broken/health_check.py solution/health_check.py
echo "py_compile: OK"

python3 -m pytest tests -v
