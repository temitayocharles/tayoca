#!/usr/bin/env python3
"""Reference: health check with explicit failure semantics.

Lab adapter: endpoints come from HEALTHCHECK_URLS (comma-separated) when
set, so the same code runs against the local mock service. The book text
uses three fixed https://*.example.com/health URLs.
"""
from __future__ import annotations

import os
import sys

import requests

DEFAULT_URLS = [
    "https://api.example.com/health",
    "https://billing.example.com/health",
    "https://auth.example.com/health",
]

CONNECT_TIMEOUT = 3  # seconds to establish a connection
READ_TIMEOUT = 5     # seconds to wait for a response


def configured_urls() -> list[str]:
    override = os.environ.get("HEALTHCHECK_URLS", "").strip()
    if override:
        return [u.strip() for u in override.split(",") if u.strip()]
    return DEFAULT_URLS


def check(url: str) -> tuple[bool, str]:
    """Return (healthy, detail) for one endpoint."""
    try:
        response = requests.get(url, timeout=(CONNECT_TIMEOUT, READ_TIMEOUT))
    except requests.RequestException as exc:
        # A request that never got an answer is a failed health check.
        return False, f"request failed: {exc}"

    # Follow the real endpoint contract. This example treats any 2xx as
    # healthy; some services also require body/readiness validation.
    if 200 <= response.status_code < 300:
        return True, f"HTTP {response.status_code}"
    return False, f"HTTP {response.status_code}"


def main() -> int:
    failed: list[str] = []
    for url in configured_urls():
        healthy, detail = check(url)
        print(f"{'OK' if healthy else 'FAILED'}: {url} ({detail})")
        if not healthy:
            failed.append(url)

    print(f"Failed services: {len(failed)}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
