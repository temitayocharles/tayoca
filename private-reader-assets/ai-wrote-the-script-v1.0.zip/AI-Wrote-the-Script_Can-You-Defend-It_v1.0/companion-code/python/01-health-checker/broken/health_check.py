#!/usr/bin/env python3
# Lab adapter: endpoints come from HEALTHCHECK_URLS (comma-separated) when
# set, so this runs against the local mock service instead of example.com.
import os

import requests

urls = os.environ.get("HEALTHCHECK_URLS", ",".join([
    "https://api.example.com/health",
    "https://billing.example.com/health",
    "https://auth.example.com/health",
])).split(",")

failed = []

for url in urls:
    try:
        response = requests.get(url)
        if response.status_code == 200:
            print(f"OK: {url}")
        else:
            print(f"FAILED: {url} -> {response.status_code}")
            failed.append(url)
    except Exception as exc:
        print(f"ERROR: {url}: {exc}")

print(f"Failed services: {len(failed)}")
