# Companion Labs — AI-to-Engineer Practice Pack

Runnable assets for every challenge in the pack. Each lab contains the
intentionally broken AI-generated script, validated reference solution,
fixtures, an automated test-suite that **proves the defect exists** in the
broken version and **proves the fix works** in the reference, and a README
with setup/reset.

## Layout

```
labs/
  _shared/                 local mock services (offline HTTP stand-ins)
  python/
    01-health-checker/     exit codes, timeouts, endpoint contracts
    02-safe-cleanup/       trusted roots, fail-closed deletion, dry-run
    03-api-pagination/     pagination, retry/backoff, schema validation
    04-log-parser/         tolerant-but-loud parsing, encoding, evidence
    05-bounded-concurrency/ worker caps, failure isolation, rate limits
  bash/
    01-backup-exit-status/ honest exit status, unique artifacts, cleanup
    02-safe-filenames/     quoting, word splitting, find -print0
    03-secret-safe-debugging/ xtrace vs credentials, fail-fast secrets
    04-pipeline-semantics/ pipefail, grep's 0/1/>1 contract
    05-kubernetes-rollout/ bounded waits, evidence, rollback caution
  validate_all.sh          run every lab check end to end
  validate_kubernetes.sh   optional kind-based real-cluster validation
```

## Safety boundary (read once, applies to every lab)

Run these labs on a machine/account you are authorized to use. The
destructive labs (cleanup, filename sweeper) operate only inside
directories the tests create under the system temp area — never point them
at real workspaces, production paths, credentials, clusters, or customer
data. Several `broken/` scripts are dangerous *by design*; the READMEs and
tests contain them.

## Setup (once)

```bash
cd labs
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt    # requests, pytest, PyYAML only
```

Prerequisites: Python 3.10+ with venv, Bash 4+, plus `curl`, `find`,
`grep`, `tar`. Optional: ShellCheck (lint) and Docker + kind + kubectl
(real-cluster validation only).

No lab requires internet access: anything the book hits over the network
has a local stand-in in `_shared/`.

## Validate everything

```bash
bash validate_all.sh                # writes a report to ../validation/logs/
```

Per-lab: each `0X-*/validate.sh` runs syntax checks, ShellCheck (when
installed) and pytest for that lab alone.

## macOS vs Linux

Labs were executed on GNU/Linux (Debian 12). Where flags differ on macOS
the text says so explicitly (`stat`, `date +%N`, curl age). All shipped
solutions avoid non-portable flags; `find -print0` is GNU/BSD and works on
macOS.

## Lab adapters

Printed book code uses realistic placeholder URLs (`example.com`). Lab
copies read endpoint configuration from environment variables
(`HEALTHCHECK_URLS`, `INVENTORY_BASE_URL`, `DEPLOY_URL`, `PROBE_SCHEME`,
`HOSTS_FILE`, `SOURCE_DIR`, `BACKUP_DIR`, `LOG_FILE`) so every network
example runs offline against `labs/_shared/mock_service.py`. Each README
states this; defects are never "adapted away."

## Reset

```bash
deactivate 2>/dev/null; rm -rf labs/.venv
find labs -name "__pycache__" -type d -prune -exec rm -rf {} +
find labs -name ".pytest_cache" -type d -prune -exec rm -rf {} +
```
