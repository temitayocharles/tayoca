# AI Wrote the Script. Can You Defend It?

Thank you for purchasing or receiving an authorized subscriber entitlement to the commercial digital edition.

Start with `AI-Wrote-the-Script_Can-You-Defend-It_v1.0.pdf`, then use the `companion-code/` directory while working through the labs.

The exercises are intentionally built around scripts that look plausible but contain operational failure modes. Predict the failure before running each broken implementation. Then reproduce it, collect evidence, make the smallest safe fix, and prove the corrected behavior.

Recommended local tooling:

- Python 3.11+
- Bash 5+ where available
- `pip install -r companion-code/requirements.txt`
- ShellCheck for Bash linting
- a local container runtime where a lab requires it
- Kubernetes only for the optional live rollout validation path

The companion code is part of the commercial book package. It is licensed for personal learning, professional development, testing and internal non-public practice. It is not licensed for resale or redistribution as a competing product.
