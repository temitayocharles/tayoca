# Official source ledger

Research snapshot: **2026-08-28**. Verify vendor documentation again before production use because node versions, authentication flows, plans, and APIs can change.

## n8n and MCP
- n8n MCP Server Trigger: https://docs.n8n.io/integrations/builtin/core-nodes/n8n-nodes-langchain.mcptrigger/
- n8n MCP Client Tool: https://docs.n8n.io/integrations/builtin/cluster-nodes/sub-nodes/n8n-nodes-langchain.toolmcp/
- n8n Tools AI Agent / Human Review: https://docs.n8n.io/advanced-ai/examples/human-fallback/
- n8n security audit: https://docs.n8n.io/hosting/securing/security-audit/
- Model Context Protocol server concepts: https://modelcontextprotocol.io/docs/learn/server-concepts

## Kubernetes and GitOps
- Kubernetes Deployments: https://kubernetes.io/docs/concepts/workloads/controllers/deployment/
- Services: https://kubernetes.io/docs/concepts/services-networking/service/
- Probes: https://kubernetes.io/docs/concepts/configuration/liveness-readiness-startup-probes/
- Resource management: https://kubernetes.io/docs/concepts/configuration/manage-resources-containers/
- RBAC: https://kubernetes.io/docs/reference/access-authn-authz/rbac/
- NetworkPolicy: https://kubernetes.io/docs/concepts/services-networking/network-policies/
- Helm documentation: https://helm.sh/docs/
- Argo CD documentation: https://argo-cd.readthedocs.io/

## AI client note
OpenAI and other MCP-client product capabilities can vary by plan/workspace and change over time. Verify the current product documentation before teaching a client-specific connection flow.
