n8n MCP Kubernetes Teaching Pack v1.0

Start with the PDF, then read workflows/WORKFLOW-SPEC.md before importing any JSON.

The templates ship inactive and contain placeholders rather than credentials. Configure MCP authentication, workflow IDs, endpoint URL, a supported chat-model credential, and n8n Human Review for the write-style incident tool before activation. Test in a non-production environment.

The Kubernetes path is intentionally GitOps-oriented. Do not give an AI agent a cluster-admin kubeconfig.
