# Workflow import and safety setup

## Import order

1. Import `02-safe-service-health-subworkflow.json` and note its workflow ID.
2. Import `03-create-incident-record-subworkflow.json` and note its workflow ID.
3. Import `04-mcp-safe-ops-server.json`, replace both `REPLACE_*_WORKFLOW_ID` values, configure supported MCP authentication in the MCP Server Trigger, then publish only after testing.
4. Import `05-ai-ops-assistant-mcp-client.json`, replace the MCP production URL, attach an approved chat-model credential, configure MCP authentication, and keep **Selected** tools only.
5. In the AI Agent's current **Human Review** configuration, place only `create_incident` behind a human approval channel. The `check_service_health` read-only tool may remain automatic. **Do not model approval as an AI-supplied boolean.**
6. Import `01-kubernetes-gitops-manifest-builder.json` for the bounded GitOps manifest lab.

## Release safety contract

- All workflows ship inactive.
- No credentials, tokens, kubeconfigs, private endpoints, or account IDs are embedded.
- The MCP server is a template until its authentication is configured.
- The write-style incident tool must be connected through n8n Human Review before activation.
- The Kubernetes lab generates bounded desired-state artifacts. It does not call the Kubernetes API.
- Prefer a branch + pull request + human merge + GitOps reconciliation for cluster changes.
- Node versions and UI labels can change. Inspect every imported node and compare with current n8n documentation before production use.

## Test cases

### Read-only health tool
- `service=demo` -> attempts the allowlisted public demonstration endpoint.
- `service=demo-failure` -> attempts the intentional 503 endpoint.
- arbitrary URL or any other service name -> rejected before a network request.

### Incident record tool
- missing service/summary -> rejected.
- invalid severity -> rejected.
- valid inputs -> returns a reference incident record. In a real implementation, a persistent write must remain behind Human Review and the destination system's authorization controls.

### Manifest builder
- namespace must be `demo` or `staging`.
- replicas must be 1 through 5.
- service port must be 1024 through 65535.
- `:latest` is rejected. Use an explicit tag for the lab and an OCI digest for stronger production immutability.
