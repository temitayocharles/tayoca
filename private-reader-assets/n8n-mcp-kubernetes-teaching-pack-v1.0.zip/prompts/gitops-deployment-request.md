# GitOps deployment request prompt

Prepare a deployment request for the test namespace only. Validate the requested app name, namespace, image tag, replicas, port, CPU, and memory. Produce Kubernetes/Helm changes for a feature branch and pull request. Do not merge the pull request and do not call the Kubernetes API directly. Report validation failures instead of bypassing them.
